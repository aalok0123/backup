﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Stripe;
using Servcorp.ViewModel;

namespace Servcorp.Web.CommonMethod
{
    public class PaymentMethod
    {

        #region payment Method

        //Create Customer
        public static string CreateStripeCustomer(StripeChargeViewModel model)
        {
            StripeCustomer stripeCustomer = new StripeCustomer();
            try
            {
                var myCustomer = new StripeCustomerCreateOptions()
                {
                    Email = model.Email,
                    Description = model.Description,
                    SourceToken = model.Token
                };               
                var customerService = new StripeCustomerService();
                StripeConfiguration.SetApiKey(System.Configuration.ConfigurationManager.AppSettings["StripeKeyTest"].ToString());
                stripeCustomer = customerService.Create(myCustomer);
                return stripeCustomer.Id;
            }
            catch (Exception)
            {
                return stripeCustomer.Id = "";
            }
        }

        //Payment Process
        public static string ProcessPayment(StripeChargeViewModel model, string customerId)
        {
            string stripechrgid = string.Empty;
            var myCharge = new StripeChargeCreateOptions
            {
                Amount = (int)(model.Amount * 100),
                Currency = "USD",
                Description = "Description for test",                
                //SourceTokenOrExistingSourceId = model.Token,                
                CustomerId = customerId
            };

            var chargeService = new StripeChargeService(System.Configuration.ConfigurationManager.AppSettings["StripeKeyTest"].ToString());
            try
            {
                var stripeCharge = chargeService.Create(myCharge);
                stripechrgid = stripeCharge.Id;
            }
            catch (Exception e)
            {
                //model.paymentIssue = e.Message;
            }

            return stripechrgid;
        }

        public static string GetRightPlanSubscriptionId(int TypeId)
        {
            string planId = "";
            if (TypeId == 0)
            { 
            
            }
            return planId;
        }
        //Set Planne
        public static string CreateSubscriptionPlan()
        {
            StripePlanCreateOptions myPlan = new StripePlanCreateOptions();
            try
            {
                Guid guid = Guid.NewGuid();
                myPlan = new StripePlanCreateOptions()
                {
                    Id = guid.ToString(),
                    Amount = 12,           // all amounts on Stripe are in cents, pence, etc
                    Currency = "usd",        // "usd" only supported right now
                    Interval = "month",      // "month" or "year"
                    IntervalCount = 1,       // optional
                    Name = "Platinum",
                    TrialPeriodDays = 30    // amount of time that will lapse before the customer is billed
                };
                var planService = new StripePlanService();
                StripeConfiguration.SetApiKey(System.Configuration.ConfigurationManager.AppSettings["StripeKeyTest"].ToString());
                StripePlan response = planService.Create(myPlan);
                return myPlan.Id;
            }
            catch (Exception ex)
            {
                return myPlan.Id = "";
            }
        }

        //Create Subscription
        public static bool ProcesssSignupRequest(StripeChargeViewModel model)
        {
            try
            {
                var planId = GetRightPlanSubscriptionId(model.TypeId);
                var customerId = CreateStripeCustomer(model);
                var chargeId = ProcessPayment(model, customerId);
                var subscriptionService = new StripeSubscriptionService();
                StripeSubscription stripeSubscription = subscriptionService.Create(customerId, planId);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }



        public static void SubscribeCustomerToPlatiumPlan(string CustomerID)
        {
            try
            { 
                //var StripeCustomerId = CreateStripeCustomer(model);// DB.GetStripeCustomerId();  //Grab stripe customerId from local DB
                var customerService = new StripeCustomerService();
                StripeCustomer stripeCustomer = customerService.Get(CustomerID);
                StripeSubscriptionService subscriptionSvc = new StripeSubscriptionService();
                StripeSubscription subscriptionData = subscriptionSvc.Create(CustomerID, System.Configuration.ConfigurationManager.AppSettings["StripePlan"].ToString());
            }
            catch(Exception ex)
            { }
        }


        //Show all Subscription Plan

        public static IEnumerable<StripePlan> GetAllSubscriptionPlane()
        {
            
            IEnumerable<StripePlan> lst = new List<StripePlan>();
            StripePlanService stripePlaneSvc = new StripePlanService();
            stripePlaneSvc.ApiKey = System.Configuration.ConfigurationManager.AppSettings["StripeKeyTest"].ToString();
            //StripeSubscriptionService svc = new StripeSubscriptionService();
            lst = stripePlaneSvc.List();
            return lst;
        }


        //Get Customer Details
        public static StripeCustomer GetCreditCardDetails(string customerId)
        {

            StripeCustomer stcus = new StripeCustomer();
            StripeCustomerService stSvc = new StripeCustomerService();
            try
            { 
            stSvc.ApiKey=System.Configuration.ConfigurationManager.AppSettings["StripeKeyTest"].ToString();
            stcus = stSvc.Get(customerId);
            }
            catch(Exception ex)
            {
                stcus = null;
            }
            return stcus;
        }

        //Update Customer Credit Cards
        public static string UpdateCreditCardDetails(CustomerCrditCardViewModel cusCrdVM)
        {
            string cardUpdatedStatus=string.Empty;
            try
            { 

            StripeCustomer stcus = new StripeCustomer();
            StripeCustomerService stSvc = new StripeCustomerService();

            stSvc.ApiKey = System.Configuration.ConfigurationManager.AppSettings["StripeKeyTest"].ToString();
            StripeCustomerUpdateOptions newOption=new StripeCustomerUpdateOptions ();
            newOption.SourceCard = new SourceCard() {
                Number = cusCrdVM.Number,
                ExpirationMonth=cusCrdVM.ExpirationMonth,
                ExpirationYear = cusCrdVM.ExpirationYear,
                Cvc = cusCrdVM.CVV,
                Description="Update my new cards"            
            };
            stcus = stSvc.Update(cusCrdVM.CustomerId, newOption);
            
            cardUpdatedStatus = "Updated";
            }
            catch(Exception ex)
            {
                cardUpdatedStatus =ex.Message;
            }
            return cardUpdatedStatus;
        }


        //Delete Customer Credit Cards
        public static string DeleteCreditCardDetails(string customerId)
        {
            string cardDeleteStatus = string.Empty;
            try
            { 
                //StripeCustomerService stSvc = new StripeCustomerService();
                //stSvc.ApiKey = System.Configuration.ConfigurationManager.AppSettings["StripeKeyTest"].ToString();
                //Testing for Delete Card
                StripeCard stCard = new StripeCard();
                StripeCardService stpSvc = new StripeCardService();
                stpSvc.ApiKey = System.Configuration.ConfigurationManager.AppSettings["StripeKeyTest"].ToString();
                StripeCustomer stripeCus = new StripeCustomer();
                stripeCus = GetCreditCardDetails(customerId);
                stpSvc.Delete(customerId, stripeCus.DefaultSourceId);

                //End
                StripeDeleted stDel = new StripeDeleted();
                //stDel = stSvc.Delete(customerId);
                cardDeleteStatus = "Deleted";
            }
            catch (Exception ex)
            {
                cardDeleteStatus = ex.Message;
            }
            return cardDeleteStatus;
        }


        //Add more Credit card

        public static string AddAnotherCreditCard(CustomerCrditCardViewModel cusCrdVM)
        {
            string status=string.Empty;
            try 
            {
                var anotherCard = new StripeCardCreateOptions();
                    anotherCard.SourceCard = new SourceCard
                    {
                       Number = cusCrdVM.Number,
                       ExpirationYear = cusCrdVM.ExpirationYear,
                       ExpirationMonth = cusCrdVM.ExpirationMonth,
                       Cvc = cusCrdVM.CVV
                     };
                    
                 StripeCardService NewStripeCardService = new StripeCardService();
                 NewStripeCardService.ApiKey = System.Configuration.ConfigurationManager.AppSettings["StripeKeyTest"].ToString();

                 StripeCard stripeCustomer = NewStripeCardService.Create(cusCrdVM.CustomerId, anotherCard);

                //Testing for assign default card
                 //StripeCustomer scus = new StripeCustomer();
                 //StripeCustomerService svcCus = new StripeCustomerService();
                 ////scus = svcCus.Get()
                

                //End
                
                return status="New Card Added";
            }
            catch(Exception ex)
            {
                return status="";
            }
        }

        #endregion
    }
}