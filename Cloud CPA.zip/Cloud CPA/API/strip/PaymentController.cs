﻿using Servcorp.Data;
using Servcorp.Data.Infrastructure;
using Servcorp.Data.Repositories;
using Servcorp.Entities;
using Servcorp.Services;
using Servcorp.Services.Abstract;
using Servcorp.Services.EmailConfiguration;
using Servcorp.Services.Utilities;
using Servcorp.ViewModel;
using Servcorp.Web.Infrastructure.Core;
using Servcorp.Web.Infrastructure.Email;
using Servcorp.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Stripe;
using Servcorp.Web.CommonMethod;
using AutoMapper;


namespace Servcorp.Web.Controllers
{
    [AllowAnonymous]
    [RoutePrefix("api/Payment")]
    public class PaymentController : ApiControllerBase
    {
        // GET: Payment
        private readonly ICommonService _commonService;
        private readonly IMembershipService _membershipService;
        private AuthRepository _repo = null;
        private readonly IStripePaymentService _stripePaymentService;
        public PaymentController(ICommonService commonService, IMembershipService membershipService,
            IEntityBaseRepository<Error> _errorsRepository, IUnitOfWork _unitOfWork,
            IStripePaymentService stripePaymentService)
            : base(_errorsRepository, _unitOfWork)
        {
            _repo = new AuthRepository();
            _commonService = commonService;
            _membershipService = membershipService;
            _stripePaymentService = stripePaymentService;
        }

        [HttpPost]
        [Route("createStripeCustomer")]
        public HttpResponseMessage CreateStripeCustomer(HttpRequestMessage request, [FromBody]StripeChargeViewModel model)
        {
            //return CreateHttpResponse(request, () =>
            //{
                string customerId = "";
                try
                {
                    var TempResult = PaymentMethod.CreateStripeCustomer(model);
                    
                    customerId = TempResult;
                    if (customerId!=null && customerId!="")
                    {
                        //PaymentMethod.SubscribeCustomerToPlatiumPlan(customerId);

                        StripeSubscriptionService subscriptionSvc = new StripeSubscriptionService();
                        StripeSubscription subscriptionData = subscriptionSvc.Create(customerId, System.Configuration.ConfigurationManager.AppSettings["StripePlan"].ToString());
                        var vmModel = new StripeSubscriptionDataViewModel()
                        {
                            ApplicationFeePercent=subscriptionData.ApplicationFeePercent,
                            CancelAtPeriodEnd=subscriptionData.CancelAtPeriodEnd,
                            CanceledAt=subscriptionData.CanceledAt,
                            Created=subscriptionData.Created,
                            CurrentPeriodEnd=subscriptionData.CurrentPeriodEnd,
                            CurrentPeriodStart=subscriptionData.CurrentPeriodStart,
                            CustomerId = subscriptionData.CustomerId,
                            Quantity=subscriptionData.Quantity,
                            Start=subscriptionData.Start,
                            Status=subscriptionData.Status,
                            TaxPercent=subscriptionData.TaxPercent,
                            TrialEnd=subscriptionData.TrialEnd,
                            TrialStart=subscriptionData.TrialStart,
                            CreatedDate = DateTime.UtcNow,
                            ModifiedDate = DateTime.UtcNow,
                            EndedAt=subscriptionData.EndedAt,
                            SubscriptionId=subscriptionData.Id,
                            //UserId=model.UserId


                        };
                        //StripeSubscriptionDataViewModel sbs = Mapper.Map<StripeSubscription, StripeSubscriptionDataViewModel>(subscriptionData);

                       string status=  _stripePaymentService.SaveStripeSubscriptionData(vmModel);
                    }
                    else
                        customerId = "";
                }
                catch (Exception)
                {
                    customerId = "";
                }
                return Request.CreateResponse(HttpStatusCode.OK, customerId);
            //});
        }

        [Route("checkUserExistOrNot")]
        [HttpPost]
        public HttpResponseMessage CheckUserExistOrNot(HttpRequestMessage request, [FromBody]CheckUserExistRequestViewModel rqVModel)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                ResponseViewModel responseData = new ResponseViewModel();
                if (ModelState.IsValid)
                {
                    responseData = _membershipService.CheckUserExistOrNot(rqVModel);
                    response = Request.CreateResponse(HttpStatusCode.OK, responseData);
                }
                else
                    response = request.CreateResponse(HttpStatusCode.OK, new { success = false });

                return response;
            });
        }



        [Route("getAllSubscriptionPlane")]
        [HttpPost]
        public HttpResponseMessage GetAllSubscriptionPlane(HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                //ResponseViewModel rm = new ResponseViewModel();
                var lst=PaymentMethod.GetAllSubscriptionPlane();
                return Request.CreateResponse(HttpStatusCode.OK, lst);
            });
        }


        //[Route("DeactivateUserOfStripeSbuscription")]
        //[HttpPost]
        //public HttpResponseMessage DeactivateUserOfStripeSbuscription(HttpRequestMessage request)
        //{
        //    return CreateHttpResponse(request, () =>
        //    {
        //        //ResponseViewModel rm = new ResponseViewModel();
        //        _membershipService.DeactivateUserOfStripeSbuscription();
        //        return Request.CreateResponse(HttpStatusCode.OK);
        //    });
        //}

        [Route("getCustomerCardDetails")]
        [HttpPost]
        public HttpResponseMessage GetCustomerDetails(HttpRequestMessage request,[FromBody]CustomerIdViewModel custVM)
        {
            return CreateHttpResponse(request, () =>
            {

                StripeCustomer details = PaymentMethod.GetCreditCardDetails(custVM.CustomerId);
                if (details.Sources.Data.Count>0)
                return Request.CreateResponse(HttpStatusCode.OK, details.Sources.Data[0].Card);
                else
                return Request.CreateResponse(HttpStatusCode.OK, details.Sources.Data);
            });
        }


        [Route("updateCustomerCardDetails")]
        [HttpPost]
        public HttpResponseMessage UpdateCreditCardDetails(HttpRequestMessage request, [FromBody]CustomerCrditCardViewModel customerVM)
        {
            return CreateHttpResponse(request, () =>
            {
                string details = PaymentMethod.UpdateCreditCardDetails(customerVM);
                return Request.CreateResponse(HttpStatusCode.OK, details);
            });
        }


        [HttpPost]
        [Route("getStripeCustomerId")]
        public HttpResponseMessage GetStripeCustomerId(HttpRequestMessage request, [FromBody]IdViewModel idViewModel)
        {
            return CreateHttpResponse(request, () =>
            {
                ResponseViewModel rm = new ResponseViewModel();
                rm.responseData =_membershipService.GetStripeCustomerId(idViewModel.id);
                return Request.CreateResponse(HttpStatusCode.OK, rm.responseData);
                //return response;
            });
        }
        //Delete Credit Card details
        [Route("deleteCustomerCardDetails")]
        [HttpPost]
        public HttpResponseMessage DeleteCreditCardDetails(HttpRequestMessage request, [FromBody]CustomerIdViewModel custVM)
        {
            return CreateHttpResponse(request, () =>
            {
                string details = PaymentMethod.DeleteCreditCardDetails(custVM.CustomerId);
                return Request.CreateResponse(HttpStatusCode.OK, details);
            });
        }

        //Add more credit card
        [Route("addAnotherCreditCard")]
        [HttpPost]
        public HttpResponseMessage AddAnotherCreditCard(HttpRequestMessage request, [FromBody]CustomerCrditCardViewModel customerVM)
        {
            return CreateHttpResponse(request, () =>
            {
                string details = PaymentMethod.AddAnotherCreditCard(customerVM);
                return Request.CreateResponse(HttpStatusCode.OK, details);
            });
        }


    }
}