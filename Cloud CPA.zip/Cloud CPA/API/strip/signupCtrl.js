﻿(function (app) {
    'use strict';

    app.controller('signupCtrl', signupCtrl);

    signupCtrl.$inject = ['$scope', 'membershipService', 'notificationService', '$rootScope', '$location', '$timeout', '$uibModalStack', '$uibModal', 'apiService', '$translatePartialLoader', '$translate', '$routeParams'];

    function signupCtrl($scope, membershipService, notificationService, $rootScope, $location, $timeout, $uibModalStack, $uibModal, apiService, $translatePartialLoader, $translate ,$routeParams) {
        $translatePartialLoader.addPart('servCorp/profile');
        $scope.signUpObject = {
            signUpDetails: [],
            guid: $routeParams.guid,
            signUpDetailsViewModel: { IsCreditCardPayment:1},
            groups: {},            
            databseObject: {               
            }
        }

        $scope.YearFormatExpiry = {
            start: "decade",
            depth: "decade",
            format: "yyyy",
            min: $scope.todayDate
        };
        $scope.todayDate = new Date();
        $scope.IsCreditCardPayment = 1;
        
        $scope.signupProcess=function () {
            if ($scope.signnUpValidator.validate()) {                
                Stripe.setPublishableKey('pk_test_ziC6XYaGEM4UrS9NbAN75rsA');
                //Stripe.setPublishableKey('pk_test_wyMxJfQAfjSEqBzFC1HmsqbN');
                Stripe.card.createToken({
                    number: $scope.CardNumber,
                    cvc: $scope.CVV,
                    exp_month:$scope.ExpiryMonth, //$scope.exp_month = 08,
                    exp_year: $scope.ExpiryYear //$scope.exp_year = 2018
                }, $scope.stripeResponseHandler);

                

                
            }

        }



        $scope.stripeResponseHandler=function (status, response) {
            if (response.error) {
                // Show the errors on the form
                notificationService.displayWarning(response.error.message);
            }
            else {
                var token = response.id;
                $scope.amount = 45;
                var model = { Token: token, Amount: $scope.amount, Email: $scope.signUpObject.signUpDetailsViewModel.Email, Description: $scope.signUpObject.signUpDetailsViewModel.CompamyName };

                if (model.Token != null) {
                    //Create stripe customer id
                    apiService.post('/api/Payment/createStripeCustomer', model, $scope.paymentconfirm, $scope.Failed)
                }
            }
        }


        $scope.paymentconfirm = function (result) {
                    if (result != "")
                    {
                        //Register company/user with stripe customerid
                         //$scope.signUpObject.signUpDetailsViewModel.StripeCustomerId = result.data.toString();
                         $scope.signUpObject.signUpDetailsViewModel.Username = $scope.signUpObject.signUpDetailsViewModel.Email;
                         $scope.signUpObject.signUpDetailsViewModel.CompanyName = $scope.signUpObject.signUpDetailsViewModel.CompamyName;
                         $scope.signUpObject.signUpDetailsViewModel.guid = $scope.signUpObject.guid;
                         apiService.post('/api/Account/registerCompany', $scope.signUpObject.signUpDetailsViewModel,
                         $scope.saveUserdetails,
                         $scope.Failed);
                    }
                    else
                    {
                        notificationService.displayWarning($translate.instant('Something_went_wrong_Please_try_again'));
                    }
                   
                }
                $scope.saveUserdetails = function (resposnse) {
                    notificationService.displaySuccess($translate.instant('Account_created_successfully_Please_login'));
                    $location.path('/companylogin');
                }


                $scope.checkUserExistOrNot = function () {
                    if ($scope.signnUpValidator.validate()) {
                        var requestVm = {};
                        requestVm.Username = $scope.signUpObject.signUpDetailsViewModel.Email;
                        requestVm.Email = $scope.signUpObject.signUpDetailsViewModel.Email;
                        $scope.signUpObject.signUpDetailsViewModel.Username = $scope.signUpObject.signUpDetailsViewModel.Email;
                        apiService.post('/api/Payment/checkUserExistOrNot', requestVm,
                                     $scope.checkUserExistOrNotSuccess,
                                     $scope.Failed);
                    }
        }
        //$scope.checkUserExistOrNotSuccess = checkUserExistOrNotSuccess;

        $scope.checkUserExistOrNotSuccess = function (response){
            if (response.data.status == 1)
            {
                //$scope.signupProcess();
                $scope.paymentconfirm();
            }
            else
                notificationService.displayError($translate.instant('User_already_exist'));
            
        }

       
    }

})(angular.module('common.core'));