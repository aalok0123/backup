﻿using CoreEntities.CustomModel;
using ServiceLayer.Interface;
using ServiceLayer.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Providers.Entities;
using System.Web.Routing;
using System.Web.Security;
using AutoMapper;
using model = CoreEntities.Models;

namespace eQstats.Helper
{
    public class CustomAuthorize : AuthorizeAttribute
    {
        private bool IsAdminUserRequired = false;

        public CustomAuthorize(bool IsAdminUserRequired = false)
        {
            this.IsAdminUserRequired = IsAdminUserRequired;


        }
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            //if (filterContext.HttpContext.User.Identity.IsAuthenticated)
            //{
            //    base.HandleUnauthorizedRequest(filterContext);
            //}
            // var useSession = (UserSession)filterContext.HttpContext.Session[ApplicationConstant.UserSession];



            //string cookiePath = ticket.CookiePath;
            //DateTime expiration = ticket.Expiration;
            //bool expired = ticket.Expired;
            //bool isPersistent = ticket.IsPersistent;
            //DateTime issueDate = ticket.IssueDate;
            //string name = 
            //string userData = ticket.UserData;
            //int version = ticket.Version;


            var useSession = SessionHelper.UserSession;
            if (!(useSession.UserId > 0)) // Authentication fail
            {

                HttpCookie authCookie = System.Web.HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];
                FormsAuthenticationTicket ticket = null;
                if (authCookie != null && !string.IsNullOrEmpty(authCookie.Value))
                {
                    ticket = FormsAuthentication.Decrypt(authCookie.Value);
                    var userCode = ticket.Name;
                    IUserService services = new UserService();
                    var userCore = services.GetAllUser(eUser => eUser.UserCode == userCode).FirstOrDefault();
                    if (userCore != null)
                    {
                        AutoMapper.Mapper.CreateMap<model.User, UserModel>();
                        var userModel = AutoMapper.Mapper.Map<model.User, UserModel>(userCore);

                        SessionHelper.StoreUserSession(userModel);
                    }

                    if (IsAdminUserRequired)
                    {
                        if (!(SessionHelper.UserSession.UserTypeId == (int)Enums.UserType.Admin))
                        {

                            filterContext.Result = new RedirectToRouteResult(new
                            RouteValueDictionary(new { controller = "Folder", action = "DocumentListing", area = "Document" }));
                        }


                    }

                }
                else
                {
                    if (filterContext.HttpContext.Request.IsAjaxRequest())
                    {


                        filterContext.Result = new JsonResult
                          {
                              Data = new
                              {
                                  status = "401"
                              },
                              JsonRequestBehavior = JsonRequestBehavior.AllowGet
                          };

                        //xhr status code 401 to redirect
                        

                        return;

                    }
                    else
                    {


                        filterContext.Result = new RedirectToRouteResult(new
                  RouteValueDictionary(new { controller = "GateWay", action = "Login", area = "" }));
                    }

                }







            }
            else // Authentication success now procced to autherize user for request
            {
                if (IsAdminUserRequired)
                {
                    if (!(SessionHelper.UserSession.UserTypeId == (int)Enums.UserType.Admin))
                    {

                        filterContext.Result = new RedirectToRouteResult(new
                        RouteValueDictionary(new { controller = "Folder", action = "DocumentListing", area = "Document" }));
                    }


                }


            }
        }
    }
}