﻿

using OGWM.Data.Common;
using OGWM.Entities;
using OGWM.Enum;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;

namespace OGWM.Data.Model
{
    public class ExcuteTableValuedSP : ogwmEntities
    {
        public void ExecuteTableValueProcedure(DataTable table, string procedureName, string paramName, string typeName)
        {
            SqlParameter parameter = new SqlParameter(paramName, table);
            parameter.SqlDbType = SqlDbType.Structured;
            parameter.TypeName = typeName;

            //// execute sp sql 
            string sql = String.Format("EXEC {0} {1};", procedureName, paramName);
            base.Database.ExecuteSqlCommand(sql, parameter);
            //base.Database.ExecuteStoreCommand(sql, parameter);
        }

        public void ExecuteUpdateUserNotifications(DataTable table, int type)
        {
            SqlConnection cn = new SqlConnection(base.Database.Connection.ConnectionString);
            cn.Open();
            SqlCommand cmd = new SqlCommand("[dbo].[UpdateUserNotifications]",cn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter tvpParam = cmd.Parameters.AddWithValue("@NotificationIds", table);
            tvpParam.SqlDbType = SqlDbType.Structured;
            SqlParameter Param = cmd.Parameters.AddWithValue("@Type", type);
            Param.SqlDbType = SqlDbType.Int;
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        public void ExecuteMultipleDeleteFromMineralInterest(int LeaseId, string OwnerIDs, int Deletedby, bool IsWellLocked = false, string LockedWellNames = "", string LocationDataIdToDelete = "")
        {
            SqlConnection cn = new SqlConnection(base.Database.Connection.ConnectionString);
            cn.Open();
            SqlCommand cmd = new SqlCommand("[dbo].[DeleteLeaseOwnershipDetails]", cn);

            cmd.CommandType = CommandType.StoredProcedure;
            System.Data.Common.DbParameter param1 = cmd.CreateParameter();
            param1 = cmd.CreateParameter();
            param1.ParameterName = "@LeaseId";
            param1.DbType = DbType.Int32;
            param1.Value = LeaseId;
            cmd.Parameters.Add(param1);

            System.Data.Common.DbParameter param2 = cmd.CreateParameter();
            param2 = cmd.CreateParameter();
            param2.ParameterName = "@OwnerIds";
            param2.DbType = DbType.String;
            param2.Value = OwnerIDs;
            cmd.Parameters.Add(param2);

            System.Data.Common.DbParameter param3 = cmd.CreateParameter();
            param3 = cmd.CreateParameter();
            param3.ParameterName = "@DeletedBy";
            param3.DbType = DbType.Int32;
            param3.Value = Deletedby;
            cmd.Parameters.Add(param3);

            System.Data.Common.DbParameter param4 = cmd.CreateParameter();
            param4 = cmd.CreateParameter();
            param4.ParameterName = "@IsWellLocked";
            param4.DbType = DbType.Boolean;
            param4.Value = IsWellLocked;
            cmd.Parameters.Add(param4);

            System.Data.Common.DbParameter param5 = cmd.CreateParameter();
            param5 = cmd.CreateParameter();
            param5.ParameterName = "@LocationDataIdToDelete";
            param5.DbType = DbType.String;
            param5.Value = LocationDataIdToDelete;
            cmd.Parameters.Add(param5);

            cmd.ExecuteNonQuery();
            cn.Close();
        }
        
        public void ExecuteSpProcedure(string procedureName, string paramName)
        {
            //// execute sp sql 
            string sql = String.Format("EXEC {0} {1};", procedureName, paramName);
            base.Database.ExecuteSqlCommand(sql);
            //base.Database.ExecuteStoreCommand(sql, parameter);
        }

        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }

        public static DataTable ToStringDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            dataTable.Columns.Add("Item");
            foreach (T item in items)
            {
                var values = new object[1];
                values[0] = item;
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }

        public DataSet GetDataSetFromADO(List<SqlParameter> parameter, string ProcedureName = "")
        {
            SqlConnection cn = new SqlConnection(base.Database.Connection.ConnectionString);
            SqlCommand cmd = new SqlCommand(ProcedureName, cn);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter itemParameter in parameter)
            {
                cmd.Parameters.Add(itemParameter);
            }
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds, "table");
            cn.Close();
            return ds;
        }

        public List<t> GetDataTableCollectionFromADO<t>(List<SqlParameter> parameter, string ProcedureName="") where t : class
        {
            SqlConnection cn = new SqlConnection(base.Database.Connection.ConnectionString);
            SqlCommand cmd = new SqlCommand(ProcedureName, cn);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter itemParameter in parameter)
            {
                cmd.Parameters.Add(itemParameter);
            }
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds, "table");
            cn.Close();
            var obj1 = ds.Tables[0].ToCollection<t>();
            return obj1;
        }


        public ReportFilter GetExibhitReportReportFilter(int? ProspectId, string LessorId, int? LeaseId, int? CountyId) 
        {
            ReportFilter rf = new ReportFilter();
            SqlConnection cn = new SqlConnection(base.Database.Connection.ConnectionString);
            SqlCommand cmd = new SqlCommand("GetFilterExibhitData", cn);
            cmd.CommandType = CommandType.StoredProcedure;

            System.Data.Common.DbParameter param1 = cmd.CreateParameter();
            param1 = cmd.CreateParameter();
            param1.ParameterName = "@ProspectId";
            param1.DbType = DbType.Int32;
            param1.Value = ProspectId;
            cmd.Parameters.Add(param1);

            System.Data.Common.DbParameter param2 = cmd.CreateParameter();
            param2 = cmd.CreateParameter();
            param2.ParameterName = "@LessorId";
            param2.DbType = DbType.String;
            param2.Value = LessorId;
            cmd.Parameters.Add(param2);

            System.Data.Common.DbParameter param3 = cmd.CreateParameter();
            param3 = cmd.CreateParameter();
            param3.ParameterName = "@LeaseId";
            param3.DbType = DbType.Int32;
            param3.Value = LeaseId;
            cmd.Parameters.Add(param3);

            System.Data.Common.DbParameter param4 = cmd.CreateParameter();
            param4 = cmd.CreateParameter();
            param4.ParameterName = "@CountyId";
            param4.DbType = DbType.Int32;
            param4.Value = CountyId;
            cmd.Parameters.Add(param4);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();

            cn.Open();
            da.Fill(ds, "ReportFilter");
            cn.Close();

            rf.ListProspect = ds.Tables[0].ToCollection<Item>();
            rf.ListLease = ds.Tables[1].ToCollection<Item>();
            rf.ListLeassor = ds.Tables[2].ToCollection<Item>();
            rf.ListFilterSurvey = ds.Tables[3].ToCollection<FilterSurvey>();
            return rf;
        }

        public List<int> GetDataTableIntCollectionFromADO(List<SqlParameter> parameter, string ProcedureName="")
        {
            SqlConnection cn = new SqlConnection(base.Database.Connection.ConnectionString);
            SqlCommand cmd = new SqlCommand(ProcedureName, cn);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter itemParameter in parameter)
            {
                cmd.Parameters.Add(itemParameter);
            }
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds, "table");
            cn.Close();
            var obj1 = ds.Tables[0].ToCollection<int>();
            return obj1;
        }
        
        public void ExecuteNonQueryFromADO(List<SqlParameter> parameter, string ProcedureName="")
        {
            SqlConnection cn = new SqlConnection(base.Database.Connection.ConnectionString);
           if( cn.State==ConnectionState.Closed)
           {
               cn.Open();
           }
            SqlCommand cmd = new SqlCommand(ProcedureName, cn);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter itemParameter in parameter)
            {
                cmd.Parameters.Add(itemParameter);
            }
            cmd.ExecuteNonQuery();
            if (cn.State == ConnectionState.Open)
            {
                cn.Close();
            }
        }
        
        public List<int> ExecUdpateLeaseWellGeom(int EntityId, string entityType = "wells")
        {
            SqlConnection cn = new SqlConnection(base.Database.Connection.ConnectionString);
            SqlCommand cmd = new SqlCommand("[dbo].[udpateLeaseWellGeom]", cn);

            cmd.CommandType = CommandType.StoredProcedure;
            System.Data.Common.DbParameter param1 = cmd.CreateParameter();
            param1 = cmd.CreateParameter();
            param1.ParameterName = "@EntityId";
            param1.DbType = DbType.Int32;
            param1.Value = EntityId;
            cmd.Parameters.Add(param1);

            System.Data.Common.DbParameter param2 = cmd.CreateParameter();
            param2 = cmd.CreateParameter();
            param2.ParameterName = "@LocationType";
            param2.DbType = DbType.String;
            param2.Value = entityType;
            cmd.Parameters.Add(param2);
            try
            {
                cn.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                if (ds.Tables[0].Rows[0][0].ToString() != "0")
                {
                    List<int> lstLocationDataIds = new List<int>();
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        lstLocationDataIds.Add(Convert.ToInt32(ds.Tables[0].Rows[i]["LocationDataId"]));
                    }
                    return lstLocationDataIds;
                }
                else
                {
                    return new List<int>();
                }
            }
            catch
            {
                return new List<int>();
            }
        }
        
        public int UpdateProspectIsViewable(DataTable Viewabledt, int SelectedDefaultTimeframe, int UserId)
        {
            SqlConnection cn = new SqlConnection(base.Database.Connection.ConnectionString);
            SqlCommand cmd = new SqlCommand("[dbo].[updateProspectIsViewable]", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter tvpParam = cmd.Parameters.AddWithValue("@ViewableDatatable", Viewabledt);
            tvpParam.SqlDbType = SqlDbType.Structured;
            SqlParameter tvpParam3 = cmd.Parameters.AddWithValue("@SelectedDefaultTimeframe", SelectedDefaultTimeframe);
            tvpParam3.SqlDbType = SqlDbType.Int;
            SqlParameter tvpParam4 = cmd.Parameters.AddWithValue("@UserId", UserId);
            tvpParam4.SqlDbType = SqlDbType.Int; 
            var IsScuess = 0;
            try
            {
                cn.Open();
               IsScuess= cmd.ExecuteNonQuery();
                cn.Close();
            }
            catch { }
            return IsScuess;
        }
        
        public int RestoreDefaultProspect(int UserId)
        {
            SqlConnection cn = new SqlConnection(base.Database.Connection.ConnectionString);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "[dbo].[updateProspectIsDivested]";
            cmd.Connection = cn;
            SqlParameter tvpParam4 = new SqlParameter("@UserId", UserId);
            tvpParam4.SqlDbType = SqlDbType.Int;
            cmd.Parameters.Add(tvpParam4);
            var IsScuess = 0;
            try
            {
                cn.Open();
                IsScuess = cmd.ExecuteNonQuery();
                cn.Close();
            }
            catch { 
            }
            return IsScuess;
        } 
        
        public static string convertToXMLFormat(string inputString)
        {
            if (inputString == "") return "";
            List<string> lst = inputString.Split(',').ToList();
            XElement xmlElements = new XElement("typeTables", lst.Select(i => new XElement("typeTable", new XElement("Item", i))));
            return xmlElements.ToString();
        }

        public static string GetLockedWellNamesForLease(int LeaseID, LockWell ByLeaseId)
        {
            var LockedWellNames = string.Empty;
            using (var db = new ogwmEntities())
            {
                var cmd = db.Database.Connection.CreateCommand();
                cmd.CommandText = "[dbo].[GetLockedWellsNameForLease]";// '" + LeaseNo + "'," + LeasId + "," + RoleId;
                cmd.CommandType = CommandType.StoredProcedure;
                System.Data.Common.DbParameter param1 = cmd.CreateParameter();
                param1 = cmd.CreateParameter();
                param1.ParameterName = "@LeaseId";
                param1.DbType = DbType.String;
                param1.Value = LeaseID;
                cmd.Parameters.Add(param1);
                var param2 = cmd.CreateParameter();
                param2.ParameterName = "@ByLeaseId";
                param2.DbType = DbType.Int32;
                param2.Value = (int)ByLeaseId;
                cmd.Parameters.Add(param2);

                try
                {
                    db.Database.Connection.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        LockedWellNames = (from n in ((IObjectContextAdapter)db).ObjectContext.Translate<string>(reader) select n).FirstOrDefault();
                    }
                    return LockedWellNames;
                }
                catch (Exception)
                {
                    //ignored 
                    return LockedWellNames;
                }
            }


        }

        ~ExcuteTableValuedSP()
        {
           //GC.SuppressFinalize(this);
        }
    
    }
}
