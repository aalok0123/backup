﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Configuration;
using System.Web;
using System.Security.Cryptography;
using System.IO;
using System.Web.Mvc;
using System.IO.Compression;

namespace OGWM.Data.Common
{
    public class CommonClass
    {
        public static string AttachmentType;
        public static string GetDefaultCounty
        {
            get
            {
                return WebConfigurationManager.AppSettings["DefaultCountyCode"].ToString();
            }
        }
        public static string GetDateFormat
        {
            get
            {
                return WebConfigurationManager.AppSettings["DateFormat"].ToString();
            }
        }
        public static string GetMailHost
        {
            get
            {
                return WebConfigurationManager.AppSettings["MailHost"].ToString();
            }
        }
        public static int GetMailPort
        {
            get
            {
                return Convert.ToInt32(WebConfigurationManager.AppSettings["MailPort"].ToString());
            }
        }
        public static string DefaultMailFrom
        {
            get
            {
                return WebConfigurationManager.AppSettings["MailFrom"].ToString();
            }
        }
        public static string DefaultMailFromPassword
        {
            get
            {
                return WebConfigurationManager.AppSettings["MailFromPassword"].ToString();
            }
        }
        public static string DefaultRecieverMailSeperator
        {
            get
            {
                return WebConfigurationManager.AppSettings["RecieverMailSeperator"].ToString();
            }
        }
        public static bool IsSSLOrTSLEnabled
        {
            get
            {
                return Convert.ToBoolean(WebConfigurationManager.AppSettings["IsSSLOrTSLEnabled"].ToString());
            }
        }
        public static string GetCommonUrlLeftPart
        {
            get
            {
                String strPathAndQuery = HttpContext.Current.Request.Url.PathAndQuery;
                return HttpContext.Current.Request.Url.AbsoluteUri.Replace(strPathAndQuery, "");
            }
        }
        public static string adConnectionString
        {
            get
            {
                var webcon = WebConfigurationManager.ConnectionStrings;
                return webcon["ADService"].ConnectionString;
            }
        }
        public static string adServer
        {
            get
            {
                return WebConfigurationManager.AppSettings["ADServer"].ToString();
            }
        }
        public static string adAdmin
        {
            get
            {
                return WebConfigurationManager.AppSettings["ADUser"].ToString();
            }
        }
        public static string adAdminPassword
        {
            get
            {
                return WebConfigurationManager.AppSettings["ADPassword"].ToString();
            }
        }
        public static bool IsActiveDirectoryLogin
        {
            get
            {
                return Convert.ToBoolean(WebConfigurationManager.AppSettings["IsActiveDirectoryLogin"]);
            }
        }
        public static string GetEnvironment
        {
            get
            {
                if (WebConfigurationManager.AppSettings["environment"] != null)
                {
                    return Convert.ToString(WebConfigurationManager.AppSettings["environment"]);
                }
                else
                {
                    return "";
                }

            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////
        ////Added on 19.09.2013 as these properties of web config are required in creating plat/////////
        ////Map images//////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////
        public static string ConnectionString
        {
            get
            {
                return WebConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;
            }
        }
        public static int ImageWidth
        {
            get
            {
                if (WebConfigurationManager.AppSettings["ImageWidth"] != null)
                    return Convert.ToInt32(WebConfigurationManager.AppSettings["ImageWidth"].ToString());
                else
                    return 800;
            }
        }
        public static int ImageHeight
        {
            get
            {
                if (WebConfigurationManager.AppSettings["ImageHeight"] != null)
                    return Convert.ToInt32(WebConfigurationManager.AppSettings["ImageHeight"].ToString());
                else return 600;
            }
        }
        public static bool IsLocalLogin
        {
            get
            {
                return Convert.ToBoolean(WebConfigurationManager.AppSettings["IsLocalLogin"]);
            }
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////

    }
    public class NoCache : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            filterContext.HttpContext.Response.Cache.SetExpires(DateTime.UtcNow.AddDays(-1));
            filterContext.HttpContext.Response.Cache.SetValidUntilExpires(false);
            filterContext.HttpContext.Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches);
            filterContext.HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            filterContext.HttpContext.Response.Cache.SetNoStore();
            base.OnActionExecuting(filterContext);
        }
    }
    public class SurfaceOwnerData
    {
        public int OwnersID { get; set; }
        public int SurfaceOwnerID { get; set; }
        public string OwnerName { get; set; }
        public decimal InterestPer { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string StateName { get; set; }
        public string CityName { get; set; }
        public string ZipCode { get; set; }
        public int? StateID { get; set; }
        public string State { get; set; }
        public int? CountyID { get; set; }
        public string Block { get; set; }
        public string Section { get; set; }
        public string Survey { get; set; }
        public string Abstract { get; set; }
    }
    public class selectItem
    {
        public string Value { get; set; }
        public string Text { get; set; }
    }

    public class SplittractLeases
    {
        public int LeaseID { get; set; }
        public string LeaseNo { get; set; }
    }
    public class selectUserMaster
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public DateTime? FirstLoginDate { get; set; }
        public DateTime? LastLoginDate { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsAdmin { get; set; }
        public string GroupName { get; set; }
    }
    public class Production_Well
    {
        public Int32 EntityId { get; set; }
        public string WellName { get; set; }
        public string Operator { get; set; }
        public string Status { get; set; }
        public Double Oil { get; set; }
        public Double Gas { get; set; }
        public Double Water { get; set; }
        public Int32 NRI { get; set; }
        public Double NetOil { get; set; }
        public Double NetGas { get; set; }
        public Int32 TubingPressure { get; set; }
        public Int32 CasingPressure { get; set; }
        public DateTime docDate { get; set; }
    }

    public class Production_WellFilter
    {
        public string ProspectID { get; set; }
        public string BatteryID { get; set; }
        public string WellId { get; set; }
        public string Operator { get; set; }
        public string DateFrom { get; set; }
        public string DateTo { get; set; }
        public string Month { get; set; }
        public string Year { get; set; }
        public int WellType { get; set; }
    }
    //public class Production_WellFilter_WellType
    //{
    //    public string ProspectID { get; set; }
    //    public string BatteryID { get; set; }
    //    public string WellId { get; set; }
    //    public string Operator { get; set; }
    //    public string DateFrom { get; set; }
    //    public string DateTo { get; set; }
    //    public string Month { get; set; }
    //    public string Year { get; set; }
    //    public int? WellType { get; set; }
    //}
    public class Production_WellMainTabFilter
    {
        public string Operator { get; set; }
        public string WellSiteId { get; set; }
        public string DateFrom { get; set; }
        public string DateTo { get; set; }
        public string Month { get; set; }
        public string Year { get; set; }
    }
    public class Production_Batteries
    {
        public Int32 GatheringSiteID { get; set; }
        public Int32 PropertyID { get; set; }
        public string Battery { get; set; }
        public string Operator { get; set; }
        public string Status { get; set; }
        public Double Oil { get; set; }
        public Double Gas { get; set; }
        public Double Water { get; set; }
        public DateTime docDate { get; set; }
    }

    public class Encryption
    {
        #region encryption/decryption

        #region Fields

        private static byte[] key = { };
        private static byte[] IV = { 38, 55, 206, 48, 28, 64, 20, 16 };
        private static string stringKey = "!5663a#KN";

        #endregion

        #region Public Methods

        public static string Encrypt(string text)
        {
            try
            {
                key = Encoding.UTF8.GetBytes(stringKey.Substring(0, 8));

                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                Byte[] byteArray = Encoding.UTF8.GetBytes(text);

                MemoryStream memoryStream = new MemoryStream();
                CryptoStream cryptoStream = new CryptoStream(memoryStream,
                    des.CreateEncryptor(key, IV), CryptoStreamMode.Write);

                cryptoStream.Write(byteArray, 0, byteArray.Length);
                cryptoStream.FlushFinalBlock();

                return Convert.ToBase64String(memoryStream.ToArray());
            }
            catch 
            {
                // Handle Exception Here
            }

            return string.Empty;
        }

        public static string Decrypt(string text)
        {
            try
            {
                key = Encoding.UTF8.GetBytes(stringKey.Substring(0, 8));

                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                Byte[] byteArray = Convert.FromBase64String(text);

                MemoryStream memoryStream = new MemoryStream();
                CryptoStream cryptoStream = new CryptoStream(memoryStream,
                    des.CreateDecryptor(key, IV), CryptoStreamMode.Write);

                cryptoStream.Write(byteArray, 0, byteArray.Length);
                cryptoStream.FlushFinalBlock();

                return Encoding.UTF8.GetString(memoryStream.ToArray());
            }
            catch 
            {
                // Handle Exception Here
            }

            return string.Empty;
        }

        #endregion

        #endregion

    }
    
    public class CompressAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            var encodingsAccepted = filterContext.HttpContext.Request.Headers["Accept-Encoding"];
            if (string.IsNullOrEmpty(encodingsAccepted)) return;

            encodingsAccepted = encodingsAccepted.ToLowerInvariant();
            var response = filterContext.HttpContext.Response;
            if (encodingsAccepted.Contains("gzip"))
            {
                response.AppendHeader("Content-encoding", "gzip");
                response.Filter = new GZipStream(response.Filter, CompressionMode.Compress);
            }
            else if (encodingsAccepted.Contains("deflate"))
            {
                response.AppendHeader("Content-encoding", "deflate");
                response.Filter = new DeflateStream(response.Filter, CompressionMode.Compress);
            }
        }
    }
}
