﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OGWM.UI.Common
{
    public static class Entity
    {
        public static string Prospect 
        { 
            get 
            { 
                return "Prospects"; 
            } 
        }
        public static string Lease
        {
            get
            {
                return "Lease";
            }
        }
        public static string Well
        {
            get
            {
                return "Wells";
            }
        }
        public static string Facility
        {
            get
            {
                return "Facility";
            }
        }
        public static string SurfacewOwner
        {
            get
            {
                return "SurfaceOwnership";
            }
        }
        
    }
}