﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using OfficeOpenXml;
using OGWM.Entities;
using OGWM.ViewModel;
using System.Data;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text;
using System.Linq;
using MoreLinq;

namespace OGWM.UI.Common
{
    public partial class ExcelHelper
    {
        private static void CheckFile(DirectoryInfo outputDir, string filename)
        {
            if (!outputDir.Exists)
            {
                outputDir.Create();
            }
            FileInfo newFile = new FileInfo(outputDir.FullName + @"\" + filename);
            if (newFile.Exists)
            {
                newFile.Delete();
                newFile = new FileInfo(outputDir.FullName + @"\" + filename);
            }
        }

        public static string LeaseMineralInterest(List<GetMineralInterestDetailInfo> lData, DirectoryInfo outputDir, string filename)
        {
            filename = filename.Replace(" ", "");
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("MineralInterest Percentage Detail");
                worksheet.Column(1).Width = 15;
                worksheet.Column(2).Width = 25;
                worksheet.Column(3).Width = 12;
                worksheet.Column(4).Width = 100;
                //worksheet.Cells[1, 1].Value = "LeaseID";
                worksheet.Cells[1, 1].Value = "Lease No";
                worksheet.Cells[1, 2].Value = "Mineral Interest Percentage";
                worksheet.Cells[1, 3].Value = "Sub Section";
                worksheet.Cells[1, 4].Value = "Description";
                int i = 1;
                foreach (var pew in lData)
                {
                    //worksheet.Cells["A" + (i + 1).ToString()].Value = pew.LeaseID;
                    worksheet.Cells["A" + (i + 1).ToString()].Value = pew.LeaseNo;
                    worksheet.Cells["B" + (i + 1).ToString()].Value = pew.MineralInterestPercentage;
                    worksheet.Cells["C" + (i + 1).ToString()].Value = pew.SectionForProspect;
                    worksheet.Cells["D" + (i + 1).ToString()].Value = pew.Description;
                    i++;
                }
                worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Production Tab Well Screen Data";
                // Add the page number to the right of the footer + total number of pages
                worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                // Add the sheet name to center of the footer
                worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                // Add the filepath to the left of the footer
                worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:1"];
                worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:D"];
                // Setting some document properties
                package.Workbook.Properties.Title = "MineralInterest Percentage Detail";
                package.Workbook.Properties.Author = "OGWM";
                package.Workbook.Properties.Comments = "MineralInterest Percentage Detail";
                package.Save();
            }
            //Write the workbook to a memory stream

            return newFile.FullName;
        }

        public static string ProductionTabWellScreenDataList(List<GetProductionTabWellScreenDataInfo> lData, DirectoryInfo outputDir, string filename)
        {
            filename = filename.Replace(" ", "");
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Production Tab Well Screen Data");
                worksheet.Cells[1, 1].Value = "Date";
                //worksheet.Cells[1, 2].Value = "WellSiteId";
                //worksheet.Cells[1, 3].Value = "ProductionPtId";
                worksheet.Cells[1, 2].Value = "Gross Oil";
                worksheet.Cells[1, 3].Value = "Gross Gas";
                worksheet.Cells[1, 4].Value = "Gross Water";
                worksheet.Cells[1, 5].Value = "Tubing Pressure";
                worksheet.Cells[1, 6].Value = "Casing Pressure";
                worksheet.Cells[1, 7].Value = "Choke";
                int i = 1;
                foreach (var pew in lData)
                {
                    worksheet.Cells["A" + (i + 1).ToString()].Value = pew.docDate ?? System.DateTime.Now;
                    worksheet.Cells["B" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.Oil), 4);
                    worksheet.Cells["C" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.Gas), 4);
                    worksheet.Cells["D" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.Water), 4);
                    worksheet.Cells["E" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.TubingPressure), 4);
                    worksheet.Cells["F" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.CasingPressure), 4);
                    worksheet.Cells["G" + (i + 1).ToString()].Value = pew.ChokeSize;
                    i++;
                }
                // Formatting style of the header
                using (var range = worksheet.Cells[1, 1, 1, 7])
                {
                    range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Font.Bold = true;// Setting bold font                    
                    range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                    range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                    range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                }
                // //Setting Number Format...
                // //Setting integer format for the column 'Quantity' and Setting decimal format for the column 'Price' and 'Value'
                worksheet.Cells["A2:A" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";// Setting date format
                //worksheet.Cells["B2:F" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0.00";
                worksheet.Cells["G2:G" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                // Setting AutoFit for all cells
                worksheet.Cells.AutoFitColumns(0);
                // Lets set the header text
                worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Production Tab Well Screen Data";
                // Add the page number to the right of the footer + total number of pages
                worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                // Add the sheet name to center of the footer
                worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                // Add the filepath to the left of the footer
                worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:1"];
                worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:G"];
                // Setting some document properties
                package.Workbook.Properties.Title = "Production Tab Well Screen Data";
                package.Workbook.Properties.Author = "OGWM";
                package.Workbook.Properties.Comments = "Production Tab Well Screen Data";
                package.Save();
            }
            //Write the workbook to a memory stream

            return newFile.FullName;
        }

        public static string ProductionExplorerWellDataList(List<GetProductionExplorerWellDataInfo> lProductionExplorerWell, DirectoryInfo outputDir)
        {
            string filename = @"\ProductionExplorerWell" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);

            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Production Explorer Well Report");
                // Add the headers
                worksheet.Cells[1, 1].Value = "Date";
                worksheet.Cells[1, 2].Value = "Well Type";
                worksheet.Cells[1, 3].Value = "Well Name";
                worksheet.Cells[1, 4].Value = "API";
                worksheet.Cells[1, 5].Value = "Operator";
                worksheet.Cells[1, 6].Value = "Status";
                worksheet.Cells[1, 7].Value = "Gross Oil";
                worksheet.Cells[1, 8].Value = "Gross Gas";
                worksheet.Cells[1, 9].Value = "Gross Water";
                worksheet.Cells[1, 10].Value = "NRI";
                worksheet.Cells[1, 11].Value = "Net Oil";
                worksheet.Cells[1, 12].Value = "Net Gas";
                worksheet.Cells[1, 13].Value = "Tubing Pressure";
                worksheet.Cells[1, 14].Value = "Casing Pressure";
                worksheet.Cells[1, 15].Value = "Choke";
                worksheet.Cells[1, 16].Value = "Pressure Notes";
                // Inserting values in the first row for: ID, Product, Quantity & Price respectively
                int i = 1;
                foreach (var pew in lProductionExplorerWell)
                {
                    worksheet.Cells["A" + (i + 1).ToString()].Value = pew.docDate ?? System.DateTime.Now;
                    worksheet.Cells["B" + (i + 1).ToString()].Value = pew.WellType;
                    worksheet.Cells["C" + (i + 1).ToString()].Value = pew.WellName;
                    worksheet.Cells["D" + (i + 1).ToString()].Value = pew.APINumber;
                    worksheet.Cells["E" + (i + 1).ToString()].Value = pew.OperatorName;
                    worksheet.Cells["F" + (i + 1).ToString()].Value = pew.TitleName;
                    worksheet.Cells["G" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.Oil), 4);
                    worksheet.Cells["H" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.Gas), 4);
                    worksheet.Cells["I" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.Water), 4);
                    worksheet.Cells["J" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.NRI), 4);
                    worksheet.Cells["K" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.NetOil), 4);
                    worksheet.Cells["L" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.NetGas), 4);
                    worksheet.Cells["M" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.TubingPressure), 4);
                    worksheet.Cells["N" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.CasingPressure), 4);
                    worksheet.Cells["O" + (i + 1).ToString()].Value = pew.Choke;
                    worksheet.Cells["P" + (i + 1).ToString()].Value = pew.PressureNotes;
                    i++;
                }
                // Adding formula to the column 'Value' //worksheet.Cells["E2:E" + (i + 1).ToString()].Formula = "C2*D2";
                // Formatting style of the header
                using (var range = worksheet.Cells[1, 1, 1, 16])
                {
                    range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Font.Bold = true;// Setting bold font                    
                    range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                    range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                    range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                }

                // Formatting the footer row
                // Setting top border of the footer row
                //worksheet.Cells["A" + (i + 1).ToString() + ":M" + (i + 1).ToString()].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                // Setting font bold of the footer row
                //worksheet.Cells["A" + (i + 1).ToString() + ":M" + (i + 1).ToString()].Style.Font.Bold = true;

                // //Setting Number Format...
                // //Setting integer format for the column 'Quantity' and Setting decimal format for the column 'Price' and 'Value'
                worksheet.Cells["A2:A" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";// Setting date format
                worksheet.Cells["B2:F" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                //worksheet.Cells["C2:C" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0";	// Setting integer format
                //worksheet.Cells["F2:M" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0.00";
                worksheet.Cells["O2:P" + (i + 1).ToString()].Style.Numberformat.Format = "@";

                //// Creating an Auto Filter for the range
                //worksheet.Cells["A1:F" + (i).ToString()].AutoFilter = true;

                // Setting AutoFit for all cells
                worksheet.Cells.AutoFitColumns(0);
                // Lets set the header text
                worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Production Explorer Well Report";
                // Add the page number to the right of the footer + total number of pages
                worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                // Add the sheet name to center of the footer
                worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                // Add the filepath to the left of the footer
                worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:1"];
                worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:O"];
                // Change the sheet view to show it in page layout mode
                //worksheet.View.PageLayoutView = true;


                // Setting some document properties
                package.Workbook.Properties.Title = "Production Explorer Well Report";
                package.Workbook.Properties.Author = "OGWM";
                package.Workbook.Properties.Comments = "Production Explorer Well Report";
                //// set some extended property values
                //package.Workbook.Properties.Company = "OGWM";
                //// set some custom property values
                //package.Workbook.Properties.SetCustomPropertyValue("Checked by", "Jan Källman");
                //package.Workbook.Properties.SetCustomPropertyValue("AssemblyName", "EPPlus");
                //// save our new workbook and we are done!
                package.Save();

            }
            return newFile.FullName;
        }

        public static string GetProductionExplorerBatteriesData(List<GetProductionExplorerBatteriesDataInfo> lProductionExplorerWell, DirectoryInfo outputDir)
        {
            string filename = @"\ProductionExplorerBatteryData" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);

            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Production Explorer Battery Report");
                // Add the headers
                worksheet.Cells[1, 1].Value = "Date";
                worksheet.Cells[1, 2].Value = "Well Type";
                worksheet.Cells[1, 3].Value = "Battery";
                worksheet.Cells[1, 4].Value = "Operator";
                worksheet.Cells[1, 5].Value = "Gross Oil";
                worksheet.Cells[1, 6].Value = "Gross Gas";
                worksheet.Cells[1, 7].Value = "Gross Water";
                // Inserting values in the first row for: ID, Product, Quantity & Price respectively
                int i = 1;
                foreach (var pew in lProductionExplorerWell)
                {
                    worksheet.Cells["A" + (i + 1).ToString()].Value = pew.DocDate ?? System.DateTime.Now;
                    worksheet.Cells["B" + (i + 1).ToString()].Value = pew.WellType;
                    worksheet.Cells["C" + (i + 1).ToString()].Value = pew.Battery;
                    worksheet.Cells["D" + (i + 1).ToString()].Value = pew.Operator;
                    worksheet.Cells["E" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.Grossoil), 4);
                    worksheet.Cells["F" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.GrossGas), 4);
                    worksheet.Cells["G" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.GrossWater), 4);
                    i++;
                }
                // Adding formula to the column 'Value' //worksheet.Cells["E2:E" + (i + 1).ToString()].Formula = "C2*D2";
                // Formatting style of the header
                using (var range = worksheet.Cells[1, 1, 1, 7])
                {
                    range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Font.Bold = true;// Setting bold font                    
                    range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                    range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                    range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                }

                // Formatting the footer row
                // Setting top border of the footer row
                //worksheet.Cells["A" + (i + 1).ToString() + ":F" + (i + 1).ToString()].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                // Setting font bold of the footer row
                //worksheet.Cells["A" + (i + 1).ToString() + ":F" + (i + 1).ToString()].Style.Font.Bold = true;

                // //Setting Number Format...
                // //Setting integer format for the column 'Quantity' and Setting decimal format for the column 'Price' and 'Value'
                worksheet.Cells["A2:A" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";// Setting date format
                worksheet.Cells["B2:D" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                //worksheet.Cells["C2:C" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0";	// Setting integer format
                //worksheet.Cells["E2:G" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0.00";
                //// Creating an Auto Filter for the range
                //worksheet.Cells["A1:F" + (i).ToString()].AutoFilter = true;

                // Setting AutoFit for all cells
                worksheet.Cells.AutoFitColumns(0);
                // Lets set the header text
                worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Production Explorer Battery Report";
                // Add the page number to the right of the footer + total number of pages
                worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                // Add the sheet name to center of the footer
                worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                // Add the filepath to the left of the footer
                worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:1"];
                worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:G"];
                // Change the sheet view to show it in page layout mode
                //worksheet.View.PageLayoutView = true;


                // Setting some document properties
                package.Workbook.Properties.Title = "Production Explorer Battery Report";
                package.Workbook.Properties.Author = "OGWM";
                package.Workbook.Properties.Comments = "Production Explorer Battery Report";
                //// set some extended property values
                //package.Workbook.Properties.Company = "OGWM";
                //// set some custom property values
                //package.Workbook.Properties.SetCustomPropertyValue("Checked by", "Jan Källman");
                //package.Workbook.Properties.SetCustomPropertyValue("AssemblyName", "EPPlus");
                //// save our new workbook and we are done!
                package.Save();

            }
            return newFile.FullName;
        }

        public static string GetProductionExplorerTicketData(List<GetProductionExplorerTicketDataInfo> lProductionExplorerWell, DirectoryInfo outputDir)
        {
            string filename = @"\ProductionExplorerTicketData" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);

            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Production Explorer Ticket Report");
                // Add the headers
                worksheet.Cells[1, 1].Value = "Date";
                worksheet.Cells[1, 2].Value = "Battery";
                worksheet.Cells[1, 3].Value = "Tank";
                worksheet.Cells[1, 4].Value = "Ticket No.";
                worksheet.Cells[1, 5].Value = "GrVol";
                worksheet.Cells[1, 6].Value = "NetVol";
                worksheet.Cells[1, 7].Value = "Start";
                worksheet.Cells[1, 8].Value = "End";
                worksheet.Cells[1, 9].Value = "Gravity";
                worksheet.Cells[1, 10].Value = "Temp";
                worksheet.Cells[1, 11].Value = "BSW";
                worksheet.Cells[1, 12].Value = "Seal Off";
                worksheet.Cells[1, 13].Value = "Seal On";
                worksheet.Cells[1, 14].Value = "STemp";
                worksheet.Cells[1, 15].Value = "ETemp";
                worksheet.Cells[1, 16].Value = "GrCarrStartVol";
                worksheet.Cells[1, 17].Value = "GrEndVol";
                worksheet.Cells[1, 18].Value = "GrCorrEndVol";
                worksheet.Cells[1, 19].Value = "BSWVol";
                worksheet.Cells[1, 20].Value = "CorrGravity";
                worksheet.Cells[1, 21].Value = "RVP Incrust";
                worksheet.Cells[1, 22].Value = "Truck No.";
                worksheet.Cells[1, 23].Value = "Notes";
                worksheet.Cells[1, 24].Value = "Input ID";
                worksheet.Cells[1, 25].Value = "Time";
                // Inserting values in the first row for: ID, Product, Quantity & Price respectively
                int i = 1;
                foreach (var fldName in lProductionExplorerWell)
                {
                    worksheet.Cells["A" + (i + 1).ToString()].Value = fldName.Date ?? System.DateTime.Now;
                    worksheet.Cells["B" + (i + 1).ToString()].Value = fldName.SiteName;
                    worksheet.Cells["C" + (i + 1).ToString()].Value = fldName.TankName;
                    worksheet.Cells["D" + (i + 1).ToString()].Value = fldName.TicketNumber;
                    worksheet.Cells["E" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.Volume), 4);
                    worksheet.Cells["F" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.NetVol), 4);
                    worksheet.Cells["G" + (i + 1).ToString()].Value = fldName.Start;
                    worksheet.Cells["H" + (i + 1).ToString()].Value = fldName.End;
                    worksheet.Cells["I" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.Gravity), 4);
                    worksheet.Cells["J" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.Temp), 4);
                    worksheet.Cells["K" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.BSW), 4);
                    worksheet.Cells["L" + (i + 1).ToString()].Value = fldName.OffSeal;
                    worksheet.Cells["M" + (i + 1).ToString()].Value = fldName.OnSeal;
                    worksheet.Cells["N" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.STemp), 4);
                    worksheet.Cells["O" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.ETemp), 4);
                    worksheet.Cells["P" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.GrCorrStartVol), 4);
                    worksheet.Cells["Q" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.GrEndVol), 4);
                    worksheet.Cells["R" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.GrCorrEndVol), 4);
                    worksheet.Cells["S" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.BSWVolume), 4);
                    worksheet.Cells["T" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.CorrGravity), 4);
                    worksheet.Cells["U" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.RVPFactor), 4);
                    worksheet.Cells["V" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(fldName.TruckNumber), 4);
                    worksheet.Cells["w" + (i + 1).ToString()].Value = fldName.Notes;
                    worksheet.Cells["x" + (i + 1).ToString()].Value = fldName.InputId;
                    worksheet.Cells["y" + (i + 1).ToString()].Value = fldName.Time;
                    i++;
                }
                // Adding formula to the column 'Value' //worksheet.Cells["E2:E" + (i + 1).ToString()].Formula = "C2*D2";
                // Formatting style of the header
                using (var range = worksheet.Cells[1, 1, 1, 25])
                {
                    range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Font.Bold = true;// Setting bold font                    
                    range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                    range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                    range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                }

                // Formatting the footer row
                // Setting top border of the footer row
                //worksheet.Cells["A" + (i + 1).ToString() + ":Y" + (i + 1).ToString()].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                // Setting font bold of the footer row
                //worksheet.Cells["A" + (i + 1).ToString() + ":Y" + (i + 1).ToString()].Style.Font.Bold = true;

                // //Setting Number Format...
                // //Setting integer format for the column 'Quantity' and Setting decimal format for the column 'Price' and 'Value'
                worksheet.Cells["A2:A" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";// Setting date format
                worksheet.Cells["B2:D" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                worksheet.Cells["G2:H" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                worksheet.Cells["L2:M" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                worksheet.Cells["W2:Y" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                //worksheet.Cells["C2:C" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0";	// Setting integer format
                worksheet.Cells["E2:F" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0.00";
                worksheet.Cells["N2:V" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0.00";
                //// Creating an Auto Filter for the range
                //worksheet.Cells["A1:F" + (i).ToString()].AutoFilter = true;

                // Setting AutoFit for all cells
                worksheet.Cells.AutoFitColumns(0);
                // Lets set the header text
                worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Production Explorer Ticket Report";
                // Add the page number to the right of the footer + total number of pages
                worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                // Add the sheet name to center of the footer
                worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                // Add the filepath to the left of the footer
                worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:1"];
                worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:Y"];
                // Change the sheet view to show it in page layout mode
                //worksheet.View.PageLayoutView = true;


                // Setting some document properties
                package.Workbook.Properties.Title = "Production Explorer Ticket Report";
                package.Workbook.Properties.Author = "OGWM";
                package.Workbook.Properties.Comments = "Production Explorer Ticket Report";
                //// set some extended property values
                //package.Workbook.Properties.Company = "OGWM";
                //// set some custom property values
                //package.Workbook.Properties.SetCustomPropertyValue("Checked by", "Jan Källman");
                //package.Workbook.Properties.SetCustomPropertyValue("AssemblyName", "EPPlus");
                //// save our new workbook and we are done!
                package.Save();
            }
            return newFile.FullName;
        }

        public static string GetProductionExplorerTicketData(List<GetProductionDispositionInfo> lProductionExplorerWell, DirectoryInfo outputDir)
        {
            string filename = @"\ProductionExplorerDispositionData" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".xlsx";
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);

            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Production Explorer Disposition Report");
                // Add the headers
                worksheet.Cells[1, 1].Value = "Date";
                worksheet.Cells[1, 2].Value = "Battery";
                worksheet.Cells[1, 3].Value = "Tank";
                worksheet.Cells[1, 4].Value = "Reason";
                worksheet.Cells[1, 5].Value = "Start";
                worksheet.Cells[1, 6].Value = "End";
                worksheet.Cells[1, 7].Value = "Vol";
                worksheet.Cells[1, 8].Value = "Seal Off";
                worksheet.Cells[1, 9].Value = "Seal On";
                worksheet.Cells[1, 10].Value = "Valve";
                worksheet.Cells[1, 11].Value = "Notes";
                worksheet.Cells[1, 12].Value = "Last Changed";
                worksheet.Cells[1, 13].Value = "Input ID";
                // Inserting values in the first row for: ID, Product, Quantity & Price respectively
                int i = 1;
                foreach (var pew in lProductionExplorerWell)
                {
                    worksheet.Cells["A" + (i + 1).ToString()].Value = pew.Date ?? System.DateTime.Now;
                    worksheet.Cells["B" + (i + 1).ToString()].Value = pew.Battery;
                    worksheet.Cells["C" + (i + 1).ToString()].Value = pew.TankName;
                    worksheet.Cells["D" + (i + 1).ToString()].Value = pew.OilDispReason;
                    worksheet.Cells["E" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.Start), 4);
                    worksheet.Cells["F" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.End), 4);
                    worksheet.Cells["g" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.Vol), 4);
                    worksheet.Cells["H" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.OffSeal), 4);
                    worksheet.Cells["I" + (i + 1).ToString()].Value = Math.Round(Convert.ToDecimal(pew.OnSeal), 4);
                    worksheet.Cells["J" + (i + 1).ToString()].Value = pew.ValveType;
                    worksheet.Cells["K" + (i + 1).ToString()].Value = pew.Notes;
                    worksheet.Cells["L" + (i + 1).ToString()].Value = pew.Stamp;
                    worksheet.Cells["M" + (i + 1).ToString()].Value = pew.InputByID;
                    i++;
                }
                // Adding formula to the column 'Value' //worksheet.Cells["E2:E" + (i + 1).ToString()].Formula = "C2*D2";
                // Formatting style of the header
                using (var range = worksheet.Cells[1, 1, 1, 13])
                {
                    range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Font.Bold = true;// Setting bold font                    
                    range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                    range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                    range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                }

                // Formatting the footer row
                // Setting top border of the footer row
                //worksheet.Cells["A" + (i + 1).ToString() + ":D" + (i + 1).ToString()].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                // Setting font bold of the footer row
                //worksheet.Cells["A" + (i + 1).ToString() + ":F" + (i + 1).ToString()].Style.Font.Bold = true;

                // //Setting Number Format...
                // //Setting integer format for the column 'Quantity' and Setting decimal format for the column 'Price' and 'Value'
                worksheet.Cells["A2:A" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";// Setting date format
                worksheet.Cells["L2:L" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";// Setting date format
                worksheet.Cells["B2:D" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                //worksheet.Cells["C2:C" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0";	// Setting integer format
                //worksheet.Cells["E2:I" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0.00";

                worksheet.Cells["J2:K" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                worksheet.Cells["M2:M" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                //// Creating an Auto Filter for the range
                //worksheet.Cells["A1:F" + (i).ToString()].AutoFilter = true;

                // Setting AutoFit for all cells
                worksheet.Cells.AutoFitColumns(0);
                // Lets set the header text
                worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Production Explorer Disposition Report";
                // Add the page number to the right of the footer + total number of pages
                worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                // Add the sheet name to center of the footer
                worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                // Add the filepath to the left of the footer
                worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:1"];
                worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:M"];
                // Change the sheet view to show it in page layout mode
                //worksheet.View.PageLayoutView = true;
                // Setting some document properties
                package.Workbook.Properties.Title = "Production Explorer Disposition Report";
                package.Workbook.Properties.Author = "OGWM";
                package.Workbook.Properties.Comments = "Production Explorer Disposition Report";
                //// set some extended property values
                //package.Workbook.Properties.Company = "OGWM";
                //// set some custom property values
                //package.Workbook.Properties.SetCustomPropertyValue("Checked by", "Jan Källman");
                //package.Workbook.Properties.SetCustomPropertyValue("AssemblyName", "EPPlus");
                //// save our new workbook and we are done!
                package.Save();

            }
            return newFile.FullName;
        }

        public static string ExcelWellContactDetailList(List<GetWellContactMasterDetailInfo> lData, DirectoryInfo outputDir, string filename)
        {
            filename = filename.Replace(" ", "");
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Excel Well Contact Detail");
                worksheet.Cells[1, 1].Value = "Company Name";
                worksheet.Cells[1, 2].Value = "Company Type Name";
                worksheet.Cells[1, 3].Value = "Email";
                worksheet.Cells[1, 4].Value = "Name";
                worksheet.Cells[1, 5].Value = "Phone";
                worksheet.Cells[1, 6].Value = "Position";
                worksheet.Cells[1, 7].Value = "Cel No";
                worksheet.Cells[1, 8].Value = "Home No";
                worksheet.Cells[1, 9].Value = "Office No";
                worksheet.Cells[1, 10].Value = "Other No";
                int i = 1;
                foreach (var pew in lData)
                {
                    worksheet.Cells["A" + (i + 1).ToString()].Value = pew.CompanyName;
                    worksheet.Cells["B" + (i + 1).ToString()].Value = pew.CompanyTypeName;
                    worksheet.Cells["C" + (i + 1).ToString()].Value = pew.Email;
                    worksheet.Cells["D" + (i + 1).ToString()].Value = pew.Name;
                    worksheet.Cells["E" + (i + 1).ToString()].Value = pew.Phone;
                    worksheet.Cells["F" + (i + 1).ToString()].Value = pew.Position;
                    worksheet.Cells["G" + (i + 1).ToString()].Value = pew.CelNo;
                    worksheet.Cells["H" + (i + 1).ToString()].Value = pew.HomeNo;
                    worksheet.Cells["I" + (i + 1).ToString()].Value = pew.OfficeNo;
                    worksheet.Cells["J" + (i + 1).ToString()].Value = pew.OtherNo;
                    i++;
                }
                // Formatting style of the header
                using (var range = worksheet.Cells[1, 1, 1, 10])
                {
                    range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    range.Style.Font.Bold = true;// Setting bold font                    
                    range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                    range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                    range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                }
                // //Setting Number Format...
                // //Setting integer format for the column 'Quantity' and Setting decimal format for the column 'Price' and 'Value'
                worksheet.Cells["A2:J" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                // Setting AutoFit for all cells
                worksheet.Cells.AutoFitColumns(0);
                // Lets set the header text
                worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Excel Well Contact Detail";
                // Add the page number to the right of the footer + total number of pages
                worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                // Add the sheet name to center of the footer
                worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                // Add the filepath to the left of the footer
                worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:1"];
                worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:J"];
                // Setting some document properties
                package.Workbook.Properties.Title = "Excel Well Contact Detail";
                package.Workbook.Properties.Author = "OGWM";
                package.Workbook.Properties.Comments = "Excel Well Contact Detail";
                package.Save();
            }
            //Write the workbook to a memory stream

            return newFile.FullName;
        }

        public static byte[] ExibhitAreportExport(ExhibitReport er, string filename, string filepath)
        {
            byte[] output = new byte[] { };
            if (er.lExhibitReportInfo.Count > 0)
            {
                DirectoryInfo outputDir = new DirectoryInfo(filepath);
                filename = filename.Replace(" ", "");
                CheckFile(outputDir, filename);
                FileInfo newFile = new FileInfo(outputDir.FullName + filename);
                using (ExcelPackage package = new ExcelPackage())
                {
                    try
                    {
                        ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(filename);
                        worksheet.PrinterSettings.PaperSize = ePaperSize.Letter;
                        worksheet.PrinterSettings.Orientation = eOrientation.Landscape;
                        int colIndex = 0;
                        int rowIndex = 1;
                        //worksheet.Cells[1,1].Value = er.h1;
                        using (ExcelRange rng = worksheet.Cells[rowIndex, 1, rowIndex, er.lColumns.Count])
                        {
                            rng.Merge = true;
                            rng.Value = er.h1;
                            rng.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.None;
                            rng.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.None;
                            rng.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            rng.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            rng.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;
                            rng.Style.Font.Bold = false;// Setting bold font                    
                            rng.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                            rng.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                            rng.Style.Font.Color.SetColor(Color.Black); // Setting font color
                        }
                        rowIndex++;

                        using (ExcelRange rng = worksheet.Cells[rowIndex, 1, rowIndex, er.lColumns.Count])
                        {
                            rng.Merge = true;
                            //rng.Value = er.h2;
                            rng.IsRichText = true;
                            //rng.RichText.Add(CleanText(er.h2));//er.h2
                            if (er.h2.EndsWith("<br/><br/>"))
                                er.h2 = er.h2.Remove(er.h2.LastIndexOf("<br/><br/>"));
                            List<IElement> htmlarraylist = HTMLWorker.ParseToList(new StringReader(er.h2), null);
                            for (int k = 0; k < htmlarraylist.Count; k++)
                            {
                                rng.RichText.Add(((IElement)htmlarraylist[k]).Chunks[0].Content);
                            }
                            rng.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.None;
                            rng.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.None;
                            rng.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            rng.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            rng.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;

                        }
                        rowIndex++;
                        using (ExcelRange rng = worksheet.Cells[rowIndex, 1, rowIndex, er.lColumns.Count])
                        {
                            rng.Merge = true;
                            rng.Value = er.h3;
                            rng.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.None;
                            rng.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.None;
                            rng.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            rng.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                            rng.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;
                            rng.Style.Font.Bold = false;// Setting bold font                    
                            rng.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                            rng.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                            rng.Style.Font.Color.SetColor(Color.Black); // Setting font color
                        }
                        rowIndex++;
                        colIndex = 0;
                        foreach (var c in er.lColumns)
                        {
                            colIndex++;
                            worksheet.Cells[rowIndex, colIndex].Value = c.title;
                            if (c.field == "LeaseNo") { worksheet.Column(colIndex).Width = 12; }
                            else if (c.field == "Lessee") { worksheet.Column(colIndex).Width = 40; }
                            else if (c.field == "Lessor") { worksheet.Column(colIndex).Width = 40; }
                            else if (c.field == "EffectiveDate") { worksheet.Column(colIndex).Width = 12; }
                            else if (c.field == "Book") { worksheet.Column(colIndex).Width = 10; }
                            else if (c.field == "Page") { worksheet.Column(colIndex).Width = 10; }
                            else if (c.field == "File") { worksheet.Column(colIndex).Width = 10; }
                            else if (c.field == "NetAcres") { worksheet.Column(colIndex).Width = 12; }
                            else if (c.field == "GrossAcres") { worksheet.Column(colIndex).Width = 12; }
                            else if (c.field == "Description") { worksheet.Column(colIndex).Width = 80; }
                        }
                        int Rowi = rowIndex;
                        rowIndex++;
                        foreach (var r in er.lExhibitReportInfo)
                        {
                            colIndex = 0;
                            foreach (var c in er.lColumns)
                            {
                                colIndex++;
                                //LeaseID,LeaseNo,Lessee,Lessor,EffectiveDate,Book,Page,File,NetAcres,GrossAcres,Description
                                worksheet.Cells[rowIndex, colIndex].Style.Numberformat.Format = "@";
                                worksheet.Cells[rowIndex, colIndex].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;
                                worksheet.Cells[rowIndex, colIndex].Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Top;
                                if (c.field == "LeaseNo")
                                {
                                    worksheet.Cells[rowIndex, colIndex].Value = r.LeaseNo;
                                    //worksheet.Column(colIndex).Width = 9;
                                }
                                else if (c.field == "Lessee")
                                {
                                    worksheet.Cells[rowIndex, colIndex].Value = r.Lessee;
                                    //worksheet.Column(colIndex).Width = 9;
                                }
                                else if (c.field == "Lessor")
                                {
                                    worksheet.Cells[rowIndex, colIndex].Value = r.Lessor;
                                    //worksheet.Column(colIndex).Width = 9;
                                }
                                else if (c.field == "EffectiveDate")
                                {
                                    worksheet.Cells[rowIndex, colIndex].Value = r.EffectiveDate.HasValue ? r.EffectiveDate.Value.ToString("MM/dd/yyyy") : "";
                                    worksheet.Cells[rowIndex, colIndex].Style.Numberformat.Format = "MM/dd/yyyy";
                                }
                                else if (c.field == "Book") { worksheet.Cells[rowIndex, colIndex].Value = r.Book; }
                                else if (c.field == "Page") { worksheet.Cells[rowIndex, colIndex].Value = r.Page; }
                                else if (c.field == "File") { worksheet.Cells[rowIndex, colIndex].Value = r.File; }
                                else if (c.field == "NetAcres")
                                {
                                    worksheet.Cells[rowIndex, colIndex].Value = r.NetAcres;
                                    worksheet.Cells[rowIndex, colIndex].Style.Numberformat.Format = "#,##0.####";
                                    worksheet.Cells[rowIndex, colIndex].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                                }
                                else if (c.field == "GrossAcres")
                                {
                                    worksheet.Cells[rowIndex, colIndex].Value = r.GrossAcres;
                                    worksheet.Cells[rowIndex, colIndex].Style.Numberformat.Format = "#,##0.##";
                                    worksheet.Cells[rowIndex, colIndex].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                                }
                                else if (c.field == "Description")
                                {
                                    worksheet.Cells[rowIndex, colIndex].Value = r.Description;
                                    //worksheet.Cells[rowIndex, colIndex].Style.WrapText = true;
                                }
                            }
                            rowIndex++;
                        }
                        colIndex = 0;
                        //foreach (var c in er.lColumns)
                        //{
                        //    colIndex++;
                        //    if (c.field == "LeaseNo") { worksheet.Cells[ExcelColumn[colIndex] + Rowi + ":" + ExcelColumn[colIndex] + (rowIndex).ToString()].Style.Numberformat.Format = "@"; }
                        //    else if (c.field == "Lessee") { worksheet.Cells[ExcelColumn[colIndex] + Rowi + ":" + ExcelColumn[colIndex] + (rowIndex).ToString()].Style.Numberformat.Format = "@"; }
                        //    else if (c.field == "Lessor") { worksheet.Cells[ExcelColumn[colIndex] + Rowi + ":" + ExcelColumn[colIndex] + (rowIndex).ToString()].Style.Numberformat.Format = "@"; }
                        //    else if (c.field == "EffectiveDate") {
                        //        worksheet.Cells[ExcelColumn[colIndex] + Rowi + ":" + ExcelColumn[colIndex] + (rowIndex).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";
                        //    }
                        //    else if (c.field == "Book") { worksheet.Cells[ExcelColumn[colIndex] + Rowi + ":" + ExcelColumn[colIndex] + (rowIndex).ToString()].Style.Numberformat.Format = "@"; }
                        //    else if (c.field == "Page") { worksheet.Cells[ExcelColumn[colIndex] + Rowi + ":" + ExcelColumn[colIndex] + (rowIndex).ToString()].Style.Numberformat.Format = "@"; }
                        //    else if (c.field == "File") { worksheet.Cells[ExcelColumn[colIndex] + Rowi + ":" + ExcelColumn[colIndex] + (rowIndex).ToString()].Style.Numberformat.Format = "@"; }
                        //    else if (c.field == "NetAcres") { worksheet.Cells[ExcelColumn[colIndex] + Rowi + ":" + ExcelColumn[colIndex] + (rowIndex).ToString()].Style.Numberformat.Format = "#,##0.##"; }
                        //    else if (c.field == "GrossAcres") { worksheet.Cells[ExcelColumn[colIndex] + Rowi + ":" + ExcelColumn[colIndex] + (rowIndex).ToString()].Style.Numberformat.Format = "#,##0.##"; }
                        //    else if (c.field == "Description") { worksheet.Cells[ExcelColumn[colIndex] + Rowi + ":" + ExcelColumn[colIndex] + (rowIndex).ToString()].Style.Numberformat.Format = "@"; }
                        //}
                        //worksheet.Cells.AutoFitColumns(0);

                        using (var range = worksheet.Cells[4, 1, 4, er.lColumns.Count])
                        {
                            range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Font.Bold = true;// Setting bold font                    
                            range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                            range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                            range.Style.Font.Color.SetColor(Color.Black); // Setting font color  
                            range.Style.WrapText = true;
                        }
                        using (var range = worksheet.Cells[5, 1, rowIndex - 1, er.lColumns.Count])
                        {
                            range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Font.Bold = false;// Setting bold font                    
                            range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                            range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                            range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                            range.Style.WrapText = true;
                        }
                        worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Exibhit A Report";
                        // Add the page number to the right of the footer + total number of pages
                        worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                        // Add the sheet name to center of the footer
                        worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                        // Add the filepath to the left of the footer
                        worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                        // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                        worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:1"];
                        worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:" + ExcelColumn[er.lColumns.Count]];
                        // Setting some document properties
                        package.Workbook.Properties.Title = "Excel Exibhit A Report";
                        package.Workbook.Properties.Author = "OGWM";
                        package.Workbook.Properties.Comments = "Excel Exibhit A Report";
                        // package.Save();
                        output = package.GetAsByteArray();
                    }
                    catch { }
                }
            }
            return output;
        }

        public static byte[] AcreageOwnershipExport(List<GetAcreageOwnershipReportInfo> lAO, string filename, string filepath)
        {

            lAO = RefactorAcreageReportData(lAO);
            byte[] output = new byte[] { };
            DirectoryInfo outputDir = new DirectoryInfo(filepath);
            filename = filename.Replace(" ", "");
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);
            using (ExcelPackage package = new ExcelPackage())
            {
                int sheetIndex = 0;
                int sRowIndex = 0;
                int rowIndex = 0;
                int tractid = 0;
                string DeckName = string.Empty;
                string WellName = string.Empty;
                AcearageReportCheck ObjAcearageReportCheck = null;
                #region Prospects Totals
                var lProspect = lAO.Select(s => new { s.ProspectName, s.ProspectNumber }).Distinct().ToList();
                ExcelWorksheet wsps = package.Workbook.Worksheets.Add("TOTALS");
                wsps.PrinterSettings.PaperSize = ePaperSize.Letter;
                wsps.PrinterSettings.Orientation = eOrientation.Landscape;
                sRowIndex++;
                #region Prospects Column Header
                wsps.Cells[1, 1].Value = "Prospect";
                wsps.Cells[1, 2].Value = "Total Leased Acreage";
                wsps.Cells[1, 3].Value = "DBR Acreage";
                wsps.Cells[1, 4].Value = "Total HBP";
                wsps.Cells[1, 5].Value = "DBR HBP";
                using (ExcelRange rng = wsps.Cells[1, 1, 1, 5])
                {
                    rng.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.None;
                    rng.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.None;
                    rng.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    rng.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                    rng.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;
                    rng.Style.Font.Bold = true;
                    rng.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    rng.Style.Fill.BackgroundColor.SetColor(Color.White);
                    rng.Style.Font.Color.SetColor(Color.Black);
                }
                wsps.Cells[1, 3].Style.Fill.BackgroundColor.SetColor(Color.BlueViolet);
                wsps.Cells[1, 5].Style.Fill.BackgroundColor.SetColor(Color.BlueViolet);
                #endregion
                #endregion
                List<ExcelWorksheet> lwsps = new List<ExcelWorksheet>();
                foreach (var p in lProspect)
                {
                    sRowIndex++;
                    sheetIndex++;
                    rowIndex = 0;
                    ExcelWorksheet wsp = package.Workbook.Worksheets.Add(p.ProspectName + " #" + p.ProspectNumber);
                    #region Prospect Column Header
                    wsp.Cells[1, 1].Value = "Sub-Section";
                    wsp.Cells[1, 2].Value = "Section";
                    wsp.Cells[1, 3].Value = "Block";
                    wsp.Cells[1, 4].Value = "County";
                    wsp.Cells[1, 5].Value = "Gross Acres";
                    wsp.Cells[1, 6].Value = "Leased Acres";
                    wsp.Cells[1, 7].Value = "HBP Acres";
                    wsp.Cells[1, 8].Value = "WIO Deck";
                    wsp.Cells[1, 9].Value = "DBR Leasehold";
                    wsp.Cells[1, 10].Value = "DBR Leased Acreage";
                    wsp.Cells[1, 11].Value = "DBR HBP Acreage";
                    wsp.Cells[1, 12].Value = "Property Name";
                    wsp.Cells[1, 13].Value = "DBR WI";
                    wsp.Cells[1, 14].Value = "DBR NRI";
                    using (ExcelRange rng = wsp.Cells[1, 1, 1, 14])
                    {
                        rng.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.None;
                        rng.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.None;
                        rng.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        rng.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        rng.Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;
                        rng.Style.Font.Bold = true;// Setting bold font                    
                        rng.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                        rng.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                        rng.Style.Font.Color.SetColor(Color.Black); // Setting font color
                    }

                    #endregion
                    rowIndex++;
                    var lAcreageOwnership = lAO.Where(u => u.ProspectName == p.ProspectName && u.ProspectNumber == p.ProspectNumber).ToList();
                    //string tempSectionValue = "";
                    //string tempBlockValue = "";
                    //string tempCountyNameValue = "";
                    string color = "Grey";
                    #region Prospect Worksheet
                    foreach (var ao in lAcreageOwnership)
                    {
                        rowIndex++;
                        //if (tempSectionValue != ao.Section.Trim() || tempBlockValue != ao.Block.Trim() || tempCountyNameValue != ao.CountyName.Trim())
                        //{
                        //    color = color == "White" ? "Grey" : "White";
                        //}
                        //tempSectionValue = ao.Section.Trim() ;
                        // tempBlockValue = ao.Block.Trim();
                        // tempCountyNameValue = ao.CountyName.Trim();
                        if (tractid != ao.LocationDataID)
                        {
                            color = color == "White" ? "Grey" : "White";
                        }
                        if (!(tractid == ao.LocationDataID))
                        {

                            ObjAcearageReportCheck = null;
                            ObjAcearageReportCheck = new AcearageReportCheck();
                            ObjAcearageReportCheck.LocationDataId = ao.LocationDataID;
                            ObjAcearageReportCheck.AcearageReportDeck = new List<AcearageReportDeck>();
                            ObjAcearageReportCheck.AcearageReportWell = new List<AcearageReportWell>();
                            ObjAcearageReportCheck.AcearageReportDeck.Add(new AcearageReportDeck() { LocationDataId = ao.LocationDataID, DeckName = ao.DeckName });
                            ObjAcearageReportCheck.AcearageReportWell.Add(new AcearageReportWell() { LocationDataId = ao.LocationDataID, WellName = ao.WellName });

                            wsp.Cells["A" + (rowIndex).ToString()].Value = ao.SubSection;
                            wsp.Cells["B" + (rowIndex).ToString()].Value = ao.Section;
                            wsp.Cells["C" + (rowIndex).ToString()].Value = ao.Block;
                            wsp.Cells["D" + (rowIndex).ToString()].Value = ao.CountyName;
                            wsp.Cells["E" + (rowIndex).ToString()].Value = ao.GrossAcres;


                            wsp.Cells["F" + (rowIndex).ToString()].Value = ao.LeasedAcres;
                            wsp.Cells["J" + (rowIndex).ToString()].Formula = "=F" + rowIndex.ToString() + "*I" + rowIndex.ToString();
                            wsp.Cells["K" + (rowIndex).ToString()].Formula = "=G" + rowIndex.ToString() + "*I" + rowIndex.ToString();
                            wsp.Cells["G" + (rowIndex).ToString()].Value = ao.HBPNetAcres;
                            wsp.Cells["H" + (rowIndex).ToString()].Value = ao.DeckName;
                            wsp.Cells["I" + (rowIndex).ToString()].Value = ao.DBRLeasehold;


                            if (ao.WellName == "")
                            {
                                if (ao.DBRWI != 0.0M)
                                {
                                    wsp.Cells["M" + (rowIndex).ToString()].Value = ao.DBRWI;
                                }
                            }
                            else
                            {
                                wsp.Cells["M" + (rowIndex).ToString()].Value = ao.DBRWI;
                            }
                            if (ao.WellName == "")
                            {
                                if (ao.DBRNRI != 0.0M)
                                {
                                    wsp.Cells["N" + (rowIndex).ToString()].Value = ao.DBRNRI;
                                }
                            }
                            else
                            {

                                wsp.Cells["N" + (rowIndex).ToString()].Value = ao.DBRNRI;
                            }

                            wsp.Cells["L" + (rowIndex).ToString()].Value = ao.WellName;
                            // wsp.Cells["M" + (rowIndex).ToString()].Value = ao.DBRWI;
                            //wsp.Cells["N" + (rowIndex).ToString()].Value = ao.DBRNRI;
                        }


                        if (tractid == ao.LocationDataID)
                        {
                            if (!ObjAcearageReportCheck.AcearageReportWell.Any(x => x.LocationDataId == ao.LocationDataID && x.WellName == ao.WellName))
                            {
                                wsp.Cells["L" + (rowIndex).ToString()].Value = ao.WellName;


                                if (ao.WellName == "")
                                {
                                    if (ao.DBRWI != 0.0M)
                                    {
                                        wsp.Cells["M" + (rowIndex).ToString()].Value = ao.DBRWI;
                                    }
                                }
                                else
                                {
                                    wsp.Cells["M" + (rowIndex).ToString()].Value = ao.DBRWI;
                                }
                                if (ao.WellName == "")
                                {
                                    if (ao.DBRNRI != 0.0M)
                                    {
                                        wsp.Cells["N" + (rowIndex).ToString()].Value = ao.DBRNRI;
                                    }
                                }
                                else
                                {

                                    wsp.Cells["N" + (rowIndex).ToString()].Value = ao.DBRNRI;
                                }


                            }

                            if (DeckName != ao.DeckName)
                            {
                                wsp.Cells["F" + (rowIndex).ToString()].Value = ao.LeasedAcres;

                                wsp.Cells["J" + (rowIndex).ToString()].Formula = "=F" + rowIndex.ToString() + "*I" + rowIndex.ToString();
                                wsp.Cells["K" + (rowIndex).ToString()].Formula = "=G" + rowIndex.ToString() + "*I" + rowIndex.ToString();

                                wsp.Cells["G" + (rowIndex).ToString()].Value = ao.HBPNetAcres;
                                wsp.Cells["H" + (rowIndex).ToString()].Value = ao.DeckName;
                                wsp.Cells["I" + (rowIndex).ToString()].Value = ao.DBRLeasehold;

                            }
                            ObjAcearageReportCheck.AcearageReportDeck.Add(new AcearageReportDeck() { LocationDataId = ao.LocationDataID, DeckName = ao.DeckName });
                            ObjAcearageReportCheck.AcearageReportWell.Add(new AcearageReportWell() { LocationDataId = ao.LocationDataID, WellName = ao.WellName });

                        }






                        // wsp.Cells["J" + (rowIndex).ToString()].Formula = String.Format("=IF( F{0}*I{1}=0, \"\",F{2}*I{3} )", rowIndex.ToString(), rowIndex.ToString(), rowIndex.ToString(), rowIndex.ToString());                         
                        // wsp.Cells["K" + (rowIndex).ToString()].Formula = String.Format("=IF( G{0}*I{1}=0, \"\",G{2}*I{3} )", rowIndex.ToString(), rowIndex.ToString(), rowIndex.ToString(), rowIndex.ToString());  


                        tractid = ao.LocationDataID;
                        DeckName = ao.DeckName;
                        WellName = ao.WellName;
                        using (ExcelRange rng = wsp.Cells[rowIndex, 1, rowIndex, 14])
                        {
                            rng.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            rng.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            rng.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            rng.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            if (color == "Grey")
                            {
                                rng.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                                rng.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(192, 192, 192));
                            }
                        }
                    }
                    #endregion
                    #region Prospect Worksheet Format
                    using (ExcelRange rng = wsp.Cells[1, 1, sRowIndex, 14])
                    {
                        rng.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        rng.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        rng.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        rng.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        rng.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        rng.Style.Fill.BackgroundColor.SetColor(Color.White);
                    }
                    using (ExcelRange rng = wsp.Cells[2, 1, rowIndex, 4])
                    {
                        rng.Style.Numberformat.Format = "@";
                        rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;
                    }
                    using (ExcelRange rng = wsp.Cells[2, 5, rowIndex, 7])
                    {
                        rng.Style.Numberformat.Format = "#,##0.00";
                        rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                    }
                    using (ExcelRange rng = wsp.Cells[2, 8, rowIndex, 8])
                    {
                        rng.Style.Numberformat.Format = "@";
                        rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;
                    }
                    //
                    using (ExcelRange rng = wsp.Cells[2, 9, rowIndex, 9])
                    {
                        rng.Style.Numberformat.Format = "#,##0.00000000%";
                        rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                    }

                    using (ExcelRange rng = wsp.Cells[2, 10, rowIndex, 11])
                    {
                        rng.Style.Numberformat.Format = "#,##0.0000";
                        rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                    }
                    using (ExcelRange rng = wsp.Cells[2, 12, rowIndex, 12])
                    {
                        rng.Style.Numberformat.Format = "@";
                        rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;
                    }
                    using (ExcelRange rng = wsp.Cells[2, 13, rowIndex, 14])
                    {
                        rng.Style.Numberformat.Format = "#,##0.00000000%";
                        rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                    }
                    #endregion
                    #region Prospect Worksheet Total

                    wsp.Cells["D" + (rowIndex + 2).ToString()].Value = "TOTAL:";
                    wsp.Cells["E" + (rowIndex + 2).ToString()].Formula = "=SUM(E2: E" + rowIndex.ToString() + ")";
                    wsp.Cells["F" + (rowIndex + 2).ToString()].Formula = "=SUM(F2: F" + rowIndex.ToString() + ")";
                    wsp.Cells["G" + (rowIndex + 2).ToString()].Formula = "=SUM(G2: G" + rowIndex.ToString() + ")";
                    //wsp.Cells["H" + (rowIndex + 2).ToString()].Formula = "=SUM(H2: H" + rowIndex.ToString() + ")";
                    wsp.Cells["J" + (rowIndex + 2).ToString()].Formula = "=SUM(J2: J" + rowIndex.ToString() + ")";
                    wsp.Cells["K" + (rowIndex + 2).ToString()].Formula = "=SUM(K2: K" + rowIndex.ToString() + ")";
                    //wsp.Cells["K" + (rowIndex + 2).ToString()].Formula = "=SUM(K2: K" + rowIndex.ToString() + ")";
                    //wsp.Cells["L" + (rowIndex + 2).ToString()].Formula = "=SUM(L2: L" + rowIndex.ToString() + ")";
                    //wsp.Cells["M" + (rowIndex + 2).ToString()].Formula = "=SUM(M2: M" + rowIndex.ToString() + ")";

                    using (ExcelRange rng = wsp.Cells[rowIndex + 2, 1, rowIndex + 2, 14])
                    {
                        rng.Style.Numberformat.Format = "@";
                        rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        rng.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        rng.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        rng.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        rng.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                        rng.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        rng.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(146, 208, 80));
                        rng.Style.Font.Bold = true;
                    }
                    using (ExcelRange rng = wsp.Cells[rowIndex + 2, 5, rowIndex + 2, 14])
                    {
                        rng.Style.Numberformat.Format = "#,##0.00";
                        rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                    }

                    wsp.Cells["D" + (rowIndex + 4).ToString()].Value = "Average WI:";
                    wsp.Cells["D" + (rowIndex + 4).ToString()].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;
                    wsp.Cells["E" + (rowIndex + 4).ToString()].Formula = "=(J" + (rowIndex + 2).ToString() + "/E" + (rowIndex + 2).ToString() + ")";
                    wsp.Cells["E" + (rowIndex + 4).ToString()].Style.Numberformat.Format = "#,##0.00%";
                    wsp.Cells["E" + (rowIndex + 4).ToString()].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;

                    using (ExcelRange rng = wsp.Cells[rowIndex + 4, 1, rowIndex + 4, 14])
                    {
                        rng.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        rng.Style.Fill.BackgroundColor.SetColor(Color.Yellow);
                    }
                    #endregion

                    #region Prospect Summary Data
                    wsps.Cells[sRowIndex, 1].Value = p.ProspectName;
                    wsps.Cells[sRowIndex, 2].Formula = "='" + p.ProspectName + " #" + p.ProspectNumber + "'!F" + (rowIndex + 2).ToString();
                    wsps.Cells[sRowIndex, 3].Formula = "='" + p.ProspectName + " #" + p.ProspectNumber + "'!J" + (rowIndex + 2).ToString();
                    wsps.Cells[sRowIndex, 4].Formula = "='" + p.ProspectName + " #" + p.ProspectNumber + "'!G" + (rowIndex + 2).ToString();
                    wsps.Cells[sRowIndex, 5].Formula = "='" + p.ProspectName + " #" + p.ProspectNumber + "'!K" + (rowIndex + 2).ToString();

                    #endregion

                    wsp.Cells.AutoFitColumns(0);
                    wsp.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Exibhit A Report";
                    wsp.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                    wsp.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                    //wsp.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                    wsp.PrinterSettings.RepeatRows = wsps.Cells["1:1"];
                    wsp.PrinterSettings.RepeatColumns = wsps.Cells["A:" + ExcelColumn[5]];
                }
                #region Prospect Summary Data Total
                wsps.Cells[sRowIndex + 2, 1].Value = "TOTAL:";
                wsps.Cells[sRowIndex + 2, 2].Formula = "=SUM(B2:B" + sRowIndex.ToString() + ")";
                wsps.Cells[sRowIndex + 2, 3].Formula = "=SUM(C2:C" + sRowIndex.ToString() + ")";
                wsps.Cells[sRowIndex + 2, 4].Formula = "=SUM(D2:D" + sRowIndex.ToString() + ")";
                wsps.Cells[sRowIndex + 2, 5].Formula = "=SUM(E2:E" + sRowIndex.ToString() + ")";
                #region Prospect Worksheet Format
                using (ExcelRange rng = wsps.Cells[1, 1, sRowIndex + 2, 5])
                {
                    rng.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    rng.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    rng.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    rng.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                    rng.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    rng.Style.Fill.BackgroundColor.SetColor(Color.White);
                }
                using (ExcelRange rng = wsps.Cells[sRowIndex + 2, 1, sRowIndex + 2, 5])
                {
                    rng.Style.Font.Bold = true;
                    rng.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    rng.Style.Fill.BackgroundColor.SetColor(Color.White);
                    rng.Style.Font.Color.SetColor(Color.Black);
                }
                using (ExcelRange rng = wsps.Cells[1, 3, sRowIndex + 2, 3])
                {
                    rng.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(146, 208, 80));
                }
                using (ExcelRange rng = wsps.Cells[1, 5, sRowIndex + 2, 5])
                {
                    rng.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(146, 208, 80));
                }
                using (ExcelRange rng = wsps.Cells[2, 1, sRowIndex + 2, 1])
                {
                    rng.Style.Numberformat.Format = "@";
                    rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Left;
                }
                using (ExcelRange rng = wsps.Cells[2, 2, sRowIndex + 2, 5])
                {
                    rng.Style.Numberformat.Format = "#,##0.00";
                    rng.Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Right;
                }
                #endregion

                #endregion

                wsps.Cells.AutoFitColumns(0);
                wsps.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Exibhit A Report";
                wsps.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                wsps.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                //wsps.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                wsps.PrinterSettings.RepeatRows = wsps.Cells["1:1"];
                wsps.PrinterSettings.RepeatColumns = wsps.Cells["A:" + ExcelColumn[5]];

                // Setting some document properties
                package.Workbook.Properties.Title = "Excel Acreage Ownership Report";
                package.Workbook.Properties.Author = "OGWM";
                package.Workbook.Properties.Comments = "Excel Acreage Ownership Report";
                // package.Save();
                output = package.GetAsByteArray();
            }
            return output;
        }

        private static string CleanText(string s)
        {
            // Need to convert HTML entities (named or numbered) into actual Unicode characters
            s = System.Web.HttpUtility.HtmlDecode(s);
            // Remove any non-breaking spaces, kills Excel
            s = s.Replace("\u00A0", " ");
            return s;
        }

        public static byte[] FracScheduleExport(List<FracScheduleInformation> lData, string filename, string filepath)
        {
            byte[] output = new byte[] { };
            if (lData.Count > 0)
            {
                DirectoryInfo outputDir = new DirectoryInfo(filepath);
                filename = filename.Replace(" ", "");
                CheckFile(outputDir, filename);
                FileInfo newFile = new FileInfo(outputDir.FullName + filename);
                using (ExcelPackage package = new ExcelPackage())
                {
                    try
                    {
                        ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(filename);
                        worksheet.Cells[1, 1].Value = "Operator";
                        worksheet.Cells[1, 2].Value = "Well";
                        worksheet.Cells[1, 3].Value = "Well Status";
                        worksheet.Cells[1, 4].Value = "Rig Release";
                        worksheet.Cells[1, 5].Value = "Comp Obligation";
                        worksheet.Cells[1, 6].Value = "Required Activity";
                        worksheet.Cells[1, 7].Value = "Length";
                        worksheet.Cells[1, 8].Value = "Scheduled Frac Start";
                        worksheet.Cells[1, 9].Value = "Scheduled Frac End";
                        worksheet.Cells[1, 10].Value = "DWOF";
                        worksheet.Cells[1, 11].Value = "Frac Company";
                        worksheet.Cells[1, 12].Value = "Area";
                        worksheet.Cells[1, 13].Value = "Stages";

                        int i = 1;
                        foreach (var pew in lData)
                        {
                            worksheet.Cells["A" + (i + 1).ToString()].Value = pew.Operator;
                            worksheet.Cells["B" + (i + 1).ToString()].Value = pew.Well;
                            worksheet.Cells["C" + (i + 1).ToString()].Value = pew.WellStatus;
                            worksheet.Cells["D" + (i + 1).ToString()].Value = pew.RigRelaese;

                            worksheet.Cells["E" + (i + 1).ToString()].Value = pew.CompObligation;
                            worksheet.Cells["F" + (i + 1).ToString()].Value = pew.RequiredActivity;
                            worksheet.Cells["G" + (i + 1).ToString()].Value = pew.LENGTH;//D

                            worksheet.Cells["H" + (i + 1).ToString()].Value = pew.ScheduledFracStartDate;
                            worksheet.Cells["I" + (i + 1).ToString()].Value = pew.ScheduledFracEndDate;
                            worksheet.Cells["J" + (i + 1).ToString()].Value = pew.Dwof;
                            worksheet.Cells["K" + (i + 1).ToString()].Value = pew.CompanyName;//H
                            worksheet.Cells["L" + (i + 1).ToString()].Value = pew.Area;
                            worksheet.Cells["M" + (i + 1).ToString()].Value = pew.Stages;
                            i++;
                        }
                        using (var range = worksheet.Cells[1, 1, 1, 13])
                        {
                            range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                            range.Style.Font.Bold = true;// Setting bold font                    
                            range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                            range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                            range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                        }
                        //Setting Number Format...
                        worksheet.Cells["A2:C" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                        worksheet.Cells["D2:E" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";	// Setting integer format
                        worksheet.Cells["F2:F" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                        worksheet.Cells["G2:G" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0";// Setting integer format
                        worksheet.Cells["H2:I" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";	// Setting date format
                        worksheet.Cells["J2:M" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                        // Setting AutoFit for all cells
                        worksheet.Cells.AutoFitColumns(0);
                        // Lets set the header text
                        worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Excel Frac Schedule";
                        // Add the page number to the right of the footer + total number of pages
                        worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                        // Add the sheet name to center of the footer
                        worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                        // Add the filepath to the left of the footer
                        worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                        // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                        worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:1"];
                        worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:N"];
                        // Setting some document properties
                        package.Workbook.Properties.Title = "Excel FracSchedule";
                        package.Workbook.Properties.Author = "OGWM";
                        package.Workbook.Properties.Comments = "Excel FracSchedule";
                        // package.Save();
                        output = package.GetAsByteArray();
                    }
                    catch { }
                }
            }
            return output;
        }

        public static byte[] QueryToolExport(List<string> ExcelSheetName, DataSet ds, string filename, string filepath)
        {
            byte[] output = new byte[] { };

            DirectoryInfo outputDir = new DirectoryInfo(filepath);
            filename = filename.Replace(" ", "");
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);

            using (ExcelPackage package = new ExcelPackage())//new ExcelPackage(newFile)
            {
                try
                {
                    if (ds.Tables.Count > 0)
                    {
                        int iSheetCount = 0;
                        string sTemp = string.Empty;
                        decimal dTemp = 0;
                        double doTemp = 0;
                        DateTime dtTemp = default(DateTime);
                        foreach (DataTable dt in ds.Tables)
                        {
                            ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(ExcelSheetName[iSheetCount]);
                            int iCol = 0;
                            int iRow = 0;
                            //worksheet.Cells["A1"].LoadFromDataTable(dt,true);
                            iRow++;
                            foreach (DataColumn dc in dt.Columns)
                            {
                                iCol++;
                                worksheet.Column(iCol).Width = dc.ColumnName.Length + 3;
                                //worksheet.Column(iCol).Style.Font.Bold = true;
                                worksheet.Cells[iRow, iCol].Value = dc.ColumnName;
                            }
                            foreach (DataRow dr in dt.Rows)
                            {
                                iRow++;
                                iCol = 0;
                                foreach (DataColumn dc in dt.Columns)
                                {
                                    sTemp = dr[dc.ColumnName].ToString();
                                    if (sTemp != "" && sTemp != string.Empty)
                                    {
                                        switch (dc.DataType.ToString())
                                        {
                                            case "System.DateTime":
                                                DateTime.TryParse(sTemp, out dtTemp);
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = dtTemp.ToString("MM/dd/yyyy");
                                                break;
                                            case "System.Double":
                                                double.TryParse(sTemp, out doTemp);
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = doTemp;//.ToString("##,##,##0.########");
                                                break;
                                            case "System.Decimal":
                                                decimal.TryParse(sTemp, out dTemp);
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = dTemp;//.ToString("##,##,##0.########");
                                                break;
                                            default:
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = sTemp;
                                                break;
                                        }
                                    }
                                    else { worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = sTemp; }
                                    iCol++;
                                }
                            }
                            iSheetCount++;
                            // Formatting style of the header
                            using (var range = worksheet.Cells[1, 1, 1, iCol])
                            {
                                range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Font.Bold = true;// Setting bold font                    
                                range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                                range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                                range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                            }

                            iCol = 0;
                            foreach (DataColumn dc in dt.Columns)
                            {
                                //iCol++;
                                try
                                {
                                    switch (dc.DataType.ToString())
                                    {
                                        case "System.DateTime":
                                            worksheet.Cells[ExcelColumn[iCol] + "2:" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";
                                            break;
                                        case "System.Double":
                                            //worksheet.Cells[ExcelColumn[iCol] + "2:" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "###,##0.####################################";
                                            break;
                                        case "System.Decimal":
                                            if (dc.ColumnName == "AFE" || dc.ColumnName == "FE" || dc.ColumnName == "AC")
                                            {
                                                worksheet.Cells[ExcelColumn[iCol] + "2:" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "$#,##,##0.00";
                                            }
                                            //worksheet.Cells[ExcelColumn[iCol] + "2:" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "#,##0.00######";
                                            break;
                                        default:
                                            worksheet.Cells[ExcelColumn[iCol] + "2:" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "@";
                                            break;
                                    }
                                }
                                catch { }
                                iCol++;
                            }
                            // //Setting Number Format...
                            // //Setting integer format for the column 'Quantity' and Setting decimal format for the column 'Price' and 'Value'
                            //worksheet.Cells["A2:A" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";// Setting date format
                            //worksheet.Cells["B2:D" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                            ////worksheet.Cells["C2:C" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0";	// Setting integer format
                            //worksheet.Cells["E2:L" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0.00";
                            //worksheet.Cells["M2:M" + (i + 1).ToString()].Style.Numberformat.Format = "@";

                            // Setting AutoFit for all cells
                            worksheet.Cells.AutoFitColumns(0);

                            worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Report";
                            // Add the page number to the right of the footer + total number of pages
                            worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                            // Add the sheet name to center of the footer
                            worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                            // Add the filepath to the left of the footer
                            worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                            // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                            worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:" + iCol];
                            worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:" + ExcelColumn[iCol]];
                        }
                    }
                    // Setting some document properties
                    package.Workbook.Properties.Title = "Report";
                    package.Workbook.Properties.Author = "OGWM";
                    package.Workbook.Properties.Comments = "Report";
                    // package.Save();
                    output = package.GetAsByteArray();
                }
                catch { }
            }
            return output;
        }

        public static byte[] QueryToolExport(DataSet ds, string filename, string filepath)
        {
            byte[] output = new byte[] { };

            DirectoryInfo outputDir = new DirectoryInfo(filepath);
            filename = filename.Replace(" ", "");
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);

            using (ExcelPackage package = new ExcelPackage())//new ExcelPackage(newFile)
            {
                try
                {
                    if (ds.Tables.Count > 0)
                    {
                        int iSheetCount = 0;
                        string sTemp = string.Empty;
                        decimal dTemp = 0;
                        double doTemp = 0;
                        DateTime dtTemp = default(DateTime);
                        foreach (DataTable dt in ds.Tables)
                        {
                            ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Report " + iSheetCount);
                            int iCol = 0;
                            int iRow = 0;
                            //worksheet.Cells["A1"].LoadFromDataTable(dt,true);
                            iRow++;
                            foreach (DataColumn dc in dt.Columns)
                            {
                                iCol++;
                                worksheet.Column(iCol).Width = dc.ColumnName.Length + 3;
                                //worksheet.Column(iCol).Style.Font.Bold = true;
                                worksheet.Cells[iRow, iCol].Value = dc.ColumnName;
                            }
                            foreach (DataRow dr in dt.Rows)
                            {
                                iRow++;
                                iCol = 0;
                                foreach (DataColumn dc in dt.Columns)
                                {
                                    sTemp = dr[dc.ColumnName].ToString();
                                    if (sTemp != "" && sTemp != string.Empty)
                                    {
                                        switch (dc.DataType.ToString())
                                        {
                                            case "System.DateTime":
                                                DateTime.TryParse(sTemp, out dtTemp);
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = dtTemp.ToString("MM/dd/yyyy");
                                                break;
                                            case "System.Double":
                                                double.TryParse(sTemp, out doTemp);
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = doTemp;//.ToString("##,##,##0.########");
                                                break;
                                            case "System.Decimal":
                                                decimal.TryParse(sTemp, out dTemp);
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = dTemp;//.ToString("##,##,##0.########");
                                                break;
                                            default:
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = sTemp;
                                                break;
                                        }
                                    }
                                    else { worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = sTemp; }
                                    iCol++;
                                }
                            }
                            iSheetCount++;
                            // Formatting style of the header
                            using (var range = worksheet.Cells[1, 1, 1, iCol])
                            {
                                range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Font.Bold = true;// Setting bold font                    
                                range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                                range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                                range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                            }

                            iCol = 0;
                            foreach (DataColumn dc in dt.Columns)
                            {
                                //iCol++;
                                try
                                {
                                    switch (dc.DataType.ToString())
                                    {
                                        case "System.DateTime":
                                            worksheet.Cells[ExcelColumn[iCol] + "2:" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";
                                            break;
                                        case "System.Double":
                                            //worksheet.Cells[ExcelColumn[iCol] + "2:" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "###,##0.####################################";
                                            break;
                                        case "System.Decimal":
                                            if (dc.ColumnName == "AFE" || dc.ColumnName == "FE" || dc.ColumnName == "AC")
                                            {
                                                worksheet.Cells[ExcelColumn[iCol] + "2:" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "$#,##,##0.00";
                                            }
                                            //worksheet.Cells[ExcelColumn[iCol] + "2:" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "#,##0.00######";
                                            break;
                                        default:
                                            worksheet.Cells[ExcelColumn[iCol] + "2:" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "@";
                                            break;
                                    }
                                }
                                catch { }
                                iCol++;
                            }
                            // //Setting Number Format...
                            // //Setting integer format for the column 'Quantity' and Setting decimal format for the column 'Price' and 'Value'
                            //worksheet.Cells["A2:A" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";// Setting date format
                            //worksheet.Cells["B2:D" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                            ////worksheet.Cells["C2:C" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0";	// Setting integer format
                            //worksheet.Cells["E2:L" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0.00";
                            //worksheet.Cells["M2:M" + (i + 1).ToString()].Style.Numberformat.Format = "@";

                            // Setting AutoFit for all cells
                            worksheet.Cells.AutoFitColumns(0);

                            worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Report";
                            // Add the page number to the right of the footer + total number of pages
                            worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                            // Add the sheet name to center of the footer
                            worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                            // Add the filepath to the left of the footer
                            worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                            // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                            worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:" + iCol];
                            worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:" + ExcelColumn[iCol]];
                        }
                    }
                    // Setting some document properties
                    package.Workbook.Properties.Title = "Report";
                    package.Workbook.Properties.Author = "OGWM";
                    package.Workbook.Properties.Comments = "Report";
                    // package.Save();
                    output = package.GetAsByteArray();
                }
                catch { }
            }
            return output;
        }

        public static byte[] QueryToolExport(DataSet ds, string filename, string filepath, List<string> ExcelSheetName)
        {
            byte[] output = new byte[] { };

            DirectoryInfo outputDir = new DirectoryInfo(filepath);
            filename = filename.Replace(" ", "");
            CheckFile(outputDir, filename);
            FileInfo newFile = new FileInfo(outputDir.FullName + filename);

            using (ExcelPackage package = new ExcelPackage())//new ExcelPackage(newFile)
            {
                try
                {
                    if (ds.Tables.Count > 0)
                    {
                        int iSheetCount = 0;
                        string sTemp = string.Empty;
                        decimal dTemp = 0;
                        double doTemp = 0;
                        DateTime dtTemp = default(DateTime);
                        foreach (DataTable dt in ds.Tables)
                        {
                            ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(Convert.ToString(ExcelSheetName[iSheetCount]));
                            int iCol = 0;
                            int iRow = 0;
                            //worksheet.Cells["A1"].LoadFromDataTable(dt,true);
                            iRow++;
                            foreach (DataColumn dc in dt.Columns)
                            {
                                iCol++;
                                worksheet.Column(iCol).Width = dc.ColumnName.Length + 3;
                                //worksheet.Column(iCol).Style.Font.Bold = true;
                                worksheet.Cells[iRow, iCol].Value = dc.ColumnName;
                            }
                            foreach (DataRow dr in dt.Rows)
                            {
                                iRow++;
                                iCol = 0;
                                foreach (DataColumn dc in dt.Columns)
                                {
                                    sTemp = dr[dc.ColumnName].ToString();
                                    if (sTemp != "" && sTemp != string.Empty)
                                    {
                                        switch (dc.DataType.ToString())
                                        {
                                            case "System.DateTime":
                                                DateTime.TryParse(sTemp, out dtTemp);
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = dtTemp.ToString("MM/dd/yyyy");
                                                break;
                                            case "System.Double":
                                                double.TryParse(sTemp, out doTemp);
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = doTemp;//.ToString("##,##,##0.########");
                                                break;
                                            case "System.Decimal":
                                                decimal.TryParse(sTemp, out dTemp);
                                                worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = dTemp;//.ToString("##,##,##0.########");
                                                break;
                                            default:
                                                {
                                                    if (IsFormulaColumn(dc.Caption.ToString()))
                                                    {
                                                        worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Formula = sTemp;
                                                    }
                                                    else
                                                    {
                                                        worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = sTemp;
                                                    }
                                                    break;
                                                }

                                        }
                                    }

                                    else { worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].Value = sTemp; }
                                    iCol++;
                                }
                            }
                            iSheetCount++;
                            // Formatting style of the header
                            using (var range = worksheet.Cells[1, 1, 1, iCol])
                            {
                                range.Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Border.Bottom.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Border.Left.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Border.Right.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
                                range.Style.Font.Bold = true;// Setting bold font                    
                                range.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;// Setting fill type solid
                                range.Style.Fill.BackgroundColor.SetColor(Color.White);// Setting background color dark blue
                                range.Style.Font.Color.SetColor(Color.Black); // Setting font color
                            }

                            iCol = 0;
                            foreach (DataColumn dc in dt.Columns)
                            {
                                //iCol++;
                                try
                                {
                                    switch (dc.DataType.ToString())
                                    {
                                        case "System.DateTime":
                                            worksheet.Cells[ExcelColumn[iCol] + 2 + ":" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";
                                            break;
                                        case "System.Double":
                                            worksheet.Cells[ExcelColumn[iCol] + 2 + ":" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "###0.0#########################";
                                            break;
                                        case "System.Decimal":
                                            worksheet.Cells[ExcelColumn[iCol] + 2 + ":" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "###0.0#########################";
                                            break;
                                        default:
                                            {
                                                if (dc.Caption.ToString().ToUpper() == "Well NRI".ToUpper())
                                                {
                                                    worksheet.Cells[ExcelColumn[iCol] + 2 + ":" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "###0.0###########";
                                                }
                                                else if (IsFormulaColumn(dc.Caption.ToString()))
                                                {
                                                    worksheet.Cells[ExcelColumn[iCol] + 2 + ":" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "###0.0#########################";

                                                }
                                                else
                                                {
                                                    worksheet.Cells[ExcelColumn[iCol] + 2 + ":" + ExcelColumn[iCol] + (iRow).ToString()].Style.Numberformat.Format = "@";
                                                    //worksheet.Cells[ExcelColumn[iCol] + (iRow).ToString()].AutoFitColumns(0);
                                                }
                                                break;
                                            }
                                    }
                                }
                                catch { }
                                iCol++;
                            }
                            foreach (DataColumn dc in dt.Columns)
                            {
                                if (dc.Caption.ToString().ToUpper() == "Well NRI".ToUpper())
                                {
                                    worksheet.Column(iCol).Width = 15;
                                }

                                else if (IsFormulaColumn(dc.Caption.ToString()))
                                {
                                    worksheet.Column(iCol).Width = 25;
                                }
                                else
                                {
                                    worksheet.Column(iCol).AutoFit(0);
                                }
                            }

                            // //Setting Number Format...
                            // //Setting integer format for the column 'Quantity' and Setting decimal format for the column 'Price' and 'Value'
                            //worksheet.Cells["A2:A" + (i + 1).ToString()].Style.Numberformat.Format = "MM/dd/yyyy";// Setting date format
                            //worksheet.Cells["B2:D" + (i + 1).ToString()].Style.Numberformat.Format = "@";
                            ////worksheet.Cells["C2:C" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0";	// Setting integer format
                            //worksheet.Cells["E2:L" + (i + 1).ToString()].Style.Numberformat.Format = "#,##0.00";
                            //worksheet.Cells["M2:M" + (i + 1).ToString()].Style.Numberformat.Format = "@";

                            // Setting AutoFit for all cells
                            //  worksheet.Cells.AutoFitColumns(0);

                            worksheet.HeaderFooter.OddHeader.CenteredText = "&24&U&\"Arial,Regular Bold\" Report";
                            // Add the page number to the right of the footer + total number of pages
                            worksheet.HeaderFooter.OddFooter.RightAlignedText = string.Format("Page {0} of {1}", ExcelHeaderFooter.PageNumber, ExcelHeaderFooter.NumberOfPages);
                            // Add the sheet name to center of the footer
                            worksheet.HeaderFooter.OddFooter.CenteredText = ExcelHeaderFooter.SheetName;
                            // Add the filepath to the left of the footer
                            worksheet.HeaderFooter.OddFooter.LeftAlignedText = ExcelHeaderFooter.FilePath + ExcelHeaderFooter.FileName;
                            // At the time of printing, when page page breaks, then the header will come in the next page by enabling this settings...
                            worksheet.PrinterSettings.RepeatRows = worksheet.Cells["1:" + iCol];
                            worksheet.PrinterSettings.RepeatColumns = worksheet.Cells["A:" + ExcelColumn[iCol]];
                        }
                    }
                    // Setting some document properties
                    package.Workbook.Properties.Title = "Report";
                    package.Workbook.Properties.Author = "OGWM";
                    package.Workbook.Properties.Comments = "Report";
                    // package.Save();
                    output = package.GetAsByteArray();
                }
                catch { }
            }
            return output;
        }

        private static bool IsFormulaColumn(string ColumnsName)
        {
            ColumnsName = ColumnsName.ToUpper();
            if (ColumnsName == "Well Working Interest".ToUpper() || ColumnsName == "Well Portion RI".ToUpper() || ColumnsName == "Well Portion ORRI".ToUpper() || ColumnsName == "Revenue Interest".ToUpper() || ColumnsName == "Well NRI".ToUpper())
            {
                return true;
            }
            else
            {
                return false; ;
            }
        }

        public static List<GetAcreageOwnershipReportInfo> RefactorAcreageReportData(List<GetAcreageOwnershipReportInfo> SQLData)
        {
            try
            {
                var ReportData = new List<GetAcreageOwnershipReportInfo>();
                var AcreageReportLocationData = new List<AcreageReportLocationData>();
                var AcreageReportLocationDataDummy = new List<AcreageReportLocationData>();
                var AcreageReportDeck = new List<AcreageReportDeck>();
                var AcreageReportWell = new List<AcreageReportWell>();
                AcreageReportLocationData = SQLData.Select(x => new AcreageReportLocationData
                {

                    Block = x.Block,
                    CountyName = x.CountyName,
                    GrossAcres = x.GrossAcres,                    
                    LocationDataID = x.LocationDataID,
                    MIP = x.MIP,
                    ProspectName = x.ProspectName,
                    ProspectNumber = x.ProspectNumber,
                    Section = x.Section,
                    SubSection = x.SubSection,

                }).ToList();

                AcreageReportLocationData = AcreageReportLocationData.DistinctBy(x => x.LocationDataID).ToList();

                AcreageReportLocationDataDummy.AddRange(AcreageReportLocationData);

                AcreageReportDeck = SQLData.Select(x => new AcreageReportDeck
                {
                    LocationDataID = x.LocationDataID,
                    DBRHBPAcreage = x.DBRHBPAcreage,
                    DBRLeasedAcreage = x.DBRLeasedAcreage,
                    DBRLeasehold = x.DBRLeasehold,
                    DeckName = x.DeckName,
                    HBPNetAcres = x.HBPNetAcres,
                    LeasedAcres = x.LeasedAcres,

                }).ToList();

               // AcreageReportDeck = AcreageReportDeck.DistinctBy(x => x.DeckName).ToList();

                AcreageReportDeck = AcreageReportDeck.GroupBy(x => new { x.LocationDataID, x.DeckName }).Select(x => new AcreageReportDeck
                {
                    LocationDataID = x.Key.LocationDataID,
                    DBRHBPAcreage = x.First().DBRHBPAcreage,
                    DBRLeasedAcreage = x.First().DBRLeasedAcreage,
                    DBRLeasehold = x.First().DBRLeasehold,
                    HBPNetAcres = x.First().HBPNetAcres,
                    LeasedAcres = x.First().LeasedAcres,
                    DeckName = x.Key.DeckName,

                }).ToList();
                AcreageReportWell = SQLData.Select(x => new AcreageReportWell
                {
                    LocationDataID = x.LocationDataID,
                    DBRNRI = x.DBRNRI,
                    DBRWI = x.DBRWI,
                    WellName = x.WellName
                }).ToList();

               // AcreageReportWell = AcreageReportWell.DistinctBy(x => x.WellName).ToList();

                AcreageReportWell = AcreageReportWell.GroupBy(x => new { x.LocationDataID, x.WellName }).Select(x => new AcreageReportWell
                {
                    LocationDataID = x.Key.LocationDataID,
                    DBRNRI = x.First().DBRNRI,
                    DBRWI = x.First().DBRWI,
                    WellName = x.First().WellName,
                   

                }).ToList();


                AcreageReportLocationDataDummy.ForEach(x =>
                {
                    var wellCount = AcreageReportWell.Where(y => y.LocationDataID == x.LocationDataID).Count();
                    var DeckCount = AcreageReportDeck.Where(y => y.LocationDataID == x.LocationDataID).Count();
                    var Maxcount = wellCount > DeckCount ? wellCount : DeckCount;
                    var DeckList = AcreageReportDeck.Where(y => y.LocationDataID == x.LocationDataID).ToList();
                    var WellList = AcreageReportWell.Where(y => y.LocationDataID == x.LocationDataID).ToList();

                    for (int i = 0; i < Maxcount; i++)
                    {
                        AcreageReportWell Well = new AcreageReportWell();
                        AcreageReportDeck Deck = new AcreageReportDeck();
                        if (DeckList.Count() > 0)
                        {
                            Deck = DeckList[i > (DeckCount - 1) ? (DeckCount - 1) : i];
                        }
                        if (WellList.Count() > 0)
                        {
                            Well = WellList[i > (wellCount - 1) ? (wellCount - 1) : i];
                        }

                        GetAcreageOwnershipReportInfo finaldata = new GetAcreageOwnershipReportInfo()
                        {
                            Block = x.Block,
                            CountyName = x.CountyName,
                            DBRHBPAcreage = Deck.DBRHBPAcreage,
                            DBRLeasedAcreage = Deck.DBRLeasedAcreage,
                            DBRLeasehold = Deck.DBRLeasehold,
                            DBRNRI = Well.DBRNRI,
                            DBRWI = Well.DBRWI,
                            DeckName = Deck.DeckName,
                            GrossAcres = x.GrossAcres,
                            HBPNetAcres = Deck.HBPNetAcres,
                            LeasedAcres = Deck.LeasedAcres,
                            LocationDataID = x.LocationDataID,
                            MIP = x.MIP,
                            ProspectName = x.ProspectName,
                            ProspectNumber = x.ProspectNumber,
                            Section = x.Section,
                            SubSection = x.SubSection,
                            WellId = 0, // not required 
                            WellLocationdataId = 0,// not required 
                            WellName = Well.WellName
                        };
                        ReportData.Add(finaldata);
                    }
                });

                return ReportData;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        private static string[] ExcelColumn = new string[] {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","AA","AB","AC","AD","AE","AF","AG","AH","AI","AJ","AK","AL","AM","AN","AO","AP","AQ","AR","AS","AT","AU","AV","AW","AX","AY","AZ","BA","BB","BC","BD","BE","BF","BG","BH","BI","BJ","BK","BL","BM","BN","BO","BP","BQ","BR","BS","BT","BU","BV","BW","BX","BY","BZ","CA","CB","CC","CD","CE","CF","CG","CH","CI","CJ","CK","CL","CM","CN","CO","CP","CQ","CR","CS","CT","CU","CV","CW","CX","CY","CZ",
        "DA","DB","DC","DD","DE","DF","DG","DH","DI","DJ","DK","DL","DM","DN","DO","DP","DQ","DR","DS","DT","DU","DV","DW","DX","DY","DZ","EA","EB","EC","ED","EE","EF","EG","EH","EI","EJ","EK","EL","EM","EN","EO","EP","EQ","ER","ES","ET","EU","EV","EW","EX","EY","EZ","FA","FB","FC","FD","FE","FF","FG","FH","FI","FJ","FK","FL","FM","FN","FO","FP","FQ","FR","FS","FT","FU","FV","FW","FX","FY","FZ","GA","GB","GC","GD","GE","GF","GG","GH","GI","GJ","GK","GL","GM","GN","GO","GP","GQ","GR","GS","GT","GU","GV","GW","GX","GY","GZ",
        "HA","HB","HC","HD","HE","HF","HG","HH","HI","HJ","HK","HL","HM","HN","HO","HP","HQ","HR","HS","HT","HU","HV","HW","HX","HY","HZ","IA","IB","IC","ID","IE","IF","IG","IH","II","IJ","IK","IL","IM","IN","IO","IP","IQ","IR","IS","IT","IU","IV","IW","IX","IY","IZ","JA","JB","JC","JD","JE","JF","JG","JH","JI","JJ","JK","JL","JM","JN","JO","JP","JQ","JR","JS","JT","JU","JV","JW","JX","JY","JZ","KA","KB","KC","KD","KE","KF","KG","KH","KI","KJ","KK","KL","KM","KN","KO","KP","KQ","KR","KS","KT","KU","KV","KW","KX","KY","KZ",
        "LA","LB","LC","LD","LE","LF","LG","LH","LI","LJ","LK","LL","LM","LN","LO","LP","LQ","LR","LS","LT","LU","LV","LW","LX","LY","LZ","MA","MB","MC","MD","ME","MF","MG","MH","MI","MJ","MK","ML","MM","MN","MO","MP","MQ","MR","MS","MT","MU","MV","MW","MX","MY","MZ","NA","NB","NC","ND","NE","NF","NG","NH","NI","NJ","NK","NL","NM","NN","NO","NP","NQ","NR","NS","NT","NU","NV","NW","NX","NY","NZ","OA","OB","OC","OD","OE","OF","OG","OH","OI","OJ","OK","OL","OM","ON","OO","OP","OQ","OR","OS","OT","OU","OV","OW","OX","OY","OZ",
        "PA","PB","PC","PD","PE","PF","PG","PH","PI","PJ","PK","PL","PM","PN","PO","PP","PQ","PR","PS","PT","PU","PV","PW","PX","PY","PZ","QA","QB","QC","QD","QE","QF","QG","QH","QI","QJ","QK","QL","QM","QN","QO","QP","QQ","QR","QS","QT","QU","QV","QW","QX","QY","QZ","RA","RB","RC","RD","RE","RF","RG","RH","RI","RJ","RK","RL","RM","RN","RO","RP","RQ","RR","RS","RT","RU","RV","RW","RX","RY","RZ","SA","SB","SC","SD","SE","SF","SG","SH","SI","SJ","SK","SL","SM","SN","SO","SP","SQ","SR","SS","ST","SU","SV","SW","SX","SY","SZ",
        "TA","TB","TC","TD","TE","TF","TG","TH","TI","TJ","TK","TL","TM","TN","TO","TP","TQ","TR","TS","TT","TU","TV","TW","TX","TY","TZ","UA","UB","UC","UD","UE","UF","UG","UH","UI","UJ","UK","UL","UM","UN","UO","UP","UQ","UR","US","UT","UU","UV","UW","UX","UY","UZ","VA","VB","VC","VD","VE","VF","VG","VH","VI","VJ","VK","VL","VM","VN","VO","VP","VQ","VR","VS","VT","VU","VV","VW","VX","VY","VZ","WA","WB","WC","WD","WE","WF","WG","WH","WI","WJ","WK","WL","WM","WN","WO","WP","WQ","WR","WS","WT","WU","WV","WW","WX","WY","WZ",
        "XA","XB","XC","XD","XE","XF","XG","XH","XI","XJ","XK","XL","XM","XN","XO","XP","XQ","XR","XS","XT","XU","XV","XW","XX","XY","XZ","YA","YB","YC","YD","YE","YF","YG","YH","YI","YJ","YK","YL","YM","YN","YO","YP","YQ","YR","YS","YT","YU","YV","YW","YX","YY","YZ","ZA","ZB","ZC","ZD","ZE","ZF","ZG","ZH","ZI","ZJ","ZK","ZL","ZM","ZN","ZO","ZP","ZQ","ZR","ZS","ZT","ZU","ZV","ZW","ZX","ZY","ZZ","AAA","AAB","AAC"};

    }



}
#region 'Class to make well based custom grouping'
public class AcreageReportLocationData
{
    public int SNO { get; set; }
    public string ProspectName { get; set; }
    public string ProspectNumber { get; set; }
    public int LocationDataID { get; set; }
    public string SubSection { get; set; }
    public string Section { get; set; }
    public string Block { get; set; }
    public string CountyName { get; set; }
    public Nullable<decimal> MIP { get; set; }
    public Nullable<decimal> GrossAcres { get; set; }
   

}


public class AcreageReportDeck
{
    public int SNO { get; set; }
    public string DeckName { get; set; }
    public int LocationDataID { get; set; }
    public Nullable<decimal> DBRLeasehold { get; set; }
    public Nullable<decimal> DBRLeasedAcreage { get; set; }
    public Nullable<decimal> DBRHBPAcreage { get; set; }
    public Nullable<decimal> LeasedAcres { get; set; }
    public Nullable<decimal> HBPNetAcres { get; set; }
}

public class AcreageReportWell
{
    public int SNO { get; set; }
    public int LocationDataID { get; set; }
    public string WellName { get; set; }
    public decimal DBRWI { get; set; }
    public decimal DBRNRI { get; set; }

}
#endregion  'Class to make well based custom grouping'

#region 'class to Make blank next row'
public class AcearageReportCheck
{

    public int LocationDataId { get; set; }
    public List<AcearageReportWell> AcearageReportWell { get; set; }
    public List<AcearageReportDeck> AcearageReportDeck { get; set; }

}
public class AcearageReportWell
{

    public int LocationDataId { get; set; }
    public int WellId { get; set; }
    public string WellName { get; set; }


}
public class AcearageReportDeck
{
    public int LocationDataId { get; set; }
    public int DeckId { get; set; }
    public string DeckName { get; set; }


}
#endregion 'class to Make blank next row'