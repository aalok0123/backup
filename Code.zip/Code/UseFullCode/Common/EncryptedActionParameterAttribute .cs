﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading;
using System.Web.Mvc;
 
using System.Security.Cryptography;
using System.IO;
using OGWM.Data.Common;
using OGWM.UI.Common;
using OGWM.UI.Controllers;
using System.Web.Routing;

namespace OGWM.UI.Common
{

    public class EncryptedActionParameterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {
                List<int> idList = new List<int>();
                string slug;
                int id = 0;
                if (filterContext.ActionDescriptor.ControllerDescriptor.ControllerName == "Facility")
                {
                    slug = filterContext.ActionParameters["encryptedId"] as string;
                    if (slug != null)
                    {
                        id = Convert.ToInt32(Encryption.Decrypt(slug.Replace('(', '/').Replace(')','+').Replace('{','=')));
                        idList = BaseCommonFunction.GetFacilitys().Select(x => x.FacilityID).ToList();
                        if (idList.Contains(id))
                        {
                            filterContext.ActionParameters["id"] = id;
                        }
                        else
                        {
                            filterContext.ActionParameters["encryptedId"] = null;
                            filterContext.ActionParameters["id"] = null;
                            filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary {{ "Controller", "Facility" }, { "Action", "FacilityInfo" } });
                            
                        }
                    }
                }
                else if (filterContext.ActionDescriptor.ControllerDescriptor.ControllerName == "Prospects")
                {
                      slug = filterContext.RouteData.Values["id"] as string;
                      if (slug != null)
                      {
                         var  stringIdList = BaseCommonFunction.GetProspects().Select(x => x.ProspectID.ToString()).ToList();
                         var stringId = Encryption.Decrypt(slug.Replace('(', '/').Replace(')', '+').Replace('{', '='));
                           if (stringIdList.Contains(stringId))
                        {
                            filterContext.ActionParameters["id"] = stringId;
                        }
                           else
                           {
                               filterContext.ActionParameters["id"] = null;
                            filterContext.RouteData.Values["id"] = null;
                                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary {{ "Controller", "Prospects" }, { "Action", "ProspectInfo" } });
                           }
                      }
                }
                else if (filterContext.ActionDescriptor.ControllerDescriptor.ControllerName == "Wells")
                {
                      slug = filterContext.RouteData.Values["id"] as string;
                      if (slug != null)
                      {
                     idList = BaseCommonFunction.GetWells().Select(x => x.WellID).ToList();
                     id = Convert.ToInt32(Encryption.Decrypt(slug.Replace('(', '/').Replace(')', '+').Replace('{', '=')));
                           if (idList.Contains(id))
                        {
                            filterContext.ActionParameters["id"] = id;
                        }
                           else
                           {
                               filterContext.ActionParameters["id"] = null;
                            filterContext.RouteData.Values["id"] = null;
                                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary {{ "Controller", "Wells" },{ "Action", "WellsInfo" } });       
                           }
                      }
                }
                   
            }
            catch
            {
                if (filterContext.ActionDescriptor.ControllerDescriptor.ControllerName == "Prospects")
                {
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary {{ "Controller", "Prospects" }, { "Action", "ProspectInfo" } });
                    //HttpContext.Current.Response.Redirect("/Prospects/ProspectInfo");
                }
                else if (filterContext.ActionDescriptor.ControllerDescriptor.ControllerName == "Wells")
                {
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary {{ "Controller", "Wells" }, { "Action", "WellsInfo" } });
                    //HttpContext.Current.Response.Redirect("/Wells/WellsInfo");
                }
                else if (filterContext.ActionDescriptor.ControllerDescriptor.ControllerName == "Facility")
                {
                    filterContext.ActionParameters["encryptedId"] = null;
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary {{ "Controller", "Facility" }, { "Action", "FacilityInfo" } });
                }
                filterContext.ActionParameters["id"] = null;
                filterContext.RouteData.Values["id"] = null;
            }
                   
            base.OnActionExecuting(filterContext);
        }
    }
    public class EncryptedActionParameter_LeaseAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {
                var  tempLeaseid =0;
                string slug;
                int id = 0;
                if (filterContext.ActionDescriptor.ControllerDescriptor.ControllerName == "Leases")
                {
                    slug = filterContext.ActionParameters["id"] as string;
                    if (slug != null)
                    {
                        id = Convert.ToInt32(Encryption.Decrypt(slug.Replace('(', '/').Replace(')', '+').Replace('{', '=')));
                        try
                        {
                            tempLeaseid = BaseCommonFunction.GetLeases().Where(u => u.LeaseID == id).FirstOrDefault().LeaseID;
                        }
                        catch (Exception)
                        { 
                        }
                        if (tempLeaseid > 0)
                        {
                            filterContext.ActionParameters["id"] = id.ToString();
                        }
                        //else
                        //{
                        //    filterContext.ActionParameters["encryptedId"] = null;
                        //    filterContext.ActionParameters["id"] = null;
                        //    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "Controller", "Leases" }, { "Action", "Main" } });

                        //}
                    }
                } 

            }
            catch
            {
                //if (filterContext.ActionDescriptor.ControllerDescriptor.ControllerName == "Leases")
                //{
                //    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "Controller", "Leases" }, { "Action", "Main" } }); 
                //} 
                //filterContext.ActionParameters["id"] = null;
                //filterContext.RouteData.Values["id"] = null;
            }

            base.OnActionExecuting(filterContext);
        }
    }
    }
