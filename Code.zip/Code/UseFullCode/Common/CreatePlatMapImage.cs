﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OGWM.Spatial;
using System.Configuration;
using System.Web.Configuration;
using OGWM.Data.Common;
using OGWM.Spatial.PlatMap;
using System.Drawing;
using System.IO;
using OGWM.Entities;
using OGWM.Business.Admin;

namespace OGWM.UI.Common
{
    public class CreatePlatMapImage
    {
        #region Properties Declaration 
        /// <summary>
        /// ConnectionsStringSettings that will be used by ogwm.spatial
        /// </summary>
        public ConnectionStringSettings ConnectionStringSettings { get; set; }
        /// <summary>
        /// Id of entity like wellid, leaseid, prospectid etc
        /// </summary>
        public int EntityId { get; set; }
        /// <summary>
        /// Type of entity like well, lease, prospect etc
        /// </summary>
        public string EntityType { get; set; }
        /// <summary>
        /// ImageBytes that is created
        /// </summary>
        public byte[] ImageBytes { get; set; }
        /// <summary>
        /// Id of current user who is logged in into system
        /// </summary>
        public int CurrentUserId { get; set; }

        public bool isImageCreated { get; set; }

        #endregion 

        /// <summary>
        /// Constructor to initailize the connection string
        /// </summary>
        public CreatePlatMapImage()
        {
            ConnectionStringSettings = ConfigurationManager.ConnectionStrings["default"];
            isImageCreated = false;
        }
        /// <summary>
        /// This method uses ogwm.spatial to create plat map image
        /// </summary>
        /// <returns>true if image creation and saving completed successfully false otherwise</returns>
        public bool createImage()
        {
           
            //If entity has no tracts then plat map image can not be created
            if (!chkEntityHasTracts()) return false;
           
            try
            {
                //Run the ogwm.spatial wpf code in a seprate STA thread
                System.Threading.Thread thread = new System.Threading.Thread(() =>
                {
                    
                    ImageBytes = GeometryToImage.Convert(ConnectionStringSettings
                            , Convert.ToUInt32(EntityId), EntityType, CommonClass.ImageWidth, CommonClass.ImageHeight);

                    if (ImageBytes != null && ImageBytes.Length > 0)
                    {
                        saveImage();
                        ExceptionHandling.LogText("Image created and saved.", "");
                        isImageCreated = true;

                    }

                    else isImageCreated = false;

                });
                thread.SetApartmentState(System.Threading.ApartmentState.STA);
                thread.Start();
                thread.Join();

                
            }
            catch (Exception ex)
            {
                ExceptionHandling.LogText("Plat map image could not be created for entity id=+"+EntityId+" and type="+EntityType
                        , "\n" + ex.Message.ToString() + "\n" + ex.StackTrace);
                return false;
            }
            
            return true;
        }
        public bool createImage1()
        {

            //If entity has no tracts then plat map image can not be created
            if (!chkEntityHasTracts()) return false;

            try
            {
                //Run the ogwm.spatial wpf code in a seprate STA thread
               
                ImageBytes = GeometryToImage.Convert(ConnectionStringSettings , Convert.ToUInt32(EntityId), EntityType, CommonClass.ImageWidth, CommonClass.ImageHeight);

                if (ImageBytes != null && ImageBytes.Length > 0)
                {
                    saveImage();
                    isImageCreated = true;
                }

            }
            catch (Exception ex)
            {
                ExceptionHandling.LogText("Plat map image could not be created for entity id=+" + EntityId + " and type=" + EntityType , "\n" + ex.Message.ToString() + "\n" + ex.StackTrace);
                return false;
            }

            return true;
        }
        /// <summary>
        /// Insert the plat map image into database
        /// </summary>
        void saveImage()
        {
            //get record for this entityId and entityType to check if they exists
            var query = new PlatMapImagesManager().GetByParentIdID(Convert.ToInt32(EntityId), EntityType);
            if (query==null)//Record does not already exists in database
            {
                query = new PlatMapImage();
                query.ParentId = Convert.ToInt32(EntityId);
                query.ImageTypeFor = EntityType;
                query.flag = false;
                query.BinaryImage = ImageBytes;
                query.CreatedBy = CurrentUserId;
                query.CreateDate = DateTime.Now;
                new PlatMapImagesManager().Add(query);
            }
            else//record already exists in database
            {
                query.ParentId = Convert.ToInt32(EntityId);
                query.ImageTypeFor = EntityType;
                query.flag = false;
                query.BinaryImage = ImageBytes;
                query.ModifiedBy = CurrentUserId;
                query.ModifiedDate = DateTime.Now;
                new PlatMapImagesManager().Update(query);
            }
        }

        /// <summary>
        /// This method checks if the entity has any tracts
        /// </summary>
        /// <returns></returns>
        bool chkEntityHasTracts()
        {
            var tracts = new LocationDataManager().GetByParentIDAndType(EntityId, EntityType);
            if (tracts == null || tracts.Count() == 0)
            {
                var query = new PlatMapImagesManager().GetByParentIdID(Convert.ToInt32(EntityId), EntityType);
                if (query != null)//Record does not already exists in database
                {
                    query.flag = false;
                    query.ModifiedBy = CurrentUserId;
                    query.ModifiedDate = DateTime.Now;
                    new PlatMapImagesManager().Update(query);
                }
                return false;
            }
            else return true;
        }
        
    }
}