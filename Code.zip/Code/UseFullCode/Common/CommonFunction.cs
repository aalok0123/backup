﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using OGWM.Data.Common;
using System.Text;
using System.Xml.Linq;
using NPOI.HSSF.UserModel;
using OGWM.Entities;
using OGWM.Business.Admin;
using System.Data;
using System.Reflection;
using OGWM.ViewModel;


namespace OGWM.UI.Common
{
    [NoCache]
    public class CommonFunction
    {
        public static DataTable CreateLocationTable()
        {
            DataTable LocationTable = new DataTable();
            LocationTable.Columns.Add("LocationId", typeof(int));
            return LocationTable;
        }
        public static DataTable CreateTable()
        {
            DataTable LocationTable = new DataTable();
            LocationTable.Columns.Add("Item", typeof(int));
            return LocationTable;
        }

        public static byte[] ConvertHTMLToPDFLandscap(string HtmlText, string Path, string FileName, bool isHeader, float marginLeft = 5, float marginRight = 4, float marginTop = 5, float marginBottom = 1)
        {
            var pageSize = new iTextSharp.text.Rectangle(1224f, 792f);
            var document = new Document(pageSize, marginLeft, marginRight, marginTop, marginBottom);
            MemoryStream memStream = new MemoryStream();
            PdfWriter.GetInstance(document, memStream); ;
            document.Open();
            document.NewPage();
            for (int sheet = 1; sheet <= 1; sheet++)
            {
                if (!string.IsNullOrEmpty(HtmlText))
                {
                    //make an arraylist ....with STRINGREADER since its no IO reading file...  
                    List<IElement> htmlarraylist = HTMLWorker.ParseToList(new StringReader(HtmlText), null);
                    //add the collection to the document
                    PdfPTable table = new PdfPTable(1);
                    for (int k = 0; k < htmlarraylist.Count; k++)
                    {
                        if (isHeader)
                        {
                            if (htmlarraylist[k] is PdfPTable)
                            {
                                PdfPTable PT = (PdfPTable)htmlarraylist[k];
                                PT = pdfpTableOutline(PT);
                                PT.HeaderRows = 3;
                            }
                        }
                        document.Add((IElement)htmlarraylist[k]);
                    }
                    document.Add(table);
                }
            }
            document.Close();
            return memStream.ToArray();
        }

        public static void ConvertHTMLToPDF(string HtmlText, string Path, string FileName, bool isHeader, float marginLeft = 5, float marginRight = 4, float marginTop = 5, float marginBottom = 1)
        {
            var document = new Document(PageSize.LETTER, marginLeft, marginRight, marginTop, marginBottom);
            document.SetPageSize(iTextSharp.text.PageSize.LETTER);

            if (!Directory.Exists(Path))
                Directory.CreateDirectory(Path);

            if (File.Exists(Path + "/" + FileName))
                File.Delete(Path + "/" + FileName);

            PdfWriter.GetInstance(document, new FileStream(Path + "/" + FileName, FileMode.Create));
            document.Open();
            document.NewPage();
            for (int sheet = 1; sheet <= 1; sheet++)
            {
                if (!string.IsNullOrEmpty(HtmlText))
                {
                    //make an arraylist ....with STRINGREADER since its no IO reading file...  
                    List<IElement> htmlarraylist = HTMLWorker.ParseToList(new StringReader(HtmlText), null);
                    //add the collection to the document
                    PdfPTable table = new PdfPTable(1);

                    for (int k = 0; k < htmlarraylist.Count; k++)
                    {
                        ///////////////This code sets the header on every pdf page////////////////////////
                        if (isHeader)
                        {
                            if (htmlarraylist[k] is PdfPTable)
                            {
                                PdfPTable PT = (PdfPTable)htmlarraylist[k];
                                PT = pdfpTableOutline(PT);
                                PT.HeaderRows = 3;
                            }
                        }
                        document.Add((IElement)htmlarraylist[k]);
                    }

                    document.Add(table);
                }
            }
            document.Close();
        }

        static PdfPTable pdfpTableOutline(PdfPTable PT)
        {
            int nullTopIndex = 3;
            int nullBottomIndex = 5;
            for (int i = 0; i < PT.Rows.Count; i++)
            {
                var cells = PT.Rows[i].GetCells();
                if (i == 0)
                {
                    cells[0].BorderWidthLeft = 0f;
                    cells[0].BorderWidthTop = 0f;
                    cells[0].BorderWidthRight = 0f;
                    cells[0].BorderWidthBottom = 0f;
                }
                else if (i == 1)
                {
                    cells[0].BorderWidthLeft = 0f;
                    cells[0].BorderWidthTop = 0f;
                    cells[0].BorderWidthRight = 0f;
                    cells[0].PaddingBottom = 10f;
                }
                else if (i == 2)
                {
                    cells[0].BorderWidthLeft = 0f;
                    cells[0].BorderWidthRight = 0f;
                    if (cells.Count() > 1)
                    {
                        cells[1].BorderWidthLeft = 0f;
                        cells[1].BorderWidthRight = 0f;
                    }

                    if (cells.Count() > 2)
                    {
                        cells[2].BorderWidthLeft = 0f;
                        cells[2].BorderWidthRight = 0f;
                    }

                    if (cells.Count() > 2)
                    {
                        cells[0].BorderWidthTop = cells[1].BorderWidthTop = cells[2].BorderWidthTop = 0f;
                        cells[0].PaddingBottom = cells[1].PaddingBottom = cells[2].PaddingBottom = 10f;
                    }
                    else if (cells.Count() > 1)
                    {
                        cells[0].BorderWidthTop = cells[1].BorderWidthTop = 0f;
                        cells[0].PaddingBottom = cells[1].PaddingBottom = 10f;
                    }
                    else
                    {
                        cells[0].BorderWidthTop = 0f;
                        cells[0].PaddingBottom = 10f;
                    }
                }
                else
                {
                    if (cells.Count() > 2)
                    {
                        if (cells[1] == null && cells[2] == null)
                        {
                            PdfPCell cBlank = new PdfPCell(new Phrase(" "));
                            cBlank.Colspan = 3;
                            cells[0] = cBlank;
                            if (i == nullTopIndex)
                            {
                                cells[0].BorderWidthLeft = 0f;
                                cells[0].BorderWidthRight = 0f;
                                cells[0].BorderWidthBottom = 0f;
                                cells[0].BorderWidthTop = 0f;
                                nullTopIndex += 3;
                            }
                            else if (i == nullBottomIndex)
                            {
                                cells[0].BorderWidthLeft = 0f;
                                cells[0].BorderWidthRight = 0f;
                                cells[0].BorderWidthBottom = 1f;
                                cells[0].BorderWidthTop = 0f;
                                nullBottomIndex += 3;
                            }
                        }
                        else
                        {
                            cells[0].BorderWidthLeft = 0f;
                            cells[0].BorderWidthRight = 0f;

                            if (cells.Count() > 2)
                            {
                                cells[2].BorderWidthLeft = 0f;
                                cells[2].BorderWidthRight = 0f;
                            }

                            if (cells.Count() > 2)
                            {
                                cells[0].BorderWidthTop = cells[1].BorderWidthTop = cells[2].BorderWidthTop = 0f;
                                cells[0].PaddingBottom = cells[1].PaddingBottom = cells[2].PaddingBottom = 0f;
                            }
                            else if (cells.Count() > 1)
                            {
                                cells[0].BorderWidthTop = cells[1].BorderWidthTop = 0f;
                                cells[0].PaddingBottom = cells[1].PaddingBottom = 0f;
                            }
                            else
                            {
                                cells[0].BorderWidthTop = 0f;
                                cells[0].PaddingBottom = 0f;
                            }
                        }
                    }
                    else
                    {
                        cells[0].BorderWidthLeft = 0f;
                        cells[0].BorderWidthRight = 0f;

                        cells[0].BorderWidthTop = 0f;
                        cells[0].PaddingBottom = 0f;
                    }
                }
            }
            PT.KeepTogether = true;
            return PT;
        }

        public static string wordString(string toConvert)
        {
            StringBuilder sbBody = new System.Text.StringBuilder();
            sbBody.Append("<html " +
          "xmlns:o='urn:schemas-microsoft-com:office:office' " +
          "xmlns:w='urn:schemas-microsoft-com:office:word'" +
          "xmlns='http://www.w3.org/TR/REC-html40'>" +
          "<head><title>Time</title>");

            //The setting specifies document's view after it is downloaded as Print
            //instead of the default Web Layout
            sbBody.Append("<!--[if gte mso 9]>" +
                                     "<xml>" +
                                     "<w:WordDocument>" +
                                     "<w:View>Print</w:View>" +
                                     "<w:Zoom>100</w:Zoom>" +
                                     "<w:DoNotOptimizeForBrowser/>" +
                                     "</w:WordDocument>" +
                                     "</xml>" +
                                     "<![endif]-->");

            sbBody.Append("<style>" +
                                    "<!-- /* Style Definitions */" +
                                    "   @page Section1" +
                                    "   {size:8.5in 11.0in; " +
                                    "   margin:1.0in 1.25in .75in 1.25in ; " +
                                    "   mso-header-margin:.5in; " +
                                    "   mso-footer-margin:.5in; mso-paper-source:0;mso-header: h1;}" +
                                    "   div.Section1" +
                                    "   {page:Section1;}" +

                                    @" div.WordSection2
                                    {
                                        page: WordSection2;
                                       
                                    }
                                    p.MsoHeader, li.MsoHeader, div.MsoHeader
                                    {margin:0in;
                                    margin-bottom:.0001pt;
                                    mso-pagination:widow-orphan;
                                    tab-stops:center 3.0in right 6.0in;
                                    font-size:12.0pt;
                                    font-family:'Times New Roman';}
                                    p.MsoNormal
                                    {
                                        margin-bottom: .0001pt;
                                        font-size: 12.0pt;
                                        font-family: 'Times New Roman' , 'serif';
                                        margin-left: 0in;
                                        margin-right: 0in;
                                        margin-top: 0in;
                                    }
                                    p.MsoBodyTextIndent2
                                    {
                                        margin-top: 0in;
                                        margin-right: 0in;
                                        margin-bottom: 6.0pt;
                                        margin-left: .10in;
                                        line-height: 200%;
                                        font-size: 12.0pt;
                                        font-family: 'Times New Roman' , 'serif';
                                    }
                                    div.MsoBodyText
                                    {
                                        margin-bottom: .0001pt;
                                        text-align: justify;
                                        line-height: 97%;
                                        font-size: 11.0pt;
                                        font-family: 'Times New Roman' , 'serif';
                                        margin-left: 0in;
                                        margin-right: 0in;
                                        margin-top: 0in;
                                    }
        
                                    p.MsoBodyText
                                    {
                                        margin-bottom: .0001pt;
                                        text-align: justify;
                                        line-height: 97%;
                                        font-size: 11.0pt;
                                        font-family: 'Times New Roman' , 'serif';
                                        margin-left: 0in;
                                        margin-right: 0in;
                                        margin-top: 0in;
                                    }
       
                                    p.MsoBodyTextIndent
                                    {
                                        margin-top: 0in;
                                        margin-right: 0in;
                                        margin-bottom: 6.0pt;
                                        margin-left: .25in;
                                        font-size: 12.0pt;
                                        font-family: 'Times New Roman' , 'serif';
                                    }
                                    div.MsoBodyTextIndent2
                                    {
                                        margin-top: 0in;
                                        margin-right: 0in;
                                        margin-bottom: 6.0pt;
                                        margin-left: .25in;
                                        line-height: 200%;
                                        font-size: 12.0pt;
                                        font-family: 'Times New Roman' , 'serif';
                                    }
                                     h6
                                     {
                                         margin-top: 10.0pt;
                                         margin-right: 0in;
                                         margin-bottom: 0in;
                                         margin-left: 0in;
                                         margin-bottom: .0001pt;
                                         page-break-after: avoid;
                                         font-size: 12.0pt;
                                         font-family: 'Cambria' , 'serif';
                                         color: #243F60;
                                         font-weight: normal;
                                         font-style: italic;
                                     }
                                     .style1
                                     {
                                         line-height: 95%;
                                         font-size: 12.0pt;
                                         font-family: 'Times New Roman' , serif;
                                         margin-left: 0in;
                                         margin-right: 0in;
                                         margin-top: 0in;
                                         margin-bottom: .0001pt;
                                     }
                                    div.MsoBodyTextIndent
                                    {
                                        margin-top: 0in;
                                        margin-right: 0in;
                                        margin-bottom: 6.0pt;
                                        margin-left: .25in;
                                        font-size: 12.0pt;
                                        font-family: 'Times New Roman' , 'serif';
                                    }" +
                                   "</style></head>");

            sbBody.Append("<body lang=EN-US style='tab-interval:.5in'>" +

                @"<div style='mso-element:header' id=h1><p class=MsoHeader><span style='mso-tab-count:1'></span>
                                <span style='mso-field-code:' PAGE ''></span>   </p>      </div>" +
                                    "<div class=Section1>" +
                                    toConvert);

            sbBody.Append("</div></body></html>");
            return sbBody.ToString();
        }

        public static MemoryStream createExcel<t>(List<t> orders) where t : class
        {
            //Get the data representing the current grid state
            //var orders = (List<t>)Session[sessionName];
            //Create new Excel workbook
            var workbook = new HSSFWorkbook();
            //Create new Excel sheet
            var sheet = workbook.CreateSheet();
            var headerRow = sheet.CreateRow(0);
            var classObject = Activator.CreateInstance(typeof(t)) as t;
            int colCount = 0;
            foreach (var item in classObject.GetType().GetProperties())
            {
                sheet.SetColumnWidth(colCount, 30 * 256);
                headerRow.CreateCell(colCount).SetCellValue(item.Name);
                colCount = colCount + 1;
            }

            //(Optional) freeze the header row so it is not scrolled
            sheet.CreateFreezePane(0, 1, 0, 1);
            int rowNumber = 1;
            //Populate the sheet with values from the grid data
            foreach (t order in orders)
            {
                //Create a new row
                var row = sheet.CreateRow(rowNumber++);
                colCount = 0;
                //Set values for the cells
                foreach (var item in classObject.GetType().GetProperties())
                {
                    row.CreateCell(colCount).SetCellValue(Convert.ToString(item.GetValue(order, null)));
                    colCount = colCount + 1;
                }
            }
            //Write the workbook to a memory stream
            MemoryStream output = new MemoryStream();
            workbook.Write(output);
            //Return the result to the end user
            return output;
        }

        public static int GetpaperVisionId(string FieldName, string FieldValue, string FileName, byte[] Message)
        {
            string MineType = "text/plain";
            switch (Path.GetExtension(FileName).ToLower())
            {
                case "doc":
                    MineType = "application/msword";
                    break;
                case "xls":
                    MineType = "application/vnd.ms-excel";
                    break;
                case "pdf":
                    MineType = "application/pdf";
                    break;
                default:
                    FieldName = FieldName + ".txt";
                    MineType = "text/plain";
                    break;
            }
            return new DocumentManager().SetAttachement(Message, FileName, 0, MineType);
        }

        public static byte[] GetBinaryFile(string fileName)
        {
            if (File.Exists(fileName))
            {
                try
                {
                    FileStream fs = File.OpenRead(fileName);
                    return ConvertStreamToByeBuffer(fs);
                }
                catch
                {
                    return new byte[0];
                }
            }
            else
            {
                return new byte[0];
            }
        }

        // write image to memory as a strem of bytes
        private static byte[] ConvertStreamToByeBuffer(FileStream imgStream)
        {
            int imgByte;
            MemoryStream tempStream = new MemoryStream();
            while ((imgByte = imgStream.ReadByte()) != -1)
            {
                tempStream.WriteByte(((byte)imgByte));
            }
            return tempStream.ToArray(); // convert to array of bytes
        }

        /// <summary>
        /// This method converts the plat map image and its information into 
        /// a pdf file saves that into disk reads its file bytes and 
        /// then removes it from disk.
        /// </summary>
        /// <param name="HtmlText"></param>
        /// <param name="Path"></param>
        /// <param name="FileName"></param>
        public static MemoryStream ConvertHTMLToPDF(string HtmlText)
        {
            bool isHeader = true; float marginLeft = 5; float marginRight = 4; float marginTop = 5; float marginBottom = 1;
            //Path = AppDomain.CurrentDomain.BaseDirectory + Path;
            var document = new Document(PageSize.B0, marginLeft, marginRight, marginTop, marginBottom);
            document.SetPageSize(iTextSharp.text.PageSize.B0);
            /////////////
            MemoryStream outputStream = new MemoryStream();
            MemoryStream workStream = new MemoryStream();
            ////////////////
            //if (!Directory.Exists(Path))
            //    Directory.CreateDirectory(Path);

            //if (File.Exists(Path + "/" + FileName))
            //{
            //    File.Delete(Path + "/" + FileName);
            //}
            //PdfWriter.GetInstance(document, new FileStream(Path + "/" + FileName, FileMode.Create));
            PdfWriter.GetInstance(document, workStream);
            document.Open();
            document.NewPage();
            for (int sheet = 1; sheet <= 1; sheet++)
            {
                if (!string.IsNullOrEmpty(HtmlText))
                {
                    //make an arraylist ....with STRINGREADER since its no IO reading file...  
                    List<IElement> htmlarraylist = HTMLWorker.ParseToList(new StringReader(HtmlText), null);
                    //add the collection to the document
                    for (int k = 0; k < htmlarraylist.Count; k++)
                    {
                        //////////////////////////////////////////////////////////////////////////////////
                        ///////////////This code sets the header on every pdf page////////////////////////
                        if (isHeader)
                        {
                            if (htmlarraylist[k] is PdfPTable)
                            {
                                PdfPTable PT = (PdfPTable)htmlarraylist[k];
                                PT = pdfpTableOutline(PT);
                                PT.HeaderRows = 3;
                            }
                        }
                        //////////////////////////////////////////////////////////////////////////////////
                        document.Add((IElement)htmlarraylist[k]);
                    }
                }
            }
            document.Close();
            byte[] byteInfo = workStream.ToArray();
            outputStream.Write(byteInfo, 0, byteInfo.Length);
            outputStream.Position = 0;
            return outputStream;
        }

        private static StyleSheet GenerateStyleSheet()
        {
            try
            {
                FontFactory.Register(@"c:\windows\fonts\times.ttf", "Times New Roman");
            }
            catch (Exception){}
            StyleSheet css = new StyleSheet();
            css.LoadTagStyle("body", "font-family", "Times New Roman");   
            return css;
        }

        public static byte[] ExportPdf(string htmlText, float marginLeft = 5, float marginRight = 4, float marginTop = 5, float marginBottom = 1, string PageSizes = "Letter", string PageOrientation = "LANDSCAPE")
        {
            Font PageNumberFont = FontFactory.GetFont("Times New Roman", 11, Font.NORMAL, BaseColor.BLACK);
            Document document = null;
            if (PageOrientation == "LANDSCAPE")
            {
                if (PageSizes.ToUpper().Trim() == "LEGAL")
                {
                    document = new Document(PageSize.LEGAL.Rotate(), marginLeft, marginRight, marginTop, marginBottom);
                }
                else if (PageSizes.ToUpper().Trim() == "LETTER")
                {
                    document = new Document(PageSize.LETTER.Rotate(), marginLeft, marginRight, marginTop, marginBottom);
                }
                else
                {
                    document = new Document(new iTextSharp.text.Rectangle(1224f, 792f), marginLeft, marginRight, marginTop, marginBottom);
                }
            }
            else
            {
                if (PageSizes.ToUpper().Trim() == "LEGAL")
                {
                    document = new Document(PageSize.LEGAL, marginLeft, marginRight, marginTop, marginBottom);
                }
                else if (PageSizes.ToUpper().Trim() == "LETTER")
                {
                    document = new Document(PageSize.LETTER, marginLeft, marginRight, marginTop, marginBottom);
                }
                else
                {
                    document = new Document(new iTextSharp.text.Rectangle(792f, 1224f), marginLeft, marginRight, marginTop, marginBottom);
                }
            }
            htmlText = new PDFDocumetFontFactory(document.PageSize.Width, document.PageSize.Height).GetHtmlStringWithResponsiveFontSize(htmlText);

            MemoryStream memStream = new MemoryStream();
            PdfWriter.GetInstance(document, memStream);
            document.Open();
            document.NewPage();
            if (htmlText.EndsWith("<br/><br/>"))
                htmlText = htmlText.Remove(htmlText.LastIndexOf("<br/><br/>"));
            List<IElement> htmlarraylist = HTMLWorker.ParseToList(new StringReader(htmlText), GenerateStyleSheet());
            foreach (IElement el in htmlarraylist)
            {
                if (el is PdfPTable)
                {
                    ((PdfPTable)el).HeaderRows = 5;
                }
               
                document.Add(el);
            }
            document.Close();
            var bytes = memStream.ToArray();
            using (MemoryStream stream = new MemoryStream())
            {
                PdfReader reader = new PdfReader(bytes);
                using (PdfStamper stamper = new PdfStamper(reader, stream))
                {
                    int pages = reader.NumberOfPages;
                    for (int i = 1; i <= pages; i++)
                    {
                        ColumnText.ShowTextAligned(stamper.GetUnderContent(i), Element.ALIGN_CENTER, new Phrase(String.Format("{0} of {1}", i, pages), PageNumberFont), document.PageSize.Width -50, document.PageSize.Height -30, 0);
                    }
                }
                bytes = stream.ToArray();
            }
            return bytes;
        }

        public static void insertSentEmailDetails(string emailType, int contactId)
        {
            SentEmailsDetail obj = new SentEmailsDetail();
            obj.ContactId = contactId;
            obj.EmailType = emailType;
            obj.DateSent = DateTime.Now;
            obj.SentByUserId = Convert.ToInt32(HttpContext.Current.Session["UserId"]);
            new SentEmailsDetailManager().Add(obj);
        }

        public static DataTable resort(DataTable dt, string colName, string direction)
        {
            dt.DefaultView.Sort = colName + " " + direction;
            dt = dt.DefaultView.ToTable();
            return dt;
        }

        public static string setDateFormat(string value)
        {
            var dateString = value as string;
            if (string.IsNullOrWhiteSpace(dateString))
            {
                return value;
            }
            DateTime result;
            var success = DateTime.TryParse(dateString, out result);
            if (success)
            {
                return result.ToString("MM/dd/yyyy");
            }
            else
            {
                return value;
            }
        }


        public static MemoryStream CreateExcelObject<t>(List<t> orders) where t : class
        {
            //Create new Excel workbook
            var workbook = new HSSFWorkbook();
            //Create new Excel sheet
            var sheet = workbook.CreateSheet();
            var headerRow = sheet.CreateRow(0);
            var classObject = Activator.CreateInstance(typeof(t)) as t;
            int colCount = 0;
            foreach (var item in classObject.GetType().GetProperties())
            {
                sheet.SetColumnWidth(colCount, 30 * 256);
                headerRow.CreateCell(colCount).SetCellValue(item.Name);
                colCount = colCount + 1;
            }

            //(Optional) freeze the header row so it is not scrolled
            sheet.CreateFreezePane(0, 1, 0, 1);
            int rowNumber = 1;
            //Populate the sheet with values from the grid data
            foreach (t order in orders)
            {
                //Create a new row
                var row = sheet.CreateRow(rowNumber++);
                colCount = 0;
                //Set values for the cells
                foreach (var item in classObject.GetType().GetProperties())
                {
                    row.CreateCell(colCount).SetCellValue(Convert.ToString(item.GetValue(order, null)));
                    colCount = colCount + 1;
                }
            }
            //Write the workbook to a memory stream
            MemoryStream output = new MemoryStream();
            workbook.Write(output);
            //Return the result to the end user
            return output;
        }

        public static string convertToXMLFormat(string inputString)
        {
            if (inputString == "") return "";
            List<string> lst = inputString.Split(',').ToList();
            XElement xmlElements = new XElement("typeTables", lst.Select(i => new XElement("typeTable", new XElement("Item", (i).Trim()))));
            return xmlElements.ToString();
        }

        public static string convertFlowbackWellsToXMLFormat(List<GetFlowbackWellsByAMIsInfo> lFlowbackWells)
        {

            if (lFlowbackWells == null) return "";
            XElement xmlElements = new XElement("FlowbackWells",
                                                    lFlowbackWells.Select(i =>
                                                        new XElement("FlowbackWell",
                                                                new XElement("SlNo", i.SlNo),
                                                                new XElement("WellId", i.WellId),
                                                                new XElement("WellName", i.WellName),
                                                                new XElement("Day", i.Day),
                                                                new XElement("BO", i.BO),
                                                                new XElement("MCF", i.MCF),
                                                                new XElement("BW", i.BW),
                                                                new XElement("BOE", i.BOE),
                                                                new XElement("BOEValue", i.BOEValue),
                                                                new XElement("Comments", i.Comments)
                                                            )
                                                    )
                                                );
            return xmlElements.ToString();
        }

        public static string convertAMINoteToXMLFormat(List<AMINote> lAMINote)
        {

            if (lAMINote == null) return "";
            XElement xmlElements = new XElement("AMINotes",
                                                    lAMINote.Select(i =>
                                                        new XElement("AMINote",
                                                                new XElement("AMIID", i.AMIID),
                                                                new XElement("AMI", i.AMI),
                                                                new XElement("Note", i.Note)
                                                            )
                                                    )
                                                );
            return xmlElements.ToString();
        }

        #region Vwf Graph

        public static DataTable convertToDataTableFormat(string inputString)
        {

            DataTable dataTable = new DataTable();
            DataColumn dataColumn = new DataColumn("ID");
            dataTable.Columns.Add(dataColumn);
            foreach (string row in inputString.Split(','))
            {
                DataRow dataRow = dataTable.NewRow();
                dataRow[0] = row;
                dataTable.Rows.Add(dataRow);
            }
            return dataTable;
        }

        public List<GetvwfMapSectionDataByMapBounds_Result> GetvwfMapSectionDataByMapBounds(string MapBounds)
        {
            return new VWFMapManager().GetvwfMapSectionDataByMapBounds(MapBounds);
        }

        public List<GetvwfMapBlockkDataByMapBoundsInfo> GetvwfMapBlockkDataByMapBounds(string MapBounds)
        {
            return new VWFMapManager().GetvwfMapBlockkDataByMapBounds(MapBounds);
        }

        public List<GetvwfMapProspectData_Result> GetvwfMapProspectData()
        {
            return new VWFMapManager().GetvwfMapProspectData();
        }

        public List<GetvwfMapCountyData_Result> GetvwfMapCountyData()
        {
            return new VWFMapManager().GetvwfMapCountyData();
        }
        public List<GetvwfMapLeaseData_Result> GetvwfMapLeaseData()
        {
            return new VWFMapManager().GetvwfMapLeaseData();
        }
        public List<GetvwfMapWellsData_Result> GetvwfMapWellsData()
        {
            return new VWFMapManager().GetvwfMapWellsData();
        }
        ////By Map Bounds
        public List<GetvwfMapProspectDataByMapBounds_Result> GetvwfMapProspectDataByMapBounds(string MapBounds)
        {
            return new VWFMapManager().GetvwfMapProspectDataByMapBounds(MapBounds);
        }

        public List<GetvwfMapCountyDataByMapBounds_Result> GetvwfMapCountyDataByMapBounds(string MapBounds)
        {
            return new VWFMapManager().GetvwfMapCountyDataByMapBounds(MapBounds);
        }
        public List<GetvwfMapLeaseDataByMapBounds_Result> GetvwfMapLeaseDataByMapBounds(string MapBounds)
        {
            return new VWFMapManager().GetvwfMapLeaseDataByMapBounds(MapBounds);
        }
        public List<GetvwfMapWellsDataByMapBounds_Result> GetvwfMapWellsDataByMapBounds(string MapBounds)
        {
            return new VWFMapManager().GetvwfMapWellsDataByMapBounds(MapBounds);
        }
        public List<GetvwfMapWellsDataByWellID_Result> GetvwfMapWellsDataByWellID(int WellID)
        {
            return new VWFMapManager().GetvwfMapWellsDataByWellID(WellID);
        }
        #endregion

    }
    public class PDFDocumetFontFactory
    {
        float DocumetnWidth = 0.0F;
        float DocumentHeight = 0.0F;
        const float Constant = 969408.0F;
        const float Tollerence = 2.0F;
        public PDFDocumetFontFactory(float DocumetnWidth, float DocumentHeight)
        {
            this.DocumetnWidth = DocumetnWidth;
            this.DocumentHeight = DocumentHeight;

        }

        public float TableFontSize
        {
            get
            {
                return ((DocumetnWidth * DocumentHeight * 13) / Constant) + Tollerence;
            }
        }
        public float MainHeaderRowFontSize
        {
            get
            {
                return ((DocumetnWidth * DocumentHeight * 11) / Constant) + Tollerence;
            }
        }

        public float GridHeaderRowFontSize
        {
            get
            {
                return ((DocumetnWidth * DocumentHeight * 9) / Constant) + Tollerence;
            }
        }

        public float GridContentFontSize
        {
            get
            {
                return ((DocumetnWidth * DocumentHeight * 8) / Constant) + Tollerence;
            }
        }

        public float PageNumberFontSize
        {
            get
            {
                return ((DocumetnWidth * DocumentHeight * 8) / Constant) + Tollerence;
            }
        }


        public string GetHtmlStringWithResponsiveFontSize( string HtmlString )
        {
          HtmlString=  HtmlString.Replace("[[Table-Font-Size]]", this.TableFontSize.ToString());
          HtmlString=  HtmlString.Replace("[[Main-Header-Row-Font-Size]]", this.MainHeaderRowFontSize.ToString());
          HtmlString=  HtmlString.Replace("[[Grid-Header-Row-Font-Size]]", this.GridHeaderRowFontSize.ToString());
          HtmlString=  HtmlString.Replace("[[Grid-Content-Font-Size]]", this.GridContentFontSize.ToString());
            return HtmlString;
        }

    }

}