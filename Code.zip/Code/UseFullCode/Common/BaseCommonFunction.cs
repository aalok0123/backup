﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OGWM.Business.Admin;

using System.Web.Mvc;
using OGWM.Entities;
using OGWM.Data.Common;
using OGWM.Enum;
using System.Web.Configuration;

namespace OGWM.UI.Common
{

    public static class BaseCommonFunction
    {
        //public static SharedTableView ApplicationSharedTables
        //{
        //    get
        //    {
        //        if (HttpContext.Current.Cache["ApplicationSharedTables"] == null)
        //        {
        //            FillApplicationSharedtables();
        //        }
        //        return (SharedTableView)HttpContext.Current.Cache["ApplicationSharedTables"];
        //    }
        //}

        public static string GetUrlPreFixSSl{
            get 
            {
                if (HttpContext.Current.Request.IsSecureConnection)
                    return "https";//WebConfigurationManager.AppSettings["PreFixSSL"].ToString();//PreFixSSL
                else
                    return "http";
             }
        }

        public static List<SelectListItem> GetAllRoles()
        {
            return GetRoles().Where(u => u.IsActive == true).Select(r => new SelectListItem() { Text = r.GroupName, Value = r.GroupID.ToString() }).OrderBy(o => o.Text).ToList();
        }

        public static List<Role> GetRoles()
        {
            if (WebConfigurationManager.AppSettings["IsCache"].ToString() == "true")
            {
                if (HttpContext.Current.Cache[SharedTable.ListRoles.ToString()] == null)
                {
                    using (RolesManager rm = new RolesManager())
                    {
                        HttpContext.Current.Cache[SharedTable.ListRoles.ToString()] = rm.GetAll();
                    }
                }
                return (List<Role>)HttpContext.Current.Cache[SharedTable.ListRoles.ToString()];
            }
            else {
                return new RolesManager().GetAll().ToList();
            }
        }

        public static List<UserMaster> GetUsers()
        {
            if (WebConfigurationManager.AppSettings["IsCache"].ToString() == "true")
            {
                if (HttpContext.Current.Cache[SharedTable.ListUserMaster.ToString()] == null)
                {
                    using (var rm = new UserMasterManager())
                    {
                        HttpContext.Current.Cache[SharedTable.ListUserMaster.ToString()] = rm.GetAll();
                    }
                }
                return (List<UserMaster>)HttpContext.Current.Cache[SharedTable.ListUserMaster.ToString()];
            }
            else {
                return new UserMasterManager().GetAll().ToList();
            }
        }
        
        #region Status

        public static List<SelectListItem> GetTitleStatus(string TitleGroup)
        {
           return GetTitleStatus().Where(Group => Group.TitleGroup == TitleGroup && Group.IsDeleted == false).Select(Titles => new SelectListItem() { Text = Titles.TitleName, Value = Titles.TitleId.ToString() }).OrderBy(o => o.Text).ToList();
        }

        public static List<SelectListItem> GetWellStatus(string TitleGroup)
        {
            return GetTitleStatus().Where(Group => Group.TitleGroup == TitleGroup && Group.IsDeleted == false).OrderBy(o => o.TitleId).Select(Titles => new SelectListItem() { Text = Titles.TitleName, Value = Titles.TitleId.ToString() }).ToList();
        }

        public static List<SelectListItem> GetTitleStatus(string TitleGroup, bool IncludeInReport)
        {
            return GetTitleStatus().Where(Group => Group.TitleGroup == TitleGroup && Group.IncludeInReport == IncludeInReport && Group.IsDeleted == false)
                         .Select(Titles => new SelectListItem() { Text = Titles.TitleName, Value = Titles.TitleId.ToString() }).OrderBy(o => o.Text).ToList();
        }

        public static string GetTitleStatusName(int? Id, string TitleName)
        {
            if (Id.HasValue)
            {
                var t = GetTitleStatus().Where(u => u.TitleId == Convert.ToInt32(Id)).FirstOrDefault();
                return t == null ? TitleName : t.TitleName;
            }
            else
                return TitleName;
        }

        public static List<TitleStatu> GetTitleStatus()
        {
            if (HttpContext.Current.Cache[SharedTable.TitleStatusInfo.ToString()] == null)
            {
                using (var rm = new TitleStatusManager())
                {
                    HttpContext.Current.Cache[SharedTable.TitleStatusInfo.ToString()] = rm.GetAll();
                }
            }
            return (List<TitleStatu>)HttpContext.Current.Cache[SharedTable.TitleStatusInfo.ToString()];
        }
        #endregion

        public static List<City> GetCitys()
        {
            if (HttpContext.Current.Cache[SharedTable.CitiesInfo.ToString()] == null)
            {
                using (CityManager rm = new CityManager())
                {
                    HttpContext.Current.Cache[SharedTable.CitiesInfo.ToString()] = rm.GetAll();
                }
            }
            return (List<City>)HttpContext.Current.Cache[SharedTable.CitiesInfo.ToString()];
        }

        public static List<GetAllCountiesInfo> GetCounty()
        {
            if (HttpContext.Current.Cache[SharedTable.CountiesInfo.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.CountiesInfo.ToString()] = (List<GetAllCountiesInfo>)rm.UpdateGlobelList(SharedTable.CountiesInfo);
                }
            }
            return (List<GetAllCountiesInfo>)HttpContext.Current.Cache[SharedTable.CountiesInfo.ToString()];
        }

        public static List<GetAllStatesInfo> GetStates()
        {
            if (HttpContext.Current.Cache[SharedTable.StatesInfo.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.StatesInfo.ToString()] = (List<GetAllStatesInfo>)rm.UpdateGlobelList(SharedTable.StatesInfo);
                }
            }
            return (List<GetAllStatesInfo>)HttpContext.Current.Cache[SharedTable.StatesInfo.ToString()];
        }

        public static List<PagePermission> GetPagePermissions()
        {
            if (HttpContext.Current.Cache[SharedTable.PagePermission.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.PagePermission.ToString()] = (List<PagePermission>)rm.UpdateGlobelList(SharedTable.PagePermission);
                }
            }
            return (List<PagePermission>)HttpContext.Current.Cache[SharedTable.PagePermission.ToString()];
        }

        public static List<AssigneeAndAssignor> GetAssigneeAndAssignors()
        {
            if (HttpContext.Current.Cache[SharedTable.AssigneeAndAssignorsInfo.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.AssigneeAndAssignorsInfo.ToString()] = (List<AssigneeAndAssignor>)rm.UpdateGlobelList(SharedTable.AssigneeAndAssignorsInfo);
                }
            }
            return (List<AssigneeAndAssignor>)HttpContext.Current.Cache[SharedTable.AssigneeAndAssignorsInfo.ToString()];
        }

        #region Notification

        public static List<NotificationReceiver> GetNotificationReceivers()
        {
            if (HttpContext.Current.Cache[SharedTable.ListNotificationReceiver.ToString()] == null)
            {
                using (var rm = new NotificationReceiverManager())
                {
                    HttpContext.Current.Cache[SharedTable.ListNotificationReceiver.ToString()] = rm.GetAll();
                }
            }
            return (List<NotificationReceiver>)HttpContext.Current.Cache[SharedTable.ListNotificationReceiver.ToString()];
        }

        public static List<NotificationProcess> GetNotificationProcesss()
        {
            if (HttpContext.Current.Cache[SharedTable.ListNotificationProcess.ToString()] == null)
            {
                using (var rm = new NotificationProcessManager())
                {
                    HttpContext.Current.Cache[SharedTable.ListNotificationProcess.ToString()] = rm.GetAll();
                }
            }
            return (List<NotificationProcess>)HttpContext.Current.Cache[SharedTable.ListNotificationProcess.ToString()];
        }

        #endregion

        #region Company

        public static List<SelectListItem> GetWellCompanyIDMaster(int TypeId)
        {
            return BaseCommonFunction.GetWellCompanys().Where(Group => Group.CompanyType == TypeId && Group.IsDeleted == false)
                         .Select(Titles => new SelectListItem() { Text = Titles.CompanyName, Value = Titles.CompanyId.ToString() }).OrderBy(o => o.Text).ToList();
        }
        
        public static List<SelectListItem> GetWellCompanyMaster(string Type)
        {
            return BaseCommonFunction.GetWellCompanys().Where(Group => Group.CompanyTypeName == Type && Group.IsDeleted == false)
                         .Select(Titles => new SelectListItem() { Text = Titles.CompanyName, Value = Titles.CompanyId.ToString() }).OrderBy(o => o.Text).ToList();
        }

        public static List<WellCompanyMaster> GetWellCompanys()
        {
            if (HttpContext.Current.Cache[SharedTable.WellCompanyMastersInfo.ToString()] == null)
            {
                using (var rm = new WellCompanyMasterManager())
                {
                    HttpContext.Current.Cache[SharedTable.WellCompanyMastersInfo.ToString()] = rm.GetAll();
                }
            }
            return (List<WellCompanyMaster>)HttpContext.Current.Cache[SharedTable.WellCompanyMastersInfo.ToString()];
        }

        public static List<LeaseCompany> GetLeaseCompanys()
        {
            if (HttpContext.Current.Cache[SharedTable.LeaseCompanyInfo.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.LeaseCompanyInfo.ToString()] = (List<LeaseCompany>)rm.UpdateGlobelList(SharedTable.LeaseCompanyInfo);
                }
            }
            return (List<LeaseCompany>)HttpContext.Current.Cache[SharedTable.LeaseCompanyInfo.ToString()];
        }

        #endregion

        //public static List<OperatorList> GetBNAMES()
        //{
        //    if (HttpContext.Current.Cache[SharedTable.BNAMEsInfo.ToString()] == null)
        //    {
        //        using (var rm = new SharedTableManager())
        //        {
        //            HttpContext.Current.Cache[SharedTable.BNAMEsInfo.ToString()] = (List<OperatorList>)rm.UpdateGlobelList(SharedTable.BNAMEsInfo);
        //        }
        //    }
        //    return (List<OperatorList>)HttpContext.Current.Cache[SharedTable.BNAMEsInfo.ToString()];
        //}

        public static List<GetOwnersFromBNameInfo> GetOwnersFromBName()
        {
            if (HttpContext.Current.Cache[SharedTable.OwnersFromBName.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    if (!string.IsNullOrEmpty(WebConfigurationManager.AppSettings["IsOwnerFromIntegra"]) && WebConfigurationManager.AppSettings["IsOwnerFromIntegra"].ToString() == "true")
                    {
                        HttpContext.Current.Cache[SharedTable.OwnersFromBName.ToString()] = new Integra().GetIntegraOwnerList().ToList();
                    }
                    else
                    {
                        HttpContext.Current.Cache[SharedTable.OwnersFromBName.ToString()] = (List<GetOwnersFromBNameInfo>)rm.UpdateGlobelList(SharedTable.OwnersFromBName);
                    }
                }
            }
            return (List<GetOwnersFromBNameInfo>)HttpContext.Current.Cache[SharedTable.OwnersFromBName.ToString()];
        }

        public static List<LesseeAndLessor> GetLesseeAndLessors()
        {
            if (HttpContext.Current.Cache[SharedTable.LesseeAndLessorsInfo.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.LesseeAndLessorsInfo.ToString()] = (List<LesseeAndLessor>)rm.UpdateGlobelList(SharedTable.LesseeAndLessorsInfo);
                }
            }
            return (List<LesseeAndLessor>)HttpContext.Current.Cache[SharedTable.LesseeAndLessorsInfo.ToString()];
        }

        public static List<DeckDetail> GetDeckDetails()
        {
            if (HttpContext.Current.Cache[SharedTable.DeckDetailsInfo.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.DeckDetailsInfo.ToString()] = (List<DeckDetail>)rm.UpdateGlobelList(SharedTable.DeckDetailsInfo);
                }
            }
            return (List<DeckDetail>)HttpContext.Current.Cache[SharedTable.DeckDetailsInfo.ToString()];
        }

        public static List<Facility> GetFacilitys()
        {
            if (HttpContext.Current.Cache[SharedTable.FacilitiesInfo.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.FacilitiesInfo.ToString()] = (List<Facility>)rm.UpdateGlobelList(SharedTable.FacilitiesInfo);
                }
            }
            return (List<Facility>)HttpContext.Current.Cache[SharedTable.FacilitiesInfo.ToString()];
        }

        public static List<Prospect> GetProspects()
        {
            if (HttpContext.Current.Cache[SharedTable.ProspectsInfo.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.ProspectsInfo.ToString()] = (List<Prospect>)rm.UpdateGlobelList(SharedTable.ProspectsInfo);
                }
            }
            return (List<Prospect>)HttpContext.Current.Cache[SharedTable.ProspectsInfo.ToString()];
        }

        public static List<Leas> GetLeases()
        {
            if (HttpContext.Current.Cache[SharedTable.LeasesInfo.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.LeasesInfo.ToString()] = (List<Leas>)rm.UpdateGlobelList(SharedTable.LeasesInfo);
                }
            }
            return (List<Leas>)HttpContext.Current.Cache[SharedTable.LeasesInfo.ToString()];
        }

        public static List<GetAllWellsInfo> GetWells()
        {
            if (HttpContext.Current.Cache[SharedTable.WellsInfo.ToString()] == null)
            {
                using (var rm = new SharedTableManager())
                {
                    HttpContext.Current.Cache[SharedTable.WellsInfo.ToString()] = (List<GetAllWellsInfo>)rm.UpdateGlobelList(SharedTable.WellsInfo);
                }
            }
            return (List<GetAllWellsInfo>)HttpContext.Current.Cache[SharedTable.WellsInfo.ToString()];
        }

        public static void ClearFromCache(SharedTable st)
        {
            HttpContext.Current.Cache.Remove(st.ToString());
        }

        public static IList<SelectListItem> GetOwnerList()
        {
            IList<SelectListItem> myList = GetOwnersFromBName()
                    .Select(s => new SelectListItem() { Text = s.OwnerName.Trim() + " - #" + s.OwnerId, Value = s.OwnerId })
                    .OrderBy(o => o.Text).ToList();
           
            if (myList == null)
                myList = new List<SelectListItem>();

            return myList;
        }

        public static IList<SelectListItem> GetAFETypeWell(string Type)
        {
            return new SharedTableManager().GetAFETypeWell(Type).Select(s => new SelectListItem() { Value = s.Value, Text = s.Text }).OrderBy(o=>o.Text).ToList();
        }

        public static IList<SelectListItem> GetListItems(string CmdName, SqlCmdType CommendType)
        {
            return new SharedTableManager().GetListItems(CmdName, CommendType).Select(s => new SelectListItem() { Value = s.Value, Text = s.Text }).OrderBy(o => o.Text).ToList();
        }
    }

}