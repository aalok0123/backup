﻿/********************************************************************************                                                                      
-- Stored Procedure: [pe].[UpdateUserNotifications]                                                                                                                                           
-- Copyright: Oil Gas Well Management                                                                                                                                         
-- Purpose: Update user notifications to set IsRead and IsDismissed
                                                                                                                                                                                                    
Date                    Author			  Description                                                                      
Created-14-Jan-2015     Vishal Yadav      Update user notifications to set IsRead and IsDismissed
*********************************************************************************/     

CREATE PROCEDURE [dbo].[UpdateUserNotifications]
    (
     @Type INT,
     @NotificationIds typeTable READONLY
    )
AS
    BEGIN
        SET NOCOUNT OFF
        IF (@Type = 1)-- Type=1 is for Dismiss
            BEGIN
                UPDATE  UserNotification
                SET     IsDismissed = 1,
                        DismissedDate = GETDATE()
                WHERE   UserNotificationID IN (SELECT   Item
                                               FROM     @NotificationIds)
            END
        ELSE
            BEGIN 
                UPDATE  UserNotification
                SET     IsRead = 1,
                        ReadDate = GETDATE()
                WHERE   UserNotificationID IN (SELECT   Item
                                               FROM     @NotificationIds)
            END
        SET NOCOUNT ON
    END
