﻿using System;
using System.Text;
using System.Collections;
using System.Linq;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Globalization;

namespace ActiveDirectory
{
    public class LdapAuthentication
    {
        private string _path;
        private string _filterAttribute;

        public LdapAuthentication(string path)
        {
            _path = path;
        }

        public bool IsAuthenticated(string domain, string username, string pwd)
        {
            string domainAndUsername = domain + @"\" + username;
            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pwd);
            try
            {
                //Bind to the native AdsObject to force authentication.
                object obj = entry.NativeObject;
                DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = "(SAMAccountName=" + username + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();
                if (null == result)
                {
                    return false;
                }
                //Update the new path to the user in the directory.
                _path = result.Path;
                _filterAttribute = (string)result.Properties["cn"][0];
            }
            catch (Exception ex)
            {
                throw new Exception("Error authenticating user. " + ex.Message);
            }
            return true;
        }

        public string GetGroups()
        {

            //string filterAttribute = "Administrator";
            DirectorySearcher search = new DirectorySearcher(_path);
            search.Filter = "(cn=" + _filterAttribute + ")";
            search.PropertiesToLoad.Add("memberOf");
            StringBuilder groupNames = new StringBuilder();

            try
            {
                SearchResult result = search.FindOne();
                int propertyCount = result.Properties["memberOf"].Count;
                string dn;
                int equalsIndex, commaIndex;

                for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
                {
                    dn = (string)result.Properties["memberOf"][propertyCounter];
                    equalsIndex = dn.IndexOf("=", 1);
                    commaIndex = dn.IndexOf(",", 1);
                    if (-1 == equalsIndex)
                    {
                        return null;
                    }
                    groupNames.Append(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1));
                    groupNames.Append("|");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error obtaining group names. " + ex.Message);
            }
            return groupNames.ToString();
        }

        #region Get User's group

        public string GetGroupForUser(string User)
        {
            //User = "Amit Kumar Singh";
            //string filterAttribute = "Administrator";
            DirectorySearcher search = new DirectorySearcher(_path);
            search.Filter = "(cn=" + User + ")";
            search.PropertiesToLoad.Add("memberOf");
            search.PropertiesToLoad.Add("memberof");
            search.PropertiesToLoad.Add("department");
            search.PropertiesToLoad.Add("cn");
            search.PropertiesToLoad.Add("sn");
            search.PropertiesToLoad.Add("name");
            search.PropertiesToLoad.Add("givenName");
            search.PropertiesToLoad.Add("samaccountname");
            StringBuilder groupNames = new StringBuilder();
            try
            {
                SearchResult result = search.FindOne();
                int propertyCount = result.Properties["memberOf"].Count;
                string dn;
                int equalsIndex, commaIndex;

                for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
                {
                    dn = (string)result.Properties["memberOf"][propertyCounter];
                    equalsIndex = dn.IndexOf("=", 1);
                    commaIndex = dn.IndexOf(",", 1);
                    if (-1 == equalsIndex)
                    {
                        return null;
                    }
                    groupNames.Append(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1));
                    groupNames.Append("|");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error obtaining group names. " + ex.Message);
            }
            return groupNames.ToString();
        }
        public String GetGroupUserName(String UserName, String Password, String Domain)
        {

            DirectoryEntry entry = new DirectoryEntry("LDAP://" + Domain, UserName, Password);
            DirectorySearcher search = new DirectorySearcher();
            search.SearchRoot = entry;
            search.Filter = "(SAMAccountName=" + UserName + ")";
            search.PropertiesToLoad.Add("memberOf");
            try
            {
                SearchResult result = search.FindOne();
                int propertyCount = result.Properties["memberOf"].Count;
                string dn = String.Empty;
                for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
                {
                    dn = (string)result.Properties["memberOf"][propertyCounter];
                    dn = dn.Remove(dn.LastIndexOf(",OU="));
                    dn = dn.Replace("CN=", "");
                }
                return dn;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static List<Principal> GetAuthGroupsforuser(string identityvalue)
        {
            // create context for domain
            PrincipalContext ctx = new PrincipalContext(ContextType.Domain);
            // find the user
            List<Principal> lst = null;
            UserPrincipal up = UserPrincipal.FindByIdentity(ctx, identityvalue);
            if (up != null)
            {
                //// get groups for that user
                List<Principal> lstAuth = up.GetAuthorizationGroups().ToList();
                lst = up.GetGroups().ToList();
                return lst;
            }
            return lst;
        }
        //This will return a list of strings which are the group names the user is a member of.
        public List<string> GetMemberOf(DirectoryEntry de)
        {
            List<string> memberof = new List<string>();

            foreach (object oMember in de.Properties["memberOf"])
            {
                memberof.Add(oMember.ToString());
            }

            return memberof;
        }
        public string[] GetRolesForUser(string username, string domain, string password)
        {
            var allRoles = new List<string>();
            string domainAndUsername = domain + @"\" + username;
            var root = new DirectoryEntry(_path, domainAndUsername, password);
            var searcher = new DirectorySearcher(root, string.Format(CultureInfo.InvariantCulture,
                "(&(objectClass=user)({0}={1}))", username));

            searcher.PropertiesToLoad.Add("memberOf");
            SearchResult result = searcher.FindOne();
            if (result != null && !string.IsNullOrEmpty(result.Path))
            {
                DirectoryEntry user = result.GetDirectoryEntry();
                PropertyValueCollection groups = user.Properties["memberOf"];
                foreach (string path in groups)
                {
                    string[] parts = path.Split(',');
                    if (parts.Length > 0)
                    {
                        foreach (string part in parts)
                        {
                            string[] p = part.Split('=');
                            if (p[0].Equals("cn", StringComparison.OrdinalIgnoreCase))
                            {
                                allRoles.Add(p[1]);
                            }
                        }
                    }
                }
            }
            return allRoles.ToArray();
        }

        #endregion


    }
}