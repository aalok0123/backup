

SELECT t.name AS table_name,
SCHEMA_NAME(schema_id) AS schema_name,
c.name AS column_name
FROM sys.tables AS t
INNER JOIN sys.columns c ON t.OBJECT_ID = c.OBJECT_ID
WHERE c.name LIKE '%Owner%'
ORDER BY schema_name, table_name;


-- Search in All Objects
SELECT OBJECT_NAME(OBJECT_ID),
definition
FROM sys.sql_modules
WHERE definition LIKE '%' + 'CreatedDate' + '%'
GO

-- Search in Stored Procedure Only
SELECT DISTINCT OBJECT_NAME(OBJECT_ID),	
object_definition(OBJECT_ID)
FROM sys.Procedures
WHERE object_definition(OBJECT_ID) LIKE '%' + 'Subsection' + '%'
-----------------------------------

select * from SurfaceOwnerDetails
select SectionForProspect, * from LocationData -- {Well alocation }
select * from MineralInterest;
select RoyaltyAmt, RoyaltyPercentage ,* from Leases-- mineral interest{mineral interest},RoyaltyInterest 

select Allocation,* from LocationData -- MineralInterestPercentage {mineral interest }

select * from Lease_Deck --{Lease Deck WIO}
select * from Lease_ORRI ;select ORRIPercentage from Leases--{Lease ORRI}

select * from LeaseORRI  -- LeaseBurdened {ORRI Burden} ; 
select interest ,* from Lease_ORRI  --{ORRIBurdenInterest }

 select * from WellNPRIOwnerDetail

 select WorkingInt, * from pe.ptsProductionPt -- {Well Working Interest}

 select NRI,* from pe.ProductionSummary --NRI ,{Well NRI}
 select * from Leases
 select * from  CountySurvey

 SELECT * FROM Counties


  select * from Owners
 
 

 

 












