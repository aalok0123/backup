--SET IDENTITY_INSERT [RRMMS].[dbo].State off
--insert into [RRMMS].[dbo].State (StateId,	StateAbbr,	StateName,	Geom)
--select StateId,	StateAbbr,	StateName,	Geom from [RMMSUAT].[dbo].state


--select  top 1 * from [RRMMS].[dbo].county

--CountyId,	CountyFP,	CountyName,	Geom,	StateId	,District


--SET IDENTITY_INSERT [RRMMS].[dbo].county off
--insert into [RRMMS].[dbo].county (CountyId,	CountyFP,	CountyName,	Geom,	StateId	,District)
--select CountyId,	CountyFP,	CountyName,	Geom,	StateId	,District from [RMMSUAT].[dbo].county

-- truncate table surveycounty
 --select top 1 * from [RMMSUAT].[dbo] . surveycounty

--SET IDENTITY_INSERT [RRMMS].[dbo].surveycounty on
--insert into [RRMMS].[dbo].surveycounty (SurveyCountyId,	CountyId,	SurveyId)
--select SurveyCountyId,	CountyId,	SurveyId from [RMMSUAT].[dbo].surveycounty


--SET IDENTITY_INSERT [RRMMS].[dbo].surveycounty off
-- truncate table surveyabstract
 --select top 1 * from [RMMSUAT].[dbo] . surveyabstract

--SET IDENTITY_INSERT [RRMMS].[dbo].surveyabstract on
--insert into [RRMMS].[dbo].surveyabstract (SurveyAbstractId,	SurveyCountyId	,OTLSId	,Abstract,	AlternateName,	Areageom,	Geom,	GrossAcres)
--select SurveyAbstractId,	SurveyCountyId	,OTLSId	,Abstract,	AlternateName,	Areageom,	Geom,	GrossAcres from [RMMSUAT].[dbo].surveyabstract


--SET IDENTITY_INSERT [RRMMS].[dbo].survey on
--insert into [RRMMS].[dbo].survey (SurveyId,	Section,	BlockTownship,	SurveyName,	Geom,	GrossAcres)
--select SurveyId,	Section,	BlockTownship,	SurveyName,	Geom,	GrossAcres from [RMMSUAT].[dbo].survey

--select top 1 * from Survey
























