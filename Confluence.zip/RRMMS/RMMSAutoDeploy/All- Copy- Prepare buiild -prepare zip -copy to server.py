import shutil
import os
import sys
import subprocess
from zipfile import ZipFile



proc = subprocess.Popen("PrepareBuildFolder.bat", cwd=r"c:\\users\aalok dahayat\\desktop\RMMSAutoDeploy")

try:
    outs, errs = proc.communicate(timeout=50)
except TimeoutExpired:
    proc.kill()
    outs, errs = proc.communicate()
#==================================Prepare zip of build =============
 
def get_all_file_paths(directory):
 
    # initializing empty file paths list
    file_paths = []
 
    # crawling through directory and subdirectories
    for root, directories, files in os.walk(directory):
        for filename in files:
            # join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            file_paths.append(filepath)
 
    # returning all file paths
    return file_paths        
 
def main():
    # path to folder which needs to be zipped
    directory = './RMMS1'
 
    # calling function to get all file paths in the directory
    file_paths = get_all_file_paths(directory)
 
    # printing the list of all files to be zipped
    print('Following files will be zipped:')
    for file_name in file_paths:
        print(file_name)
 
    # writing files to a zipfile
    with ZipFile('RMMS1.zip','w') as zip:
        # writing each file one by one
        for file in file_paths:
            zip.write(file)
 
    print('All files zipped successfully!')        
 
 
if __name__ == "__main__":
    main()




#=======================================Copy zip to server =================

subp = subprocess.Popen("CopyZipToServer.bat", cwd=r"c:\users\aalok dahayat\desktop\RMMSAutoDeploy")


#===========================================================================================
print ('end')
