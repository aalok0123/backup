
-- =============================================
-- Author:		Aalok Dahayat
-- Create date: 22 Jun 2017 
-- Description: Return DMS value from latlong, verfied from http://andrew.hedges.name/experiments/convert_lat_long/ 
-- select [dbo].[LatLongToDMS] (32.52189450000000200000,-101.66902355000001000000)
-- =============================================
ALTER FUNCTION [dbo].[LatLongToDMS]
    (
     @ddLat  DECIMAL(23,20)
    ,@ddLong DECIMAL(23,20)
    )
RETURNS varchar(200)
AS
      BEGIN
      DECLARE  @Result varchar(200)
	  DECLARE  @dmsLatHem varchar(10)
	  DECLARE  @dmsLongHem varchar(10)
	  DECLARE  @ddLatVal DECIMAL(23,20)
	  DECLARE @ddLongVal DECIMAL(23,20)
	  DECLARE  @dmsLatDeg int 
	  DECLARE  @dmsLongDeg int

	IF (@ddLat <0 ) 
	     BEGIN 
			SET @dmsLatHem  = 'S';
			SET @ddLatVal =  CASE WHEN @ddLat>=0 THEN @ddLat ELSE (@ddLat)*(1) END -- remove - sign 
		END 
		
   ELSE
		BEGIN
			SET @dmsLatHem  = 'N';
			SET @ddLatVal = @ddLat
		END
		
   IF ( @ddLong<0 ) 
		BEGIN
			 SET  @dmsLongHem = 'W';
			SET @ddLongVal = CASE WHEN @ddLong>=0 THEN @ddLong ELSE (@ddLong)*(-1) END -- remove - sign   
		END
		 ELSE 
		 
	   BEGIN
			 SET  @dmsLongHem = 'E';
			 SET @ddLongVal = @ddLong;
	   END
------------------------Reset Negative value------------------------------------
		SET @ddLatVal = CASE WHEN @ddLatVal>=0 THEN @ddLatVal ELSE (@ddLatVal)*(-1) END 

		SET @ddLongVal = CASE WHEN @ddLongVal>=0 THEN @ddLongVal ELSE (@ddLongVal)*(-1) END 
----------------------------------------------------------------------------------
--Set  degrees value=>degree -------------
		
		set @dmsLatDeg =  PARSENAME(@ddLatVal,2) 
		set @dmsLongDeg =  PARSENAME(@ddLongVal,2) 
		  
-- set minutes value=> * 60 = mins

	DECLARE  @ddLatRemainder DECIMAL(23,20) =   CAST ( (('0.' + CAST( (PARSENAME(@ddLatVal,1)) AS VARCHAR(MAX)) )) AS DECIMAL(23,20)) * 60 ;
	DECLARE @dmsLatMin VARCHAR(5) =   PARSENAME(@ddLatRemainder,2)  
	DECLARE  @ddLongRemainder DECIMAL(23,20) =   CAST ( (('0.' + CAST( (PARSENAME(@ddLongVal,1)) AS VARCHAR(MAX)) )) AS DECIMAL(23,20)) * 60  ;
	DECLARE @dmsLongMin VARCHAR(5) =   PARSENAME(@ddLongRemainder,2) 
--  set secs value=>* 60 again = secs
    
	DECLARE @ddLatMinRemainder  DECIMAL(23,20)=  CAST ( (('0.' + CAST( (PARSENAME(@ddLatRemainder,1)) AS VARCHAR(MAX)) )) AS DECIMAL(23,20)) * 60  ;
	DECLARE @dmsLatSec DECIMAL(5,2)   = round(@ddLatMinRemainder,2);
	DECLARE @ddLongtMinRemainder  DECIMAL(23,20)=  CAST ( (('0.' + CAST( (PARSENAME(@ddLongRemainder,1)) AS VARCHAR(MAX)) )) AS DECIMAL(23,20)) * 60  ;
	DECLARE @dmsLongSec DECIMAL(5,2)   = round(@ddLongtMinRemainder,2);

	-- complete  value
	--SET @Result= CAST(  @dmsLatDeg AS VARCHAR(MAX))+'* ' +   CAST(  @dmsLatMin AS VARCHAR(MAX))  +''' ' +    CAST(  @dmsLatSec AS VARCHAR(MAX))   +''''' ' +  CAST(  @dmsLatHem AS VARCHAR(MAX))    +   CAST(  @dmsLongDeg AS VARCHAR(MAX))+'* ' +   CAST(  @dmsLongMin AS VARCHAR(MAX))  +''' ' +    CAST(  @dmsLongSec AS VARCHAR(MAX))   +''''' ' +  CAST(  @dmsLongHem AS VARCHAR(MAX))

	-- Only Degree value
	SET @Result= CAST(  @dmsLatDeg AS VARCHAR(MAX))+ ' ''' + CAST(  @dmsLatHem AS VARCHAR(MAX))    + ' and '+  CAST(  @dmsLongDeg AS VARCHAR(MAX))+ ' ''' + CAST(  @dmsLongHem AS VARCHAR(MAX))
     RETURN @Result;
    END;

GO


